package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.freecam.FreecamController;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Redirect(
            method = "renderItemInHand",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/Options;getCameraType()Lnet/minecraft/client/CameraType;"))
    private CameraType donututilities$renderHandsDuringFreecam(Options options) {
        return FreecamController.active() ? CameraType.FIRST_PERSON : options.getCameraType();
    }

    @Inject(method = "pick", at = @At("TAIL"))
    private void donututilities$usePlayerPickDuringFreecam(float partialTick, CallbackInfo info) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) {
            return;
        }

        if (FreecamController.active()) {
            Vec3 from = FreecamController.position();
            Vec3 direction = Vec3.directionFromRotation(FreecamController.xRot(), FreecamController.yRot());
            Vec3 to = from.add(direction.scale(client.player.blockInteractionRange()));
            HitResult freecamHit = client.level.clip(new ClipContext(from, to, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, client.player));
            if (freecamHit instanceof BlockHitResult blockHit
                    && freecamHit.getType() == HitResult.Type.BLOCK
                    && client.player.isWithinBlockInteractionRange(blockHit.getBlockPos(), 0.0D)) {
                client.hitResult = freecamHit;
            }
            client.crosshairPickEntity = null;
        }

        if (!DonutUtilitiesClient.MODULES.enabled("anti_trap") || client.hitResult == null) {
            return;
        }
        if (client.hitResult instanceof EntityHitResult entityHit && entityHit.getEntity() instanceof ArmorStand) {
            Vec3 location = entityHit.getLocation();
            client.hitResult = BlockHitResult.miss(location, Direction.UP, BlockPos.containing(location));
            client.crosshairPickEntity = null;
        } else if (client.hitResult instanceof BlockHitResult blockHit
                && client.level.getBlockEntity(blockHit.getBlockPos()) instanceof SignBlockEntity) {
            client.hitResult = BlockHitResult.miss(blockHit.getLocation(), blockHit.getDirection(), blockHit.getBlockPos());
        }
    }
}
