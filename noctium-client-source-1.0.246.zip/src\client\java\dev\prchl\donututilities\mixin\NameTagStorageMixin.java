package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.module.ItemInfoModule;
import net.minecraft.client.renderer.feature.NameTagFeatureRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(NameTagFeatureRenderer.Storage.class)
public abstract class NameTagStorageMixin {
    private static final ThreadLocal<Boolean> DONUTUTILITIES_ITEM_INFO = ThreadLocal.withInitial(() -> false);

    @ModifyVariable(method = "add", at = @At("HEAD"), argsOnly = true)
    private Component donututilities$stripItemInfoMarker(Component text) {
        boolean itemInfo = text != null && text.getString().contains(ItemInfoModule.NAMETAG_MARKER);
        DONUTUTILITIES_ITEM_INFO.set(itemInfo);
        if (!itemInfo) {
            return text;
        }
        MutableComponent result = Component.empty();
        for (Component part : text.toFlatList()) {
            String value = part.getString().replace(ItemInfoModule.NAMETAG_MARKER, "");
            if (!value.isEmpty()) {
                result.append(Component.literal(value).withStyle(part.getStyle()));
            }
        }
        return result;
    }

    @ModifyArg(method = "add", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/SubmitNodeStorage$NameTagSubmit;<init>(Lorg/joml/Matrix4f;FFLnet/minecraft/network/chat/Component;IIID)V"), index = 6)
    private int donututilities$itemInfoBackground(int backgroundColor) {
        return DONUTUTILITIES_ITEM_INFO.get() ? 0xF0151820 : backgroundColor;
    }
}
