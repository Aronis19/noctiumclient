package dev.prchl.donututilities.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.client.Minecraft;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final Map<ModuleCategory, List<Module>> byCategory = new EnumMap<>(ModuleCategory.class);
    private final SusChunkSettings susChunkSettings = new SusChunkSettings();
    private final EspSettings espSettings = new EspSettings();
    private final BlockEspSettings blockEspSettings = new BlockEspSettings();
    private final HudSettings hudSettings = new HudSettings();
    private final FreecamModule freecamModule = new FreecamModule();
    private final MenuScaleSettings menuScaleSettings = new MenuScaleSettings();
    private final PopupSettings popupSettings = new PopupSettings();
    private final BrandSpooferSettings brandSpooferSettings = new BrandSpooferSettings();
    private final ItemInfoModule itemInfoModule = new ItemInfoModule();
    private final PlayerInfoSettings playerInfoSettings = new PlayerInfoSettings();
    private final ModuleListSettings moduleListSettings = new ModuleListSettings();
    private final VisualsSettings visualsSettings = new VisualsSettings();
    private final SwingSpeedSettings swingSpeedSettings = new SwingSpeedSettings();
    private final ClickGuiLayoutSettings clickGuiLayoutSettings = new ClickGuiLayoutSettings();
    private final NameProtectSettings nameProtectSettings = new NameProtectSettings();
    private final SkinProtectSettings skinProtectSettings = new SkinProtectSettings();
    private final DonutRegionSettings donutRegionSettings = new DonutRegionSettings();

    public void registerDefaults() {
        if (!modules.isEmpty()) {
            return;
        }

        add(new Module("block_entity_debug", "Block Entity Debug", ModuleCategory.BASE, "X-ray boxes and optional tracers for loaded block entities.", 0xFF71F5E8));
        add(new Module("hole_esp", "Hole ESP", ModuleCategory.BASE, "Marks enclosed air pockets and possible hidden entrances.", 0xFF8DE96B));
        add(new Module("light_finder", "Light Finder", ModuleCategory.BASE, "Marks player-like light sources in loaded chunks.", 0xFFFFD25A));
        add(new Module("prime_chunk_finder", "Prime Chunk Finder", ModuleCategory.DONUT, "Highlights high-score chunks with multiple base signals.", 0xFFFF7A90));
        add(new Module("sus_chunk_finder", "Sus Chunk Finder", ModuleCategory.DONUT, "Scores chunks from storage, light, and unnatural block signals.", 0xFFFF5C8A));
        add(new Module("suspicious_esp", "Suspicious ESP", ModuleCategory.BASE, "Marks crafted, redstone, portal, rail, and utility blocks.", 0xFFB48CFF));
        add(new AntiTrapModule());
        add(new Module("donut_region_map", "Donut Region Map", ModuleCategory.DONUT,
                "Shows the DonutSMP region grid at your coordinates on any server.", 0xFF72A7FF));

        add(new Module("storage_esp", "Storage ESP", ModuleCategory.RENDER, "Marks chests, barrels, hoppers, furnaces, and shulkers.", 0xFFE6C55C));
        add(new Module("block_esp", "Block ESP", ModuleCategory.RENDER, "Marks selected suspicious blocks from the scanner.", 0xFF90CAF9));
        add(new Module("player_esp", "Player ESP", ModuleCategory.RENDER, "Adds visible particles around loaded players.", 0xFF64FFDA));
        add(new Module("mob_esp", "Mob ESP", ModuleCategory.RENDER, "Adds visible particles around nearby mobs.", 0xFFFFAB91));
        add(new Module("swing_speed", "Swing Speed", ModuleCategory.RENDER, "Speeds up the local hand swing animation.", 0xFF8BE9FD));
        add(new FullbrightModule());
        add(freecamModule);

        add(new Module("menu_scale", "Menu Scale", ModuleCategory.MISC, "Changes the size of the Right Shift ClickGUI.", 0xFF90CAF9));
        add(new Module("skin_protect", "Skin Protect", ModuleCategory.MISC, "Locally replaces player skins with a selected account skin.", 0xFF8BE9FD));
        add(new Module("name_protect", "Name Protect", ModuleCategory.MISC, "Locally replaces your displayed player name.", 0xFF8BE9FD));
        add(itemInfoModule);

        Module moduleList = new Module("module_list", "Module List", ModuleCategory.CLIENT, "Shows enabled modules in the top-right HUD.", 0xFF9CF7F2);
        moduleList.setEnabled(true);
        add(moduleList);
        Module visuals = new Module("visuals", "Visuals", ModuleCategory.CLIENT,
                "Controls HUD accent colors, rainbow animation, and the watermark logo.", 0xFF79C8FF);
        visuals.setEnabled(true);
        add(visuals);
        Module customFont = new Module("custom_font", "Custom Font", ModuleCategory.CLIENT,
                "Toggles the Noctium font across the ClickGUI and client HUD.", 0xFF9CF7F2);
        customFont.setEnabled(true);
        add(customFont);
        add(new Module("hud", "HUD", ModuleCategory.CLIENT, "Shows coordinates, time, ping, TPS, and movement speed.", 0xFFFFFFFF));
        add(new Module("player_info", "Player Info", ModuleCategory.CLIENT, "Shows equipment, ping, distance, and health above loaded players.", 0xFF75E08A));
        Module popup = new Module("popup", "Popup", ModuleCategory.CLIENT, "Shows animated module status notifications.", 0xFF8BE9FD);
        popup.setEnabled(true);
        add(popup);
        add(new Module("brand_spoofer", "Brand Spoofer", ModuleCategory.CLIENT, "Spoofs the client brand sent to servers.", 0xFF8BE9FD));
    }

    private void add(Module module) {
        modules.add(module);
        byCategory.computeIfAbsent(module.category(), ignored -> new ArrayList<>()).add(module);
    }

    public List<Module> modules() {
        return Collections.unmodifiableList(modules);
    }

    public List<Module> modules(ModuleCategory category) {
        return byCategory.getOrDefault(category, List.of());
    }

    public Optional<Module> find(String id) {
        return modules.stream().filter(module -> module.id().equals(id)).findFirst();
    }

    public boolean enabled(String id) {
        return find(id).map(Module::enabled).orElse(false);
    }

    public SusChunkSettings susChunkSettings() {
        return susChunkSettings;
    }

    public EspSettings espSettings() {
        return espSettings;
    }

    public BlockEspSettings blockEspSettings() {
        return blockEspSettings;
    }

    public HudSettings hudSettings() {
        return hudSettings;
    }

    public FreecamModule freecamModule() {
        return freecamModule;
    }

    public MenuScaleSettings menuScaleSettings() {
        return menuScaleSettings;
    }

    public PopupSettings popupSettings() {
        return popupSettings;
    }

    public BrandSpooferSettings brandSpooferSettings() {
        return brandSpooferSettings;
    }

    public ItemInfoModule itemInfoModule() {
        return itemInfoModule;
    }

    public PlayerInfoSettings playerInfoSettings() {
        return playerInfoSettings;
    }

    public ModuleListSettings moduleListSettings() {
        return moduleListSettings;
    }

    public VisualsSettings visualsSettings() {
        return visualsSettings;
    }

    public SwingSpeedSettings swingSpeedSettings() {
        return swingSpeedSettings;
    }

    public ClickGuiLayoutSettings clickGuiLayoutSettings() {
        return clickGuiLayoutSettings;
    }

    public NameProtectSettings nameProtectSettings() {
        return nameProtectSettings;
    }

    public SkinProtectSettings skinProtectSettings() {
        return skinProtectSettings;
    }

    public DonutRegionSettings donutRegionSettings() {
        return donutRegionSettings;
    }

    public void registerKeybinds() {
        freecamModule.registerKeybind();
    }

    public void tickKeybinds(Minecraft client) {
        for (Module module : modules) {
            module.tickKeybind(client);
        }
    }

    public void tick(Minecraft client) {
        for (Module module : modules) {
            if (module.enabled()) {
                module.tick(client);
            }
        }
    }
}
