package dev.prchl.donututilities.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.freecam.FreecamController;
import dev.prchl.donututilities.module.EspSettings;
import dev.prchl.donututilities.scan.BaseMarker;
import dev.prchl.donututilities.scan.MarkerType;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3fc;

public final class ChunkOverlayRenderer {
    private static final int MAX_CHUNK_OVERLAYS = 1024;
    private static final int MAX_MARKER_BOXES = 6000;
    private static final int MAX_BLOCK_ENTITY_BOXES = 1024;
    private static final int MAX_ENTITY_BOXES = 64;
    private static final int MAX_BLOCK_TRACES = 192;
    private static final long SORT_CACHE_MS = 140L;
    private static final long SURFACE_CACHE_MS = 500L;
    private static final int SURFACE_CELL_SIZE = 4;
    private static final float SURFACE_OVERLAY_THICKNESS = 0.24F;
    private static final float FLAT_OVERLAY_OFFSET = 0.65F;
    private static long lastRenderWarningMs;
    private static List<BaseMarker> cachedSortedMarkers = List.of();
    private static long cachedSortAtMs;
    private static long cachedSortChunk = Long.MIN_VALUE;
    private static int cachedMarkerCount = -1;
    private static float cachedSharedSurfaceY = Float.NaN;
    private static long cachedSurfaceAtMs;
    private static long cachedSurfaceChunk = Long.MIN_VALUE;
    private static int cachedSurfaceMarkerCount = -1;

    private ChunkOverlayRenderer() {
    }

    public static void register() {
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(ChunkOverlayRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        try {
            renderSafe(context);
        } catch (Throwable exception) {
            long now = System.currentTimeMillis();
            if (now - lastRenderWarningMs > 5000L) {
                DonutUtilitiesClient.LOGGER.warn("Skipped overlay render to prevent a client crash", exception);
                lastRenderWarningMs = now;
            }
        }
    }

    private static void renderSafe(WorldRenderContext context) {
        Minecraft client = Minecraft.getInstance();
        if (client.level == null || client.player == null || !hasVisibleOverlayModule()) {
            return;
        }

        Camera camera = client.gameRenderer.getMainCamera();
        Vec3 cameraPos = camera.position();
        Vec3 traceStart = traceStart(camera);
        PoseStack matrices = context.matrices();
        VertexConsumer fillVertices = context.consumers().getBuffer(EspRenderTypes.xrayFill());
        VertexConsumer lineVertices = context.consumers().getBuffer(EspRenderTypes.xrayLines());
        int alpha = alphaFromSettings();
        Set<Long> renderedChunks = new HashSet<>();
        int chunkOverlays = 0;
        int markerBoxes = 0;
        int blockEntityBoxes = 0;
        int blockTraces = 0;
        List<BaseMarker> markers = sortedMarkersForRender(client);
        float sharedSusChunkY = sharedSusChunkY(client, markers);

        matrices.pushPose();
        try {
            matrices.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);

            for (BaseMarker marker : markers) {
                if (marker.type() == MarkerType.SUS_CHUNK) {
                    if (!shouldRenderSusChunks()) {
                        continue;
                    }

                    if (chunkOverlays >= susChunkOverlayLimit(client)
                            || overlayOrigin(client).distSqr(marker.pos()) > susChunkRenderDistanceSqr(client)) {
                        continue;
                    }

                    if (drawSusChunk(fillVertices, lineVertices, matrices.last(), client, marker, renderedChunks, alpha, sharedSusChunkY)) {
                        chunkOverlays++;
                    }
                    continue;
                }

                if (markerBoxes >= MAX_MARKER_BOXES || !shouldRenderMarker(marker)
                        || overlayOrigin(client).distSqr(marker.pos()) > markerRenderDistanceSqr(client)) {
                    continue;
                }

                if (marker.type() == MarkerType.BLOCK_ENTITY) {
                    int chunkX = marker.pos().getX() >> 4;
                    int chunkZ = marker.pos().getZ() >> 4;
                    if (blockEntityBoxes >= MAX_BLOCK_ENTITY_BOXES || !client.level.hasChunk(chunkX, chunkZ)) {
                        continue;
                    }
                    blockEntityBoxes++;
                }

                boolean drawTracer = blockTraces < MAX_BLOCK_TRACES;
                drawMarkerBox(fillVertices, lineVertices, matrices.last(), marker, traceStart, drawTracer);
                if (drawTracer) {
                    blockTraces++;
                }
                markerBoxes++;
            }

            drawEntityEsp(fillVertices, lineVertices, matrices.last(), client, traceStart);
        } finally {
            matrices.popPose();
        }
    }

    private static List<BaseMarker> sortedMarkersForRender(Minecraft client) {
        long now = System.currentTimeMillis();
        BlockPos playerPos = client.player.blockPosition();
        long playerChunk = (((long) (playerPos.getX() >> 4)) << 32) ^ ((playerPos.getZ() >> 4) & 0xFFFFFFFFL);
        int markerCount = DonutUtilitiesClient.SCANNER.markerCount();
        if (playerChunk == cachedSortChunk && markerCount == cachedMarkerCount
                && now - cachedSortAtMs < SORT_CACHE_MS) {
            return cachedSortedMarkers;
        }
        List<BaseMarker> markers = new ArrayList<>(DonutUtilitiesClient.SCANNER.markers());
        markers.sort(Comparator.comparingInt(ChunkOverlayRenderer::renderPriority)
                .thenComparingDouble(marker -> playerPos.distSqr(marker.pos()))
                .thenComparingInt(marker -> marker.type().ordinal())
                .thenComparingLong(marker -> marker.pos().asLong()));
        cachedSortedMarkers = List.copyOf(markers);
        cachedSortAtMs = now;
        cachedSortChunk = playerChunk;
        cachedMarkerCount = markerCount;
        return cachedSortedMarkers;
    }

    private static int renderPriority(BaseMarker marker) {
        return switch (marker.type()) {
            case STORAGE, BLOCK_ESP -> 0;
            case SUSPICIOUS, BLOCK_ENTITY -> 1;
            case LIGHT -> isLightVolume(marker) ? 2 : 1;
            case SUS_CHUNK, PRIME_CHUNK, SEED_PATTERN -> 2;
            case HOLE -> 3;
        };
    }

    private static Vec3 traceStart(Camera camera) {
        Vec3 cameraPos = camera.position();
        Vector3fc forward = camera.forwardVector();
        return new Vec3(cameraPos.x + forward.x() * 0.45, cameraPos.y + forward.y() * 0.45, cameraPos.z + forward.z() * 0.45);
    }

    private static BlockPos overlayOrigin(Minecraft client) {
        return FreecamController.active()
                ? BlockPos.containing(FreecamController.position())
                : client.player.blockPosition();
    }

    private static double markerRenderDistanceSqr(Minecraft client) {
        int renderBlocks = Math.max(192, client.options.renderDistance().get() * 16 + 64);
        renderBlocks = Math.max(renderBlocks, DonutUtilitiesClient.MODULES.espSettings().traceDistance());
        return (double) renderBlocks * renderBlocks;
    }

    private static double susChunkRenderDistanceSqr(Minecraft client) {
        int renderBlocks = Math.max(192, client.options.renderDistance().get() * 16 + 64);
        return (double) renderBlocks * renderBlocks;
    }

    private static int susChunkOverlayLimit(Minecraft client) {
        int renderDistance = Math.max(2, client.options.renderDistance().get());
        int fullRenderSquare = (renderDistance * 2 + 1) * (renderDistance * 2 + 1);
        return Math.max(64, Math.min(MAX_CHUNK_OVERLAYS, fullRenderSquare));
    }

    private static boolean drawSusChunk(VertexConsumer fillVertices, VertexConsumer lineVertices, PoseStack.Pose pose,
            Minecraft client, BaseMarker marker, Set<Long> renderedChunks, int alpha, float sharedY) {
        BlockPos pos = marker.pos();
        int chunkX = pos.getX() >> 4;
        int chunkZ = pos.getZ() >> 4;
        long chunkKey = (((long) chunkX) << 32) ^ (chunkZ & 0xFFFFFFFFL);
        if (!renderedChunks.add(chunkKey)) {
            return false;
        }

        int minBlockX = chunkX << 4;
        int minBlockZ = chunkZ << 4;
        if (!client.level.hasChunk(chunkX, chunkZ)) {
            return false;
        }

        float y = (Float.isNaN(sharedY) ? highestChunkSurface(client, minBlockX, minBlockZ) : sharedY) + FLAT_OVERLAY_OFFSET;
        drawBox(fillVertices, pose, minBlockX, y, minBlockZ,
                minBlockX + 16.0F, y + SURFACE_OVERLAY_THICKNESS, minBlockZ + 16.0F,
                255, 45, 75, Math.max(105, alpha));
        drawOutlinedBox(lineVertices, pose, minBlockX, y, minBlockZ,
                minBlockX + 16.0F, y + SURFACE_OVERLAY_THICKNESS, minBlockZ + 16.0F,
                255, 45, 75, 235);
        return true;
    }

    private static float sharedSusChunkY(Minecraft client, List<BaseMarker> markers) {
        if (!shouldRenderSusChunks()) {
            return Float.NaN;
        }

        long now = System.currentTimeMillis();
        BlockPos origin = overlayOrigin(client);
        long originChunk = (((long) (origin.getX() >> 4)) << 32) ^ ((origin.getZ() >> 4) & 0xFFFFFFFFL);
        int markerCount = DonutUtilitiesClient.SCANNER.markerCount();
        if (originChunk == cachedSurfaceChunk && markerCount == cachedSurfaceMarkerCount
                && now - cachedSurfaceAtMs < SURFACE_CACHE_MS) {
            return cachedSharedSurfaceY;
        }

        float lowest = Float.POSITIVE_INFINITY;
        int checked = 0;
        for (BaseMarker marker : markers) {
            if (checked >= susChunkOverlayLimit(client) || marker.type() != MarkerType.SUS_CHUNK
                    || origin.distSqr(marker.pos()) > susChunkRenderDistanceSqr(client)) {
                continue;
            }

            int chunkX = marker.pos().getX() >> 4;
            int chunkZ = marker.pos().getZ() >> 4;
            if (!client.level.hasChunk(chunkX, chunkZ)) {
                continue;
            }

            lowest = Math.min(lowest, highestChunkSurface(client, chunkX << 4, chunkZ << 4));
            checked++;
        }
        cachedSharedSurfaceY = lowest == Float.POSITIVE_INFINITY ? Float.NaN : lowest;
        cachedSurfaceAtMs = now;
        cachedSurfaceChunk = originChunk;
        cachedSurfaceMarkerCount = markerCount;
        return cachedSharedSurfaceY;
    }

    private static float highestChunkSurface(Minecraft client, int minBlockX, int minBlockZ) {
        int highest = client.level.getMinY();
        for (int dx = 0; dx < 16; dx += SURFACE_CELL_SIZE) {
            for (int dz = 0; dz < 16; dz += SURFACE_CELL_SIZE) {
                int x = minBlockX + dx + SURFACE_CELL_SIZE / 2;
                int z = minBlockZ + dz + SURFACE_CELL_SIZE / 2;
                highest = Math.max(highest, client.level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z));
            }
        }
        return highest;
    }

    private static void drawMarkerBox(VertexConsumer fillVertices, VertexConsumer lineVertices, PoseStack.Pose pose, BaseMarker marker,
            Vec3 traceStart, boolean drawTracer) {
        BlockPos pos = marker.pos();
        if (marker.type() == MarkerType.LIGHT) {
            drawLightVolume(fillVertices, lineVertices, pose, marker, traceStart, drawTracer);
            return;
        }
        int color = marker.color();
        int red = color >> 16 & 0xFF;
        int green = color >> 8 & 0xFF;
        int blue = color & 0xFF;
        int alpha = markerAlpha(marker.type());
        float inflate = marker.type() == MarkerType.STORAGE ? 0.16F
                : marker.type() == MarkerType.SUSPICIOUS || marker.type() == MarkerType.BLOCK_ESP ? 0.12F : 0.05F;
        float inset = marker.type() == MarkerType.HOLE ? 0.02F : -inflate;
        float minX = pos.getX() + inset;
        float minY = pos.getY() + inset;
        float minZ = pos.getZ() + inset;
        float maxX = pos.getX() + 1.0F - inset;
        float maxY = pos.getY() + 1.0F - inset;
        float maxZ = pos.getZ() + 1.0F - inset;
        int fillAlpha = markerFillAlpha(marker.type(), alpha);
        drawBox(fillVertices, pose, minX, minY, minZ, maxX, maxY, maxZ, red, green, blue, fillAlpha);
        if (hasTopHighlight(marker.type())) {
            drawTopHighlight(fillVertices, lineVertices, pose, minX, maxY, minZ, maxX, maxZ, red, green, blue, fillAlpha);
        }
        drawOutlinedBox(lineVertices, pose, minX, minY, minZ, maxX, maxY, maxZ, red, green, blue, 245);
        if (drawTracer) {
            drawTrace(lineVertices, pose, traceStart, center(minX, minY, minZ, maxX, maxY, maxZ), false,
                    traceModuleId(marker.type()));
        }
    }

    private static void drawLightVolume(VertexConsumer fillVertices, VertexConsumer lineVertices, PoseStack.Pose pose,
            BaseMarker marker, Vec3 traceStart, boolean drawTracer) {
        BlockPos pos = marker.pos();
        if (isLightVolume(marker)) {
            float inset = 0.035F;
            float strength = Math.max(0.0F, Math.min(1.0F, (marker.score() - 2) / 13.0F));
            strength = strength * strength * (3.0F - 2.0F * strength);
            int red = Math.round(58 + (255 - 58) * strength);
            int green = Math.round(50 + (240 - 50) * strength);
            int blue = Math.round(3 + (24 - 3) * strength);
            int alpha = Math.round(40 + 34 * strength);
            drawBox(fillVertices, pose,
                    pos.getX() + inset, pos.getY() + inset, pos.getZ() + inset,
                    pos.getX() + 1.0F - inset, pos.getY() + 1.0F - inset, pos.getZ() + 1.0F - inset,
                    red, green, blue, alpha);
            return;
        }

        if (drawTracer) {
            drawTrace(lineVertices, pose, traceStart,
                    new Vec3(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D), false,
                    "light_finder");
        }
    }

    private static boolean isLightVolume(BaseMarker marker) {
        return marker.type() == MarkerType.LIGHT && "$LIGHT_VOLUME".equals(marker.label());
    }

    private static boolean hasTopHighlight(MarkerType type) {
        return type == MarkerType.BLOCK_ESP || type == MarkerType.STORAGE
                || type == MarkerType.SUSPICIOUS || type == MarkerType.BLOCK_ENTITY
                || type == MarkerType.LIGHT;
    }

    private static void drawTopHighlight(VertexConsumer fillVertices, VertexConsumer lineVertices, PoseStack.Pose pose,
            float minX, float y, float minZ, float maxX, float maxZ, int red, int green, int blue, int fillAlpha) {
        float capY = y + 0.018F;
        float inset = 0.035F;
        float capMinX = minX + inset;
        float capMinZ = minZ + inset;
        float capMaxX = maxX - inset;
        float capMaxZ = maxZ - inset;
        int capAlpha = Math.min(190, Math.max(120, fillAlpha + 65));

        drawFace(fillVertices, pose, capMinX, capY, capMinZ, capMinX, capY, capMaxZ, capMaxX, capY, capMaxZ, capMaxX, capY, capMinZ,
                red, green, blue, capAlpha);
        drawFace(fillVertices, pose, capMinX, capY, capMinZ, capMaxX, capY, capMinZ, capMaxX, capY, capMaxZ, capMinX, capY, capMaxZ,
                red, green, blue, capAlpha);
        drawOutlinedTop(lineVertices, pose, capMinX, capY + 0.002F, capMinZ, capMaxX, capMaxZ, red, green, blue, 255);
    }

    private static void drawEntityEsp(VertexConsumer fillVertices, VertexConsumer lineVertices, PoseStack.Pose pose, Minecraft client,
            Vec3 traceStart) {
        boolean players = DonutUtilitiesClient.MODULES.enabled("player_esp");
        boolean mobs = DonutUtilitiesClient.MODULES.enabled("mob_esp");
        if (!players && !mobs) {
            return;
        }

        int count = 0;
        for (Entity entity : client.level.entitiesForRendering()) {
            if (count >= MAX_ENTITY_BOXES || entity == client.player || entity.distanceToSqr(client.player) > 16384.0) {
                continue;
            }

            boolean isPlayer = entity instanceof Player;
            if ((!players || !isPlayer) && (!mobs || isPlayer || !(entity instanceof LivingEntity))) {
                continue;
            }

            AABB box = entity.getBoundingBox().inflate(0.08);
            int red = isPlayer ? 100 : 255;
            int green = isPlayer ? 255 : 171;
            int blue = isPlayer ? 218 : 145;
            drawBox(fillVertices, pose,
                    (float) box.minX, (float) box.minY, (float) box.minZ,
                    (float) box.maxX, (float) box.maxY, (float) box.maxZ,
                    red, green, blue, 42);
            drawOutlinedBox(lineVertices, pose,
                    (float) box.minX, (float) box.minY, (float) box.minZ,
                    (float) box.maxX, (float) box.maxY, (float) box.maxZ,
                    red, green, blue, 235);
            drawTrace(lineVertices, pose, traceStart, box.getCenter(), true, isPlayer ? "player_esp" : "mob_esp");
            count++;
        }
    }

    private static void drawTrace(VertexConsumer vertices, PoseStack.Pose pose, Vec3 start, Vec3 target,
            boolean entityTrace, String moduleId) {
        EspSettings settings = DonutUtilitiesClient.MODULES.espSettings();
        if (!settings.traces() || (entityTrace && !settings.entityTraces()) || (!entityTrace && !settings.blockTraces())) {
            return;
        }

        if (start.distanceToSqr(target) > (double) settings.traceDistance() * settings.traceDistance()) {
            return;
        }

        int alpha = settings.traceAlpha() * 255 / 100;
        drawLine(vertices, pose, start, target, settings.traceRed(moduleId), settings.traceGreen(moduleId),
                settings.traceBlue(moduleId), Math.min(255, Math.max(150, alpha)));
    }

    private static String traceModuleId(MarkerType type) {
        return switch (type) {
            case BLOCK_ENTITY -> "block_entity_debug";
            case STORAGE -> "storage_esp";
            case LIGHT -> "light_finder";
            case HOLE -> "hole_esp";
            case BLOCK_ESP -> "block_esp";
            case SUSPICIOUS -> "suspicious_esp";
            case PRIME_CHUNK -> "prime_chunk_finder";
            case SEED_PATTERN -> "seed_chunk_finder";
            case SUS_CHUNK -> "sus_chunk_finder";
        };
    }

    private static void drawTraceBeam(VertexConsumer vertices, PoseStack.Pose pose, Vec3 start, Vec3 target,
            int red, int green, int blue, int alpha) {
        double distance = start.distanceTo(target);
        if (distance <= 0.5) {
            return;
        }

        Vec3 beamStart = start.lerp(target, 0.025);
        Vec3 direction = target.subtract(beamStart).normalize();
        Vec3 up = Math.abs(direction.y) > 0.92D ? new Vec3(1.0D, 0.0D, 0.0D) : new Vec3(0.0D, 1.0D, 0.0D);
        Vec3 side = direction.cross(up).normalize().scale(0.022D);
        Vec3 normal = direction.cross(side).normalize().scale(0.022D);

        Vec3 s1 = beamStart.add(side).add(normal);
        Vec3 s2 = beamStart.add(side).subtract(normal);
        Vec3 s3 = beamStart.subtract(side).subtract(normal);
        Vec3 s4 = beamStart.subtract(side).add(normal);
        Vec3 e1 = target.add(side).add(normal);
        Vec3 e2 = target.add(side).subtract(normal);
        Vec3 e3 = target.subtract(side).subtract(normal);
        Vec3 e4 = target.subtract(side).add(normal);

        drawFace(vertices, pose, s1, e1, e2, s2, red, green, blue, alpha);
        drawFace(vertices, pose, s2, e2, e3, s3, red, green, blue, alpha);
        drawFace(vertices, pose, s3, e3, e4, s4, red, green, blue, alpha);
        drawFace(vertices, pose, s4, e4, e1, s1, red, green, blue, alpha);
        drawFace(vertices, pose, s1, s2, s3, s4, red, green, blue, alpha);
        drawFace(vertices, pose, e1, e4, e3, e2, red, green, blue, alpha);
    }

    private static Vec3 center(float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
        return new Vec3((minX + maxX) * 0.5F, (minY + maxY) * 0.5F, (minZ + maxZ) * 0.5F);
    }

    private static boolean shouldRenderMarker(BaseMarker marker) {
        return switch (marker.type()) {
            case BLOCK_ENTITY -> DonutUtilitiesClient.MODULES.enabled("block_entity_debug");
            case STORAGE -> DonutUtilitiesClient.MODULES.enabled("storage_esp");
            case LIGHT -> DonutUtilitiesClient.MODULES.enabled("light_finder");
            case HOLE -> DonutUtilitiesClient.MODULES.enabled("hole_esp");
            case BLOCK_ESP -> DonutUtilitiesClient.MODULES.enabled("block_esp");
            case SUSPICIOUS -> DonutUtilitiesClient.MODULES.enabled("suspicious_esp");
            case PRIME_CHUNK -> DonutUtilitiesClient.MODULES.enabled("prime_chunk_finder");
            case SEED_PATTERN -> DonutUtilitiesClient.MODULES.enabled("seed_chunk_finder");
            case SUS_CHUNK -> false;
        };
    }

    private static boolean shouldRenderSusChunks() {
        return DonutUtilitiesClient.MODULES.enabled("sus_chunk_finder") || DonutUtilitiesClient.MODULES.enabled("rtp_base_finder");
    }

    private static boolean hasVisibleOverlayModule() {
        return shouldRenderSusChunks()
                || DonutUtilitiesClient.MODULES.enabled("block_entity_debug")
                || DonutUtilitiesClient.MODULES.enabled("storage_esp")
                || DonutUtilitiesClient.MODULES.enabled("light_finder")
                || DonutUtilitiesClient.MODULES.enabled("hole_esp")
                || DonutUtilitiesClient.MODULES.enabled("suspicious_esp")
                || DonutUtilitiesClient.MODULES.enabled("block_esp")
                || DonutUtilitiesClient.MODULES.enabled("prime_chunk_finder")
                || DonutUtilitiesClient.MODULES.enabled("seed_chunk_finder")
                || DonutUtilitiesClient.MODULES.enabled("player_esp")
                || DonutUtilitiesClient.MODULES.enabled("mob_esp")
                || FreecamController.active();
    }

    private static int markerAlpha(MarkerType type) {
        return switch (type) {
            case HOLE -> 80;
            case STORAGE, BLOCK_ENTITY -> 105;
            case LIGHT -> 220;
            case SUSPICIOUS, BLOCK_ESP -> 85;
            case PRIME_CHUNK, SEED_PATTERN -> 100;
            case SUS_CHUNK -> 0;
        };
    }

    private static int markerFillAlpha(MarkerType type, int alpha) {
        return switch (type) {
            case STORAGE -> 72;
            case SUSPICIOUS, BLOCK_ESP -> 58;
            case BLOCK_ENTITY -> 48;
            case LIGHT -> 138;
            case HOLE -> 42;
            case PRIME_CHUNK, SEED_PATTERN -> 70;
            case SUS_CHUNK -> 0;
        };
    }

    private static int alphaFromSettings() {
        int percent = DonutUtilitiesClient.MODULES.susChunkSettings().alpha();
        int clamped = Math.max(15, Math.min(100, percent));
        return Math.max(85, Math.min(155, clamped * 2));
    }

    private static void drawBox(VertexConsumer vertices, PoseStack.Pose pose, float minX, float minY, float minZ,
            float maxX, float maxY, float maxZ, int red, int green, int blue, int alpha) {
        drawFace(vertices, pose, minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ, red, green, blue, alpha);
        drawFace(vertices, pose, minX, maxY, minZ, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, red, green, blue, alpha);
        drawFace(vertices, pose, minX, minY, minZ, minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ, red, green, blue, alpha);
        drawFace(vertices, pose, maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, maxX, minY, maxZ, red, green, blue, alpha);
        drawFace(vertices, pose, minX, minY, minZ, minX, maxY, minZ, maxX, maxY, minZ, maxX, minY, minZ, red, green, blue, alpha);
        drawFace(vertices, pose, minX, minY, maxZ, maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ, red, green, blue, alpha);
    }

    private static void drawFace(VertexConsumer vertices, PoseStack.Pose pose,
            float x1, float y1, float z1, float x2, float y2, float z2,
            float x3, float y3, float z3, float x4, float y4, float z4, int red, int green, int blue, int alpha) {
        vertex(vertices, pose, x1, y1, z1, red, green, blue, alpha);
        vertex(vertices, pose, x2, y2, z2, red, green, blue, alpha);
        vertex(vertices, pose, x3, y3, z3, red, green, blue, alpha);
        vertex(vertices, pose, x4, y4, z4, red, green, blue, alpha);
    }

    private static void drawFace(VertexConsumer vertices, PoseStack.Pose pose,
            Vec3 first, Vec3 second, Vec3 third, Vec3 fourth, int red, int green, int blue, int alpha) {
        drawFace(vertices, pose,
                (float) first.x, (float) first.y, (float) first.z,
                (float) second.x, (float) second.y, (float) second.z,
                (float) third.x, (float) third.y, (float) third.z,
                (float) fourth.x, (float) fourth.y, (float) fourth.z,
                red, green, blue, alpha);
    }

    private static void vertex(VertexConsumer vertices, PoseStack.Pose pose, float x, float y, float z,
            int red, int green, int blue, int alpha) {
        vertices.addVertex(pose, x, y, z).setColor(red, green, blue, alpha);
    }

    private static void drawLine(VertexConsumer vertices, PoseStack.Pose pose, Vec3 start, Vec3 end,
            int red, int green, int blue, int alpha) {
        float x1 = (float) start.x;
        float y1 = (float) start.y;
        float z1 = (float) start.z;
        float x2 = (float) end.x;
        float y2 = (float) end.y;
        float z2 = (float) end.z;
        float dx = x2 - x1;
        float dy = y2 - y1;
        float dz = z2 - z1;
        float length = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (length <= 0.0001F) {
            return;
        }

        float nx = dx / length;
        float ny = dy / length;
        float nz = dz / length;
        vertices.addVertex(pose, x1, y1, z1).setColor(red, green, blue, alpha).setNormal(pose, nx, ny, nz).setLineWidth(2.5F);
        vertices.addVertex(pose, x2, y2, z2).setColor(red, green, blue, alpha).setNormal(pose, nx, ny, nz).setLineWidth(2.5F);
    }

    private static void drawOutlinedBox(VertexConsumer vertices, PoseStack.Pose pose, float minX, float minY, float minZ,
            float maxX, float maxY, float maxZ, int red, int green, int blue, int alpha) {
        line(vertices, pose, minX, minY, minZ, maxX, minY, minZ, red, green, blue, alpha);
        line(vertices, pose, maxX, minY, minZ, maxX, minY, maxZ, red, green, blue, alpha);
        line(vertices, pose, maxX, minY, maxZ, minX, minY, maxZ, red, green, blue, alpha);
        line(vertices, pose, minX, minY, maxZ, minX, minY, minZ, red, green, blue, alpha);
        line(vertices, pose, minX, maxY, minZ, maxX, maxY, minZ, red, green, blue, alpha);
        line(vertices, pose, maxX, maxY, minZ, maxX, maxY, maxZ, red, green, blue, alpha);
        line(vertices, pose, maxX, maxY, maxZ, minX, maxY, maxZ, red, green, blue, alpha);
        line(vertices, pose, minX, maxY, maxZ, minX, maxY, minZ, red, green, blue, alpha);
        line(vertices, pose, minX, minY, minZ, minX, maxY, minZ, red, green, blue, alpha);
        line(vertices, pose, maxX, minY, minZ, maxX, maxY, minZ, red, green, blue, alpha);
        line(vertices, pose, maxX, minY, maxZ, maxX, maxY, maxZ, red, green, blue, alpha);
        line(vertices, pose, minX, minY, maxZ, minX, maxY, maxZ, red, green, blue, alpha);
    }

    private static void drawOutlinedTop(VertexConsumer vertices, PoseStack.Pose pose, float minX, float y, float minZ,
            float maxX, float maxZ, int red, int green, int blue, int alpha) {
        line(vertices, pose, minX, y, minZ, maxX, y, minZ, red, green, blue, alpha);
        line(vertices, pose, maxX, y, minZ, maxX, y, maxZ, red, green, blue, alpha);
        line(vertices, pose, maxX, y, maxZ, minX, y, maxZ, red, green, blue, alpha);
        line(vertices, pose, minX, y, maxZ, minX, y, minZ, red, green, blue, alpha);
        line(vertices, pose, minX, y, minZ, maxX, y, maxZ, red, green, blue, Math.max(120, alpha - 40));
        line(vertices, pose, maxX, y, minZ, minX, y, maxZ, red, green, blue, Math.max(120, alpha - 40));
    }

    private static void line(VertexConsumer vertices, PoseStack.Pose pose, float x1, float y1, float z1,
            float x2, float y2, float z2, int red, int green, int blue, int alpha) {
        drawLine(vertices, pose, new Vec3(x1, y1, z1), new Vec3(x2, y2, z2), red, green, blue, alpha);
    }
}
