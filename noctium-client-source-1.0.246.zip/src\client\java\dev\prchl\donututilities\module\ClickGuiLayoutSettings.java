package dev.prchl.donututilities.module;

import java.util.EnumMap;
import java.util.Map;

public final class ClickGuiLayoutSettings {
    public record Position(int x, int y) {
    }

    private final Map<ModuleCategory, Position> positions = new EnumMap<>(ModuleCategory.class);
    private final Map<ModuleCategory, Boolean> collapsed = new EnumMap<>(ModuleCategory.class);
    private Position searchPosition;
    private boolean searchCollapsed;

    public Position position(ModuleCategory category) {
        return positions.get(category);
    }

    public void setPosition(ModuleCategory category, int x, int y) {
        positions.put(category, new Position(x, y));
    }

    public boolean collapsed(ModuleCategory category) {
        return collapsed.getOrDefault(category, false);
    }

    public void setCollapsed(ModuleCategory category, boolean value) {
        collapsed.put(category, value);
    }

    public Position searchPosition() {
        return searchPosition;
    }

    public void setSearchPosition(int x, int y) {
        searchPosition = new Position(x, y);
    }

    public boolean searchCollapsed() {
        return searchCollapsed;
    }

    public void setSearchCollapsed(boolean searchCollapsed) {
        this.searchCollapsed = searchCollapsed;
    }
}
