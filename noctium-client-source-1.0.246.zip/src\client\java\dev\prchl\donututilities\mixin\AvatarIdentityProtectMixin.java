package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.render.IdentityProtect;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.world.entity.Avatar;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AvatarRenderer.class)
public abstract class AvatarIdentityProtectMixin {
    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/Avatar;Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;F)V",
            at = @At("TAIL"))
    private void donututilities$protectIdentity(Avatar avatar, AvatarRenderState state, float tickDelta,
            CallbackInfo info) {
        state.skin = IdentityProtect.protectedSkin(avatar.getUUID(), state.skin);
        if (state.nameTag != null) {
            state.nameTag = IdentityProtect.protectedName(avatar.getUUID(), state.nameTag);
        }
    }
}
