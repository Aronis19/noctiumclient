package dev.prchl.donututilities.render;

import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.module.DonutRegionSettings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class DonutRegionMapRenderer {
    private static final int MAP_SIZE = 9;
    private static final double REGION_SIZE = 50000.0D;
    private static final double MAP_OFFSET = 225000.0D;
    private static final int[] REGION_COLORS = {
            0xFF9FCE63, 0xFF00A663, 0xFF4FADEA,
            0xFF2F6EBA, 0xFFF5C242, 0xFFFC8803
    };
    private static final String[] REGION_NAMES = {
            "EU CENTRAL", "EU WEST", "NA EAST", "NA WEST", "ASIA", "OCEANIA"
    };
    private static final RegionInfo[] REGIONS = createRegions();

    private DonutRegionMapRenderer() {
    }

    public static void render(GuiGraphics graphics) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) {
            return;
        }

        DonutRegionSettings settings = DonutUtilitiesClient.MODULES.donutRegionSettings();
        boolean customFont = settings.fontMode() == DonutRegionSettings.FontMode.NOCTIUM;
        int cell = settings.cellSize();
        int mapWidth = MAP_SIZE * cell;
        int extraHeight = settings.coordinates() ? 25 : 0;
        if (settings.regionLabels()) {
            extraHeight += REGION_NAMES.length * 10 + 5;
        }
        int contentHeight = mapWidth + extraHeight;
        int maxX = Math.max(0, graphics.guiWidth() - mapWidth);
        int maxY = Math.max(0, graphics.guiHeight() - contentHeight);
        int mapX = Math.round(maxX * settings.positionX() / 100.0F);
        int mapY = Math.round(maxY * settings.positionY() / 100.0F);
        int alpha = Math.round(255.0F * settings.transparency() / 100.0F);

        graphics.fill(mapX, mapY, mapX + mapWidth, mapY + mapWidth, argb(alpha, 25, 25, 25));
        drawCells(graphics, mapX, mapY, cell, alpha);
        if (settings.grid()) {
            drawGrid(graphics, mapX, mapY, cell);
        }
        drawRegionNumbers(graphics, mapX, mapY, cell, settings.labelScale(), customFont);
        if (settings.playerIndicator()) {
            drawPlayerIndicator(graphics, client, mapX, mapY, cell);
        }

        int infoY = mapY + mapWidth + 5;
        if (settings.coordinates()) {
            int x = (int) Math.floor(client.player.getX());
            int z = (int) Math.floor(client.player.getZ());
            HudTheme.text(graphics, "POSITION  X: " + x + "  Z: " + z,
                    mapX, infoY, HudTheme.TEXT, customFont);
            RegionInfo current = regionAt(client.player.getX(), client.player.getZ());
            if (current != null) {
                HudTheme.text(graphics, "REGION  " + current.id + "  " + REGION_NAMES[current.type],
                        mapX, infoY + 11, HudTheme.TEXT, customFont);
            }
            infoY += 28;
        }
        if (settings.regionLabels()) {
            drawLegend(graphics, mapX, infoY, customFont);
        }
    }

    private static void drawCells(GuiGraphics graphics, int mapX, int mapY, int cell, int alpha) {
        for (RegionInfo region : REGIONS) {
            int color = REGION_COLORS[region.type];
            int x = mapX + region.col * cell + 1;
            int y = mapY + region.row * cell + 1;
            graphics.fill(x, y, x + Math.max(1, cell - 2), y + Math.max(1, cell - 2),
                    (Math.min(alpha, 230) << 24) | (color & 0x00FFFFFF));
        }
    }

    private static void drawGrid(GuiGraphics graphics, int mapX, int mapY, int cell) {
        int size = MAP_SIZE * cell;
        int color = 0xE60F0F0F;
        for (int index = 0; index <= MAP_SIZE; index++) {
            int offset = index * cell;
            graphics.fill(mapX + offset, mapY, mapX + offset + 1, mapY + size, color);
            graphics.fill(mapX, mapY + offset, mapX + size, mapY + offset + 1, color);
        }
    }

    private static void drawRegionNumbers(GuiGraphics graphics, int mapX, int mapY, int cell, int labelScale,
            boolean customFont) {
        float scale = Math.max(0.45F, Math.min(1.35F, labelScale / 100.0F));
        for (RegionInfo region : REGIONS) {
            String text = Integer.toString(region.id);
            int textWidth = HudTheme.scaledWidth(text, customFont);
            float available = Math.max(1.0F, cell - 2.0F);
            float fit = Math.min(scale, available / Math.max(1.0F, textWidth));
            float width = textWidth * fit;
            float height = 9.0F * HudTheme.TEXT_SCALE * fit;
            float x = mapX + region.col * cell + (cell - width) / 2.0F;
            float y = mapY + region.row * cell + (cell - height) / 2.0F;
            graphics.pose().pushMatrix();
            graphics.pose().translate(x, y);
            graphics.pose().scale(fit, fit);
            HudTheme.text(graphics, text, 0, 0, 0xFFFFFFFF, customFont);
            graphics.pose().popMatrix();
        }
    }

    private static void drawPlayerIndicator(GuiGraphics graphics, Minecraft client, int mapX, int mapY, int cell) {
        int gridX = worldGrid(client.player.getX());
        int gridZ = worldGrid(client.player.getZ());
        if (gridX < 0 || gridX >= MAP_SIZE || gridZ < 0 || gridZ >= MAP_SIZE) {
            return;
        }
        double fractionX = positiveFraction((client.player.getX() + MAP_OFFSET) / REGION_SIZE);
        double fractionZ = positiveFraction((client.player.getZ() + MAP_OFFSET) / REGION_SIZE);
        int centerX = mapX + gridX * cell + (int) Math.round(fractionX * (cell - 1));
        int centerY = mapY + gridZ * cell + (int) Math.round(fractionZ * (cell - 1));
        double angle = Math.toRadians(-client.player.getYRot() - 90.0F);
        int arrowSize = Math.max(4, Math.min(9, cell / 2));
        int tipX = centerX + (int) Math.round(Math.cos(angle) * arrowSize);
        int tipY = centerY - (int) Math.round(Math.sin(angle) * arrowSize);
        int leftX = centerX + (int) Math.round(Math.cos(angle + Math.toRadians(135.0D)) * arrowSize);
        int leftY = centerY - (int) Math.round(Math.sin(angle + Math.toRadians(135.0D)) * arrowSize);
        int rightX = centerX + (int) Math.round(Math.cos(angle - Math.toRadians(135.0D)) * arrowSize);
        int rightY = centerY - (int) Math.round(Math.sin(angle - Math.toRadians(135.0D)) * arrowSize);
        drawTriangle(graphics, tipX, tipY, leftX, leftY, rightX, rightY, 0xFFFF3232);
    }

    private static void drawTriangle(GuiGraphics graphics, int x1, int y1, int x2, int y2,
            int x3, int y3, int color) {
        int minY = Math.min(y1, Math.min(y2, y3));
        int maxY = Math.max(y1, Math.max(y2, y3));
        for (int y = minY; y <= maxY; y++) {
            int left = Integer.MAX_VALUE;
            int right = Integer.MIN_VALUE;
            int[] intersections = {
                    edgeIntersection(x1, y1, x2, y2, y),
                    edgeIntersection(x2, y2, x3, y3, y),
                    edgeIntersection(x3, y3, x1, y1, y)
            };
            for (int intersection : intersections) {
                if (intersection != Integer.MAX_VALUE) {
                    left = Math.min(left, intersection);
                    right = Math.max(right, intersection);
                }
            }
            if (left <= right && left != Integer.MAX_VALUE) {
                graphics.fill(left, y, right + 1, y + 1, color);
            }
        }
    }

    private static int edgeIntersection(int x1, int y1, int x2, int y2, int y) {
        if (y < Math.min(y1, y2) || y > Math.max(y1, y2)) {
            return Integer.MAX_VALUE;
        }
        if (y1 == y2) {
            return (x1 + x2) / 2;
        }
        return x1 + (x2 - x1) * (y - y1) / (y2 - y1);
    }

    private static void drawLegend(GuiGraphics graphics, int x, int y, boolean customFont) {
        for (int index = 0; index < REGION_NAMES.length; index++) {
            graphics.fill(x, y + index * 10, x + 7, y + index * 10 + 7, REGION_COLORS[index]);
            HudTheme.text(graphics, REGION_NAMES[index], x + 11, y + index * 10 - 1,
                    HudTheme.TEXT, customFont);
        }
    }

    private static RegionInfo regionAt(double worldX, double worldZ) {
        int gridX = worldGrid(worldX);
        int gridZ = worldGrid(worldZ);
        if (gridX < 0 || gridX >= MAP_SIZE || gridZ < 0 || gridZ >= MAP_SIZE) {
            return null;
        }
        return REGIONS[gridZ * MAP_SIZE + gridX];
    }

    private static int worldGrid(double coordinate) {
        return (int) Math.floor((coordinate + MAP_OFFSET) / REGION_SIZE);
    }

    private static double positiveFraction(double value) {
        return value - Math.floor(value);
    }

    private static int argb(int alpha, int red, int green, int blue) {
        return (alpha << 24) | (red << 16) | (green << 8) | blue;
    }

    private static RegionInfo[] createRegions() {
        int[][] layout = {
                {82, 5}, {100, 3}, {101, 3}, {102, 3}, {103, 2}, {104, 2}, {105, 2}, {106, 2}, {91, 2},
                {83, 5}, {44, 3}, {75, 3}, {42, 3}, {41, 2}, {40, 2}, {39, 2}, {38, 2}, {92, 2},
                {84, 5}, {45, 3}, {14, 3}, {13, 3}, {12, 2}, {11, 2}, {10, 2}, {37, 2}, {93, 2},
                {85, 5}, {46, 5}, {74, 5}, {3, 3}, {2, 2}, {1, 2}, {25, 2}, {36, 2}, {94, 2},
                {86, 4}, {47, 4}, {72, 4}, {71, 4}, {5, 2}, {4, 2}, {24, 2}, {35, 2}, {95, 2},
                {87, 4}, {51, 1}, {17, 1}, {9, 0}, {8, 0}, {7, 0}, {23, 0}, {34, 0}, {96, 2},
                {88, 4}, {54, 1}, {18, 1}, {61, 0}, {62, 0}, {21, 0}, {22, 0}, {33, 0}, {97, 0},
                {89, 0}, {26, 1}, {27, 0}, {28, 0}, {29, 0}, {30, 0}, {59, 0}, {32, 0}, {98, 0},
                {90, 0}, {107, 1}, {108, 1}, {109, 1}, {110, 1}, {111, 1}, {112, 1}, {113, 1}, {99, 0}
        };
        RegionInfo[] regions = new RegionInfo[layout.length];
        for (int index = 0; index < layout.length; index++) {
            regions[index] = new RegionInfo(layout[index][0], layout[index][1],
                    index / MAP_SIZE, index % MAP_SIZE);
        }
        return regions;
    }

    private record RegionInfo(int id, int type, int row, int col) {
    }
}
