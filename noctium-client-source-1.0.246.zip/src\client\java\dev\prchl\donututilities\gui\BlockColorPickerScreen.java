package dev.prchl.donututilities.gui;

import dev.prchl.donututilities.render.GuiTheme;
import dev.prchl.donututilities.render.shape.RoundedRectRenderer;
import java.awt.Color;
import java.util.function.IntConsumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;
import org.lwjgl.glfw.GLFW;

public final class BlockColorPickerScreen extends Screen {
    private static final int PANEL_WIDTH = 230;
    private static final int PANEL_HEIGHT = 286;
    private static final int HEADER_HEIGHT = 26;
    private static final int COLOR_SIZE = 145;
    private static final int HUE_WIDTH = 14;
    private final Screen parent;
    private final String blockName;
    private final int originalColor;
    private final IntConsumer saver;
    private float hue;
    private float saturation;
    private float brightness;
    private int dragging;

    public BlockColorPickerScreen(Screen parent, Block block, int originalColor, IntConsumer saver) {
        super(Component.literal("Block color"));
        this.parent = parent;
        this.blockName = block.getName().getString().toUpperCase(java.util.Locale.ROOT);
        this.originalColor = 0xFF000000 | (originalColor & 0x00FFFFFF);
        this.saver = saver;
        float[] hsb = Color.RGBtoHSB((originalColor >> 16) & 0xFF, (originalColor >> 8) & 0xFF,
                originalColor & 0xFF, null);
        hue = hsb[0];
        saturation = hsb[1];
        brightness = hsb[2];
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(graphics);
        graphics.fill(0, 0, width, height, 0x99000000);
        int panelX = (width - PANEL_WIDTH) / 2;
        int panelY = (height - PANEL_HEIGHT) / 2;
        rounded(graphics, panelX, panelY, PANEL_WIDTH, PANEL_HEIGHT, 7, 0xFF191B1F);
        RoundedRectRenderer.roundedTopRect(graphics, panelX, panelY, PANEL_WIDTH, HEADER_HEIGHT, 7, 0xFF1A191E);
        graphics.fill(panelX, panelY + HEADER_HEIGHT - 1, panelX + PANEL_WIDTH, panelY + HEADER_HEIGHT,
                0xFF66D58A);
        String title = GuiTheme.fit("COLOR: " + blockName, PANEL_WIDTH - 14);
        drawCentered(graphics, title, panelX + PANEL_WIDTH / 2, panelY + 7, 0xFFFFFFFF);

        int colorX = panelX + 14;
        int colorY = panelY + HEADER_HEIGHT + 10;
        drawSaturationBrightness(graphics, colorX, colorY);
        int hueX = colorX + COLOR_SIZE + 10;
        drawHue(graphics, hueX, colorY);
        maskRoundedCorners(graphics, colorX, colorY, COLOR_SIZE, COLOR_SIZE, 4, 0xFF191B1F);
        maskRoundedCorners(graphics, hueX, colorY, HUE_WIDTH, COLOR_SIZE, 3, 0xFF191B1F);

        int selectedX = colorX + Math.round(saturation * (COLOR_SIZE - 1));
        int selectedY = colorY + Math.round((1.0F - brightness) * (COLOR_SIZE - 1));
        rounded(graphics, selectedX - 3, selectedY - 3, 7, 7, 4, 0xFF111111);
        rounded(graphics, selectedX - 2, selectedY - 2, 5, 5, 3, 0xFFFFFFFF);
        int hueY = colorY + Math.round(hue * (COLOR_SIZE - 1));
        rounded(graphics, hueX - 2, hueY - 2, HUE_WIDTH + 4, 5, 3, 0xFF111111);
        rounded(graphics, hueX - 1, hueY - 1, HUE_WIDTH + 2, 3, 2, 0xFFFFFFFF);

        int swatchY = colorY + COLOR_SIZE + 10;
        int swatchWidth = 84;
        rounded(graphics, colorX, swatchY, swatchWidth, 22, 4, originalColor);
        rounded(graphics, colorX + 98, swatchY, swatchWidth, 22, 4, currentColor());
        drawCentered(graphics, "ORIGINAL", colorX + swatchWidth / 2, swatchY + 27, GuiTheme.MUTED);
        drawCentered(graphics, "NEW", colorX + 98 + swatchWidth / 2, swatchY + 27, GuiTheme.MUTED);

        int buttonY = panelY + PANEL_HEIGHT - 34;
        int cancelX = panelX + PANEL_WIDTH - 132;
        int saveX = panelX + PANEL_WIDTH - 68;
        drawButton(graphics, cancelX, buttonY, 58, 23, "CANCEL", 0xFF444648,
                inside(mouseX, mouseY, cancelX, buttonY, 58, 23));
        drawButton(graphics, saveX, buttonY, 54, 23, "SAVE", 0xFF55DD83,
                inside(mouseX, mouseY, saveX, buttonY, 54, 23));
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private void drawSaturationBrightness(GuiGraphics graphics, int x, int y) {
        for (int column = 0; column < COLOR_SIZE; column++) {
            float sat = column / (float) (COLOR_SIZE - 1);
            int topColor = 0xFF000000 | (Color.HSBtoRGB(hue, sat, 1.0F) & 0x00FFFFFF);
            graphics.fillGradient(x + column, y, x + column + 1, y + COLOR_SIZE, topColor, 0xFF000000);
        }
    }

    private void drawHue(GuiGraphics graphics, int x, int y) {
        for (int line = 0; line < COLOR_SIZE; line++) {
            int color = 0xFF000000 | (Color.HSBtoRGB(line / (float) (COLOR_SIZE - 1), 1.0F, 1.0F)
                    & 0x00FFFFFF);
            graphics.fill(x, y + line, x + HUE_WIDTH, y + line + 1, color);
        }
    }

    private void drawButton(GuiGraphics graphics, int x, int y, int width, int height, String text, int color,
            boolean hovered) {
        rounded(graphics, x, y, width, height, 5, hovered ? lighten(color) : color);
        drawCentered(graphics, text, x + width / 2, y + 6, 0xFFFFFFFF);
    }

    private void drawCentered(GuiGraphics graphics, String text, int centerX, int y, int color) {
        GuiTheme.text(graphics, text, centerX - GuiTheme.scaledWidth(text) / 2, y, color);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        int panelX = (width - PANEL_WIDTH) / 2;
        int panelY = (height - PANEL_HEIGHT) / 2;
        int colorX = panelX + 14;
        int colorY = panelY + HEADER_HEIGHT + 10;
        int hueX = colorX + COLOR_SIZE + 10;
        if (inside(event.x(), event.y(), colorX, colorY, COLOR_SIZE, COLOR_SIZE)) {
            dragging = 1;
            updateColor(event.x(), event.y(), colorX, colorY, hueX);
            return true;
        }
        if (inside(event.x(), event.y(), hueX, colorY, HUE_WIDTH, COLOR_SIZE)) {
            dragging = 2;
            updateColor(event.x(), event.y(), colorX, colorY, hueX);
            return true;
        }
        int buttonY = panelY + PANEL_HEIGHT - 34;
        if (inside(event.x(), event.y(), panelX + PANEL_WIDTH - 132, buttonY, 58, 23)) {
            minecraft.setScreen(parent);
            return true;
        }
        if (inside(event.x(), event.y(), panelX + PANEL_WIDTH - 68, buttonY, 54, 23)) {
            saver.accept(currentColor());
            minecraft.setScreen(parent);
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (event.button() == 0 && dragging != 0) {
            int panelX = (width - PANEL_WIDTH) / 2;
            int panelY = (height - PANEL_HEIGHT) / 2;
            int colorX = panelX + 14;
            int colorY = panelY + HEADER_HEIGHT + 10;
            updateColor(event.x(), event.y(), colorX, colorY, colorX + COLOR_SIZE + 10);
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = 0;
        return super.mouseReleased(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_ESCAPE) {
            minecraft.setScreen(parent);
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    private void updateColor(double mouseX, double mouseY, int colorX, int colorY, int hueX) {
        if (dragging == 1) {
            saturation = clamp((float) ((mouseX - colorX) / (COLOR_SIZE - 1)), 0.0F, 1.0F);
            brightness = 1.0F - clamp((float) ((mouseY - colorY) / (COLOR_SIZE - 1)), 0.0F, 1.0F);
        } else if (dragging == 2) {
            hue = clamp((float) ((mouseY - colorY) / (COLOR_SIZE - 1)), 0.0F, 1.0F);
        }
    }

    private int currentColor() {
        return 0xFF000000 | (Color.HSBtoRGB(hue, saturation, brightness) & 0x00FFFFFF);
    }

    private int lighten(int color) {
        int red = Math.min(255, ((color >> 16) & 0xFF) + 25);
        int green = Math.min(255, ((color >> 8) & 0xFF) + 25);
        int blue = Math.min(255, (color & 0xFF) + 25);
        return (color & 0xFF000000) | (red << 16) | (green << 8) | blue;
    }

    private void rounded(GuiGraphics graphics, int x, int y, int width, int height, int radius, int color) {
        RoundedRectRenderer.roundedRect(graphics, x, y, width, height, radius, color);
    }

    private void maskRoundedCorners(GuiGraphics graphics, int x, int y, int width, int height, int radius,
            int background) {
        for (int row = 0; row < radius; row++) {
            double offsetY = radius - row - 0.5D;
            double exactInset = radius - Math.sqrt(Math.max(0.0D, radius * radius - offsetY * offsetY));
            int fullPixels = (int) Math.floor(exactInset);
            double edgeCoverage = exactInset - fullPixels;
            if (fullPixels > 0) {
                graphics.fill(x, y + row, x + fullPixels, y + row + 1, background);
                graphics.fill(x + width - fullPixels, y + row, x + width, y + row + 1, background);
                graphics.fill(x, y + height - row - 1, x + fullPixels, y + height - row, background);
                graphics.fill(x + width - fullPixels, y + height - row - 1, x + width, y + height - row,
                        background);
            }
            int feather = withAlpha(background, (int) Math.round(((background >>> 24) & 0xFF) * edgeCoverage));
            graphics.fill(x + fullPixels, y + row, x + fullPixels + 1, y + row + 1, feather);
            graphics.fill(x + width - fullPixels - 1, y + row, x + width - fullPixels, y + row + 1, feather);
            graphics.fill(x + fullPixels, y + height - row - 1, x + fullPixels + 1, y + height - row, feather);
            graphics.fill(x + width - fullPixels - 1, y + height - row - 1,
                    x + width - fullPixels, y + height - row, feather);
        }
    }

    private int withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private boolean inside(double mouseX, double mouseY, int x, int y, int w, int h) {
        return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
    }
}
