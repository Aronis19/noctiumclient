package dev.prchl.donututilities.gui;

import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.module.BlockEspSettings;
import dev.prchl.donututilities.render.GuiTheme;
import dev.prchl.donututilities.render.shape.RoundedRectRenderer;
import dev.prchl.donututilities.scan.MarkerType;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import org.lwjgl.glfw.GLFW;

public final class BlockPickerScreen extends Screen {
    private static final int PANEL_WIDTH = 400;
    private static final int MAX_GRID_HEIGHT = 170;
    private static final int HEADER_HEIGHT = 26;
    private static final int TAB_HEIGHT = 22;
    private static final int SEARCH_HEIGHT = 22;
    private static final int TILE_SIZE = 30;
    private static final int TILE_GAP = 4;
    private static final int FOOTER_HEIGHT = 38;
    private static final int PADDING = 10;
    private static final Set<String> UNOBTAINABLE_BLOCKS = Set.of(
            "minecraft:barrier",
            "minecraft:budding_amethyst",
            "minecraft:chain_command_block",
            "minecraft:command_block",
            "minecraft:end_portal_frame",
            "minecraft:frosted_ice",
            "minecraft:jigsaw",
            "minecraft:light",
            "minecraft:ominous_vault",
            "minecraft:reinforced_deepslate",
            "minecraft:repeating_command_block",
            "minecraft:structure_block",
            "minecraft:structure_void",
            "minecraft:suspicious_gravel",
            "minecraft:suspicious_sand",
            "minecraft:test_block",
            "minecraft:test_instance_block",
            "minecraft:vault");

    private final Screen parent;
    private final List<Block> blocks = new ArrayList<>();
    private final Set<String> stagedSelection = new LinkedHashSet<>();
    private final Map<String, Float> tileHoverAmounts = new java.util.HashMap<>();
    private String searchText = "";
    private boolean searchFocused;
    private boolean selectedTab;
    private int scroll;

    public BlockPickerScreen(Screen parent) {
        super(Component.literal("Block ESP"));
        this.parent = parent;
        BlockEspSettings settings = DonutUtilitiesClient.MODULES.blockEspSettings();
        stagedSelection.addAll(settings.selectedBlockIds());
        for (Block block : BuiltInRegistries.BLOCK) {
            if (isNormallyObtainable(block)) {
                blocks.add(block);
            }
        }
        Set<String> allowedIds = new LinkedHashSet<>();
        blocks.forEach(block -> allowedIds.add(BuiltInRegistries.BLOCK.getKey(block).toString()));
        stagedSelection.retainAll(allowedIds);
        blocks.sort(Comparator.comparing(block -> BuiltInRegistries.BLOCK.getKey(block).toString()));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(graphics);
        graphics.fill(0, 0, width, height, 0x99000000);

        Geometry geometry = geometry();
        int panelX = geometry.x();
        int panelY = geometry.y();
        int panelWidth = geometry.width();
        int panelHeight = geometry.height();
        GuiTheme.panel(graphics, panelX, panelY, panelWidth, panelHeight);
        RoundedRectRenderer.roundedTopRect(graphics, panelX, panelY, panelWidth, HEADER_HEIGHT, 6, 0xFF1A191E);
        graphics.fill(panelX, panelY + HEADER_HEIGHT - 1, panelX + panelWidth, panelY + HEADER_HEIGHT,
                0xFF66D58A);

        String heading = "BLOCK COLORS: BLOCKS (" + stagedSelection.size() + " BLOCKS)";
        drawCentered(graphics, heading, panelX + panelWidth / 2, panelY + 7, 0xFFFFFFFF);

        int tabY = panelY + HEADER_HEIGHT + 8;
        int allWidth = 104;
        int selectedWidth = 112;
        drawTab(graphics, panelX + PADDING, tabY, allWidth, "ALL BLOCKS", !selectedTab,
                inside(mouseX, mouseY, panelX + PADDING, tabY, allWidth, TAB_HEIGHT));
        drawTab(graphics, panelX + PADDING + allWidth + 10, tabY, selectedWidth,
                "SELECTED (" + stagedSelection.size() + ")", selectedTab,
                inside(mouseX, mouseY, panelX + PADDING + allWidth + 10, tabY, selectedWidth, TAB_HEIGHT));

        int contentTop = tabY + TAB_HEIGHT + 8;
        if (!selectedTab) {
            String input = searchText.isEmpty() && !searchFocused ? "SEARCH" : searchText
                    + (searchFocused && (System.currentTimeMillis() / 450L) % 2L == 0L ? "_" : "");
            GuiTheme.searchBox(graphics, panelX + PADDING, contentTop, panelWidth - PADDING * 2,
                    SEARCH_HEIGHT, input);
            contentTop += SEARCH_HEIGHT + 10;
        }

        List<Block> visible = visibleBlocks();
        int gridX = panelX + PADDING + 5;
        int gridWidth = panelWidth - (PADDING + 5) * 2;
        int gridBottom = panelY + panelHeight - FOOTER_HEIGHT;
        int columns = Math.max(1, (gridWidth + TILE_GAP) / (TILE_SIZE + TILE_GAP));
        int viewportHeight = Math.max(1, gridBottom - contentTop);
        int maxScroll = Math.max(0, rows(visible.size(), columns) * (TILE_SIZE + TILE_GAP) - viewportHeight);
        scroll = clamp(scroll, 0, maxScroll);
        int gridY = contentTop - scroll;

        Block hoveredBlock = null;
        BlockEspSettings settings = DonutUtilitiesClient.MODULES.blockEspSettings();
        graphics.enableScissor(gridX, contentTop, gridX + gridWidth, gridBottom);
        for (int i = 0; i < visible.size(); i++) {
            int tileX = gridX + (i % columns) * (TILE_SIZE + TILE_GAP);
            int tileY = gridY + (i / columns) * (TILE_SIZE + TILE_GAP);
            if (tileY + TILE_SIZE < contentTop || tileY > gridBottom) {
                continue;
            }
            Block block = visible.get(i);
            boolean selected = isSelected(block);
            boolean hovered = inside(mouseX, mouseY, tileX, tileY, TILE_SIZE, TILE_SIZE);
            if (hovered) hoveredBlock = block;
            int color = settings.color(block.defaultBlockState());
            String blockId = BuiltInRegistries.BLOCK.getKey(block).toString();
            float hoverAmount = tileHoverAmounts.getOrDefault(blockId, 0.0F);
            float hoverTarget = hovered ? 1.0F : 0.0F;
            hoverAmount += (hoverTarget - hoverAmount) * 0.22F;
            if (Math.abs(hoverTarget - hoverAmount) < 0.01F) hoverAmount = hoverTarget;
            tileHoverAmounts.put(blockId, hoverAmount);
            int idleColor = selected ? translucent(color, 0xA8) : 0xFF27292F;
            int hoverColor = selected ? translucent(color, 0xC8) : 0xFF444648;
            rounded(graphics, tileX, tileY, TILE_SIZE, TILE_SIZE, 4,
                    interpolateColor(idleColor, hoverColor, hoverAmount));
            if (selected) {
                graphics.fill(tileX, tileY, tileX + TILE_SIZE, tileY + 1, lighten(color));
                rounded(graphics, tileX + TILE_SIZE - 8, tileY + 3, 5, 5, 3, lighten(color));
            }
            graphics.renderFakeItem(new ItemStack(block.asItem()), tileX + 7, tileY + 7);
        }
        graphics.disableScissor();

        if (maxScroll > 0) {
            int trackX = panelX + panelWidth - 10;
            int trackHeight = viewportHeight;
            int thumbHeight = Math.max(24, trackHeight * viewportHeight / (viewportHeight + maxScroll));
            int thumbY = contentTop + (trackHeight - thumbHeight) * scroll / maxScroll;
            rounded(graphics, trackX, contentTop, 3, gridBottom - contentTop, 2, 0x552F3440);
            rounded(graphics, trackX, thumbY, 3, thumbHeight, 2, 0xFF66E88A);
        }

        int footerY = panelY + panelHeight - FOOTER_HEIGHT;
        rounded(graphics, panelX, footerY, panelWidth, panelY + panelHeight - footerY, 6, 0xFF1A191E);
        int saveWidth = 68;
        int cancelWidth = 68;
        int clearWidth = 78;
        int buttonY = footerY + 7;
        int saveX = panelX + panelWidth - PADDING - saveWidth;
        int cancelX = saveX - 8 - cancelWidth;
        int clearX = cancelX - 8 - clearWidth;
        drawButton(graphics, clearX, buttonY, clearWidth, 22, "CLEAR ALL", 0xFF593333,
                inside(mouseX, mouseY, clearX, buttonY, clearWidth, 22));
        drawButton(graphics, cancelX, buttonY, cancelWidth, 22, "CANCEL", 0xFF444648,
                inside(mouseX, mouseY, cancelX, buttonY, cancelWidth, 22));
        drawButton(graphics, saveX, buttonY, saveWidth, 22, "SAVE", 0xFF55DD83,
                inside(mouseX, mouseY, saveX, buttonY, saveWidth, 22));

        if (hoveredBlock != null) {
            drawBlockTooltip(graphics, hoveredBlock, mouseX, mouseY);
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private void drawTab(GuiGraphics graphics, int x, int y, int width, String text, boolean active,
            boolean hovered) {
        int color = active ? 0xFF5BE18A : (hovered ? 0xFF444648 : 0xFF303239);
        rounded(graphics, x, y, width, TAB_HEIGHT, 5, color);
        drawCentered(graphics, text, x + width / 2, y + 6, 0xFFFFFFFF);
    }

    private void drawButton(GuiGraphics graphics, int x, int y, int width, int height, String text, int color,
            boolean hovered) {
        rounded(graphics, x, y, width, height, 5, hovered ? lighten(color) : color);
        drawCentered(graphics, text, x + width / 2, y + 6, 0xFFFFFFFF);
    }

    private void drawBlockTooltip(GuiGraphics graphics, Block block, int mouseX, int mouseY) {
        String text = block.getName().getString();
        int tooltipWidth = GuiTheme.scaledWidth(text) + 12;
        int tooltipHeight = 20;
        int x = clamp(mouseX + 9, 2, Math.max(2, width - tooltipWidth - 2));
        int y = clamp(mouseY + 11, 2, Math.max(2, height - tooltipHeight - 2));
        rounded(graphics, x, y, tooltipWidth, tooltipHeight, 4, 0xF0101115);
        GuiTheme.text(graphics, text, x + 6, y + 6, 0xFFFFFFFF);
    }

    private void drawCentered(GuiGraphics graphics, String text, int centerX, int y, int color) {
        GuiTheme.text(graphics, text, centerX - GuiTheme.scaledWidth(text) / 2, y, color);
    }

    private List<Block> visibleBlocks() {
        String query = selectedTab ? "" : searchText.trim().toLowerCase(Locale.ROOT);
        return blocks.stream()
                .filter(block -> !selectedTab || isSelected(block))
                .filter(block -> query.isEmpty()
                        || BuiltInRegistries.BLOCK.getKey(block).toString().toLowerCase(Locale.ROOT).contains(query)
                        || block.getName().getString().toLowerCase(Locale.ROOT).contains(query))
                .toList();
    }

    private boolean isSelected(Block block) {
        return stagedSelection.contains(BuiltInRegistries.BLOCK.getKey(block).toString());
    }

    private boolean isNormallyObtainable(Block block) {
        String blockId = BuiltInRegistries.BLOCK.getKey(block).toString();
        if (blockId.equals("minecraft:bedrock")) {
            return true;
        }
        if (block.asItem() == Items.AIR || UNOBTAINABLE_BLOCKS.contains(blockId)
                || blockId.startsWith("minecraft:infested_")) {
            return false;
        }
        return BuiltInRegistries.ITEM.getKey(block.asItem()).toString().equals(blockId);
    }

    private void toggle(Block block) {
        String id = BuiltInRegistries.BLOCK.getKey(block).toString();
        if (!stagedSelection.add(id)) {
            stagedSelection.remove(id);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 1) {
            if (selectedTab) {
                Block block = blockAt(event.x(), event.y());
                if (block != null) {
                    BlockEspSettings settings = DonutUtilitiesClient.MODULES.blockEspSettings();
                    minecraft.setScreen(new BlockColorPickerScreen(this, block,
                            settings.color(block.defaultBlockState()), color -> {
                                settings.setBlockColor(block, color);
                                DonutUtilitiesClient.SCANNER.clearType(MarkerType.BLOCK_ESP);
                                DonutUtilitiesClient.saveConfig();
                            }));
                }
            }
            return true;
        }
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        Geometry geometry = geometry();
        int panelX = geometry.x();
        int panelY = geometry.y();
        int panelWidth = geometry.width();
        int panelHeight = geometry.height();
        int tabY = panelY + HEADER_HEIGHT + 8;
        int allWidth = 104;
        if (inside(event.x(), event.y(), panelX + PADDING, tabY, allWidth, TAB_HEIGHT)) {
            selectedTab = false;
            scroll = 0;
            return true;
        }
        if (inside(event.x(), event.y(), panelX + PADDING + allWidth + 10, tabY, 112, TAB_HEIGHT)) {
            selectedTab = true;
            searchFocused = false;
            scroll = 0;
            return true;
        }

        int contentTop = tabY + TAB_HEIGHT + 8;
        if (!selectedTab) {
            if (inside(event.x(), event.y(), panelX + PADDING, contentTop, panelWidth - PADDING * 2,
                    SEARCH_HEIGHT)) {
                searchFocused = true;
                return true;
            }
            contentTop += SEARCH_HEIGHT + 10;
        }

        int footerY = panelY + panelHeight - FOOTER_HEIGHT;
        int saveX = panelX + panelWidth - PADDING - 68;
        int cancelX = saveX - 8 - 68;
        int clearX = cancelX - 8 - 78;
        if (inside(event.x(), event.y(), clearX, footerY + 7, 78, 22)) {
            stagedSelection.clear();
            scroll = 0;
            return true;
        }
        if (inside(event.x(), event.y(), cancelX, footerY + 7, 68, 22)) {
            cancelAndClose();
            return true;
        }
        if (inside(event.x(), event.y(), saveX, footerY + 7, 68, 22)) {
            saveAndClose();
            return true;
        }

        List<Block> visible = visibleBlocks();
        int gridX = panelX + PADDING + 5;
        int gridWidth = panelWidth - (PADDING + 5) * 2;
        int gridBottom = footerY;
        if (!inside(event.x(), event.y(), gridX, contentTop, gridWidth, Math.max(1, gridBottom - contentTop))) {
            searchFocused = false;
            return true;
        }
        int columns = Math.max(1, (gridWidth + TILE_GAP) / (TILE_SIZE + TILE_GAP));
        int gridY = contentTop - scroll;
        for (int i = 0; i < visible.size(); i++) {
            int tileX = gridX + (i % columns) * (TILE_SIZE + TILE_GAP);
            int tileY = gridY + (i / columns) * (TILE_SIZE + TILE_GAP);
            if (inside(event.x(), event.y(), tileX, tileY, TILE_SIZE, TILE_SIZE)) {
                toggle(visible.get(i));
                return true;
            }
        }
        return true;
    }

    private Block blockAt(double mouseX, double mouseY) {
        Geometry geometry = geometry();
        int tabY = geometry.y() + HEADER_HEIGHT + 8;
        int contentTop = tabY + TAB_HEIGHT + 8 + (selectedTab ? 0 : SEARCH_HEIGHT + 10);
        int gridX = geometry.x() + PADDING + 5;
        int gridWidth = geometry.width() - (PADDING + 5) * 2;
        int gridBottom = geometry.y() + geometry.height() - FOOTER_HEIGHT;
        if (!inside(mouseX, mouseY, gridX, contentTop, gridWidth, Math.max(1, gridBottom - contentTop))) {
            return null;
        }
        List<Block> visible = visibleBlocks();
        int columns = Math.max(1, (gridWidth + TILE_GAP) / (TILE_SIZE + TILE_GAP));
        int gridY = contentTop - scroll;
        for (int i = 0; i < visible.size(); i++) {
            int tileX = gridX + (i % columns) * (TILE_SIZE + TILE_GAP);
            int tileY = gridY + (i / columns) * (TILE_SIZE + TILE_GAP);
            if (inside(mouseX, mouseY, tileX, tileY, TILE_SIZE, TILE_SIZE)) {
                return visible.get(i);
            }
        }
        return null;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        Geometry geometry = geometry();
        int tabY = geometry.y() + HEADER_HEIGHT + 8;
        int contentTop = tabY + TAB_HEIGHT + 8 + (selectedTab ? 0 : SEARCH_HEIGHT + 10);
        int gridBottom = geometry.y() + geometry.height() - FOOTER_HEIGHT;
        if (!inside(mouseX, mouseY, geometry.x() + PADDING, contentTop,
                geometry.width() - PADDING * 2, Math.max(1, gridBottom - contentTop))) {
            return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
        }
        scroll -= (int) Math.round(scrollY * (TILE_SIZE + TILE_GAP) * 2.0);
        return true;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (!searchFocused || !event.isAllowedChatCharacter()) return super.charTyped(event);
        if (searchText.length() < 48) {
            searchText += event.codepointAsString();
            scroll = 0;
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (searchFocused) {
            if (event.key() == GLFW.GLFW_KEY_BACKSPACE && !searchText.isEmpty()) {
                searchText = searchText.substring(0, searchText.length() - 1);
                scroll = 0;
                return true;
            }
            if (event.key() == GLFW.GLFW_KEY_ENTER) {
                searchFocused = false;
                return true;
            }
        }
        if (event.key() == GLFW.GLFW_KEY_ESCAPE) {
            cancelAndClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        cancelAndClose();
    }

    private void saveAndClose() {
        DonutUtilitiesClient.MODULES.blockEspSettings()
                .setSelectedBlockIds(new LinkedHashSet<>(stagedSelection), true);
        DonutUtilitiesClient.SCANNER.clearType(MarkerType.BLOCK_ESP);
        DonutUtilitiesClient.saveConfig();
        minecraft.setScreen(parent);
    }

    private void cancelAndClose() {
        minecraft.setScreen(parent);
    }

    private Geometry geometry() {
        int panelWidth = Math.min(PANEL_WIDTH, width - 24);
        int gridWidth = panelWidth - (PADDING + 5) * 2;
        int columns = Math.max(1, (gridWidth + TILE_GAP) / (TILE_SIZE + TILE_GAP));
        int requiredGridHeight = rows(visibleBlocks().size(), columns) * (TILE_SIZE + TILE_GAP);
        int gridHeight = Math.min(MAX_GRID_HEIGHT, Math.max(TILE_SIZE + TILE_GAP, requiredGridHeight));
        int controlsHeight = HEADER_HEIGHT + 8 + TAB_HEIGHT + 8 + (selectedTab ? 0 : SEARCH_HEIGHT + 10);
        int panelHeight = Math.min(controlsHeight + gridHeight + FOOTER_HEIGHT, height - 24);
        return new Geometry((width - panelWidth) / 2, (height - panelHeight) / 2, panelWidth, panelHeight);
    }

    private int rows(int size, int columns) {
        return Math.max(1, (size + columns - 1) / columns);
    }

    private int translucent(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    private int lighten(int color) {
        int red = Math.min(255, ((color >> 16) & 0xFF) + 35);
        int green = Math.min(255, ((color >> 8) & 0xFF) + 35);
        int blue = Math.min(255, (color & 0xFF) + 35);
        return (color & 0xFF000000) | (red << 16) | (green << 8) | blue;
    }

    private int interpolateColor(int from, int to, float amount) {
        float value = Math.max(0.0F, Math.min(1.0F, amount));
        int alpha = Math.round(((from >>> 24) & 0xFF) + (((to >>> 24) & 0xFF) - ((from >>> 24) & 0xFF)) * value);
        int red = Math.round(((from >> 16) & 0xFF) + (((to >> 16) & 0xFF) - ((from >> 16) & 0xFF)) * value);
        int green = Math.round(((from >> 8) & 0xFF) + (((to >> 8) & 0xFF) - ((from >> 8) & 0xFF)) * value);
        int blue = Math.round((from & 0xFF) + ((to & 0xFF) - (from & 0xFF)) * value);
        return (alpha << 24) | (red << 16) | (green << 8) | blue;
    }

    private void rounded(GuiGraphics graphics, int x, int y, int width, int height, int radius, int color) {
        RoundedRectRenderer.roundedRect(graphics, x, y, width, height, radius, color);
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private boolean inside(double mouseX, double mouseY, int x, int y, int w, int h) {
        return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
    }

    private record Geometry(int x, int y, int width, int height) {
    }
}
