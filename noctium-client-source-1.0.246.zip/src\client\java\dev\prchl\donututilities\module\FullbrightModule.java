package dev.prchl.donututilities.module;

import net.minecraft.client.Minecraft;

public final class FullbrightModule extends Module {
    private Double oldGamma;

    public FullbrightModule() {
        super("fullbright", "Fullbright", ModuleCategory.RENDER, "Raises client gamma while enabled.", 0xFFF5C542);
    }

    @Override
    public void setEnabled(boolean enabled) {
        if (enabled == enabled()) {
            return;
        }

        Minecraft client = Minecraft.getInstance();
        if (enabled) {
            oldGamma = client.options.gamma().get();
            client.options.gamma().set(12.0);
        } else if (oldGamma != null) {
            client.options.gamma().set(oldGamma);
            oldGamma = null;
        }

        super.setEnabled(enabled);
    }
}
