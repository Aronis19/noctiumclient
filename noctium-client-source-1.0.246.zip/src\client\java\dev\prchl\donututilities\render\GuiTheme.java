package dev.prchl.donututilities.render;

import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.render.shape.RoundedRectRenderer;
import dev.prchl.donututilities.render.shape.ShapeProperties;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class GuiTheme {
    public static final int PANEL = 0xFF191B1F;
    public static final int PANEL_ALT = 0xFF191B1F;
    public static final int HEADER = 0xFF1A191E;
    public static final int ROW = 0xFF191B1F;
    public static final int ROW_HOVER = 0xFF444648;
    public static final int BORDER = 0x403E4655;
    public static final int SHADOW = 0x55000000;
    public static final int LINE = 0x453B4352;
    public static final int TOP_SHINE = 0x1AFFFFFF;
    public static final int HEADER_TEXT = 0xFFFFFFFF;
    public static final int TEXT = 0xFFD3D3D3;
    public static final int MUTED = 0xFFA7A7A7;
    public static final int ACCENT = 0xFF4677FF;
    public static final int ENABLED = 0xFF4DAC68;
    public static final int DISABLED = 0xFFA7A7A7;

    public static final int RADIUS = 6;
    public static final int HEADER_HEIGHT = 28;
    public static final int ROW_HEIGHT = 22;
    public static final float TEXT_SCALE = 1.0F;
    public static final float HEADER_TEXT_SCALE = 1.0F;

    private static final FontDescription UI_FONT = new FontDescription.Resource(
            Identifier.fromNamespaceAndPath(DonutUtilitiesClient.MOD_ID, "minecraft_ten"));

    private GuiTheme() {
    }

    public static void panel(GuiGraphics graphics, int x, int y, int width, int height) {
        rounded(graphics, x, y, width, height, RADIUS, PANEL);
        graphics.fill(x + RADIUS, y, x + width - RADIUS, y + 1, BORDER);
    }

    public static void header(GuiGraphics graphics, int x, int y, int width, int height, String title, boolean selected) {
        header(graphics, x, y, width, height, title, selected, false);
    }

    public static void header(GuiGraphics graphics, int x, int y, int width, int height, String title,
            boolean selected, boolean collapsed) {
        RoundedRectRenderer.roundedTopRect(graphics, x, y, width, height, RADIUS, HEADER);
        drawCategoryIcon(graphics, x + 9, y + 8, title, selected ? ACCENT : TEXT);
        text(graphics, fit(title, unscaledWidth(width - 58, HEADER_TEXT_SCALE), HEADER_TEXT_SCALE),
                x + 30, y + 7, selected ? ACCENT : HEADER_TEXT, HEADER_TEXT_SCALE);
        graphics.fill(x + width - 17, y + 12, x + width - 11, y + 14, selected ? ACCENT : MUTED);
    }

    public static void row(GuiGraphics graphics, int x, int y, int width, int height, boolean hovered) {
        row(graphics, x, y, width, height, hovered ? 1.0F : 0.0F);
    }

    public static void row(GuiGraphics graphics, int x, int y, int width, int height, float hoverAmount) {
        float amount = Math.max(0.0F, Math.min(1.0F, hoverAmount));
        rounded(graphics, x, y, width, height, 4, ROW);
        if (amount <= 0.01F) {
            return;
        }
        int hoverAlpha = Math.round(255.0F * amount);
        rounded(graphics, x, y, width, height, 4, (hoverAlpha << 24) | 0x444648);
    }

    public static void selection(GuiGraphics graphics, int x, int y, int width, int height, boolean hovered) {
        rounded(graphics, x, y, width, height, 7, hovered ? 0x804677FF : 0x603B5FAE);
        RoundedRectRenderer.render(ShapeProperties.create(graphics, x, y, width, height)
                .round(7.0F)
                .thickness(1.0F)
                .outlineColor(0xAA4677FF)
                .color(0x00000000)
                .build());
    }

    public static void toggle(GuiGraphics graphics, int x, int y, boolean enabled) {
        int track = enabled ? 0xCC4677FF : 0x66333333;
        int knob = 0xFFFFFFFF;
        rounded(graphics, x, y, 26, 13, 7, track);
        rounded(graphics, enabled ? x + 15 : x + 2, y + 2, 9, 9, 5, knob);
    }

    public static void searchBox(GuiGraphics graphics, int x, int y, int width, int height, String text) {
        rounded(graphics, x, y, width, height, 5, 0xAA000000);
        graphics.fill(x + 5, y, x + width - 5, y + 1, 0x553E4655);
        mutedText(graphics, fit(text, unscaledWidth(width - 18)), x + 8, y + 6);
    }

    public static void text(GuiGraphics graphics, String text, int x, int y, int color) {
        text(graphics, text, x, y, color, TEXT_SCALE);
    }

    public static void mutedText(GuiGraphics graphics, String text, int x, int y) {
        text(graphics, text, x, y, MUTED);
    }

    public static void accentText(GuiGraphics graphics, String text, int x, int y) {
        text(graphics, text, x, y, ACCENT);
    }

    public static void inset(GuiGraphics graphics, int x, int y, int width, int height) {
        graphics.fill(x, y, x + width, y + height, 0x68000000);
    }

    public static String fit(String text, int maxWidth) {
        return fit(text, maxWidth, TEXT_SCALE);
    }

    public static int scaledWidth(String text) {
        return scaledWidth(text, TEXT_SCALE);
    }

    public static int unscaledWidth(int scaledWidth) {
        return unscaledWidth(scaledWidth, TEXT_SCALE);
    }

    private static void text(GuiGraphics graphics, String text, int x, int y, int color, float scale) {
        Component component = fontComponent(text);
        graphics.pose().pushMatrix();
        graphics.pose().scale(scale, scale);
        int sx = Math.round(x / scale);
        int sy = Math.round(y / scale);
        graphics.drawString(Minecraft.getInstance().font, component, sx + 1, sy + 1, 0x52000000, false);
        graphics.drawString(Minecraft.getInstance().font, component, sx, sy, color, false);
        graphics.pose().popMatrix();
    }

    private static String fit(String text, int maxWidth, float scale) {
        String value = text;
        while (!value.isEmpty() && scaledWidth(value, scale) > maxWidth) {
            value = value.substring(0, value.length() - 1);
        }
        return value;
    }

    private static int scaledWidth(String text, float scale) {
        return Math.round(Minecraft.getInstance().font.width(fontComponent(text)) * scale);
    }

    private static int unscaledWidth(int scaledWidth, float scale) {
        return Math.max(1, Math.round(scaledWidth / scale));
    }

    private static Component fontComponent(String text) {
        Component component = Component.literal(text);
        return DonutUtilitiesClient.MODULES.enabled("custom_font")
                ? component.copy().withStyle(style -> style.withFont(UI_FONT))
                : component;
    }

    private static void rounded(GuiGraphics graphics, int x, int y, int width, int height, int radius, int color) {
        RoundedRectRenderer.roundedRect(graphics, x, y, width, height, radius, color);
    }

    private static void drawCategoryIcon(GuiGraphics graphics, int x, int y, String title, int color) {
        ItemStack stack = switch (title) {
            case "MISC" -> new ItemStack(Items.COMPARATOR);
            case "BASEFINDING" -> new ItemStack(Items.SHULKER_BOX);
            case "DONUT" -> new ItemStack(Items.KELP);
            case "CLIENT" -> new ItemStack(Items.NETHER_STAR);
            case "SEARCH" -> new ItemStack(Items.SPYGLASS);
            case "RENDER" -> new ItemStack(Items.ENDER_EYE);
            default -> ItemStack.EMPTY;
        };
        if (!stack.isEmpty()) {
            graphics.renderItem(stack, x - 2, y - 2);
        } else {
            rounded(graphics, x + 1, y + 1, 9, 9, 2, 0x33000000);
            graphics.fill(x + 3, y + 3, x + 8, y + 8, color);
        }
    }
}
