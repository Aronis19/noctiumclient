package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.render.IdentityProtect;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerTabOverlay.class)
public abstract class PlayerTabIdentityProtectMixin {
    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void donututilities$protectTabName(PlayerInfo info, CallbackInfoReturnable<Component> callback) {
        callback.setReturnValue(IdentityProtect.protectedName(info.getProfile().id(), callback.getReturnValue()));
    }
}
