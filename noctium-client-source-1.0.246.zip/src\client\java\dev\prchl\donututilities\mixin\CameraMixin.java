package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.freecam.FreecamController;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    private boolean detached;

    @Shadow
    protected abstract void setPosition(Vec3 position);

    @Shadow
    protected abstract void setRotation(float yRot, float xRot);

    @Inject(method = "setup", at = @At("TAIL"))
    private void donututilities$applyFreecam(Level level, Entity entity, boolean detached, boolean thirdPersonReverse,
            float partialTick, CallbackInfo info) {
        if (!FreecamController.active()) {
            return;
        }

        FreecamController.updateForRender(Minecraft.getInstance(), entity.getViewYRot(partialTick), entity.getViewXRot(partialTick),
                DonutUtilitiesClient.MODULES.freecamModule().speed());
        setPosition(FreecamController.position());
        setRotation(FreecamController.yRot(), FreecamController.xRot());
        detached = true;
    }
}
