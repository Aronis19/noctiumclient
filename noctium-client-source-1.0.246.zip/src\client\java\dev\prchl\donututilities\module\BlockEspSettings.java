package dev.prchl.donututilities.module;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public final class BlockEspSettings {
    private boolean normalChests = true;
    private boolean trappedChests = true;
    private boolean barrels = true;
    private boolean enderChests = true;
    private boolean shulkers = true;
    private boolean hoppers;
    private boolean droppers;
    private boolean dispensers;
    private boolean crafters;
    private boolean furnaces;
    private boolean pots;
    private boolean spawners = true;
    private boolean ancientDebris = true;
    private boolean diamondOre = true;
    private boolean emeraldOre;
    private boolean goldOre;
    private boolean utility = true;
    private boolean redstone;
    private boolean obsidian = true;
    private boolean lights;
    private boolean customBlock;
    private String customBlockId = "minecraft:deepslate_diamond_ore,minecraft:spawner";
    private boolean explicitSelection = true;
    private final Set<String> selectedBlockIds = new LinkedHashSet<>();
    private final Map<String, Integer> blockColors = new LinkedHashMap<>();

    public boolean explicitSelection() {
        return explicitSelection;
    }

    public boolean isSelected(Block block) {
        return selectedBlockIds.contains(BuiltInRegistries.BLOCK.getKey(block).toString());
    }

    public Set<String> selectedBlockIds() {
        return Collections.unmodifiableSet(new LinkedHashSet<>(selectedBlockIds));
    }

    public Map<String, Integer> blockColors() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(blockColors));
    }

    public void setBlockColor(String blockId, int color) {
        if (blockId == null || blockId.isBlank()) return;
        blockColors.put(blockId, 0xFF000000 | (color & 0x00FFFFFF));
    }

    public void setBlockColor(Block block, int color) {
        setBlockColor(BuiltInRegistries.BLOCK.getKey(block).toString(), color);
    }

    public int selectedCount() {
        return selectedBlockIds.size();
    }

    public void setSelectedBlockIds(Set<String> ids, boolean explicit) {
        selectedBlockIds.clear();
        if (ids != null) {
            selectedBlockIds.addAll(ids);
        }
        explicitSelection = explicit;
    }

    public void toggleBlock(Block block) {
        materializeLegacySelection();
        String id = BuiltInRegistries.BLOCK.getKey(block).toString();
        if (!selectedBlockIds.add(id)) {
            selectedBlockIds.remove(id);
        }
    }

    private void materializeLegacySelection() {
        if (explicitSelection) {
            return;
        }
        explicitSelection = true;
        selectedBlockIds.clear();
        for (Block block : BuiltInRegistries.BLOCK) {
            if (matchesLegacy(block.defaultBlockState())) {
                selectedBlockIds.add(BuiltInRegistries.BLOCK.getKey(block).toString());
            }
        }
    }

    public boolean normalChests() {
        return normalChests;
    }

    public void toggleNormalChests() {
        normalChests = !normalChests;
    }

    public boolean trappedChests() {
        return trappedChests;
    }

    public void toggleTrappedChests() {
        trappedChests = !trappedChests;
    }

    public boolean barrels() {
        return barrels;
    }

    public void toggleBarrels() {
        barrels = !barrels;
    }

    public boolean enderChests() {
        return enderChests;
    }

    public void toggleEnderChests() {
        enderChests = !enderChests;
    }

    public boolean shulkers() {
        return shulkers;
    }

    public void toggleShulkers() {
        shulkers = !shulkers;
    }

    public boolean hoppers() {
        return hoppers;
    }

    public void toggleHoppers() {
        hoppers = !hoppers;
    }

    public boolean droppers() {
        return droppers;
    }

    public void toggleDroppers() {
        droppers = !droppers;
    }

    public boolean dispensers() {
        return dispensers;
    }

    public void toggleDispensers() {
        dispensers = !dispensers;
    }

    public boolean crafters() {
        return crafters;
    }

    public void toggleCrafters() {
        crafters = !crafters;
    }

    public boolean furnaces() {
        return furnaces;
    }

    public void toggleFurnaces() {
        furnaces = !furnaces;
    }

    public boolean pots() {
        return pots;
    }

    public void togglePots() {
        pots = !pots;
    }

    public boolean spawners() {
        return spawners;
    }

    public void toggleSpawners() {
        spawners = !spawners;
    }

    public boolean ancientDebris() {
        return ancientDebris;
    }

    public void toggleAncientDebris() {
        ancientDebris = !ancientDebris;
    }

    public boolean diamondOre() {
        return diamondOre;
    }

    public void toggleDiamondOre() {
        diamondOre = !diamondOre;
    }

    public boolean emeraldOre() {
        return emeraldOre;
    }

    public void toggleEmeraldOre() {
        emeraldOre = !emeraldOre;
    }

    public boolean goldOre() {
        return goldOre;
    }

    public void toggleGoldOre() {
        goldOre = !goldOre;
    }

    public boolean utility() {
        return utility;
    }

    public void toggleUtility() {
        utility = !utility;
    }

    public boolean redstone() {
        return redstone;
    }

    public void toggleRedstone() {
        redstone = !redstone;
    }

    public boolean obsidian() {
        return obsidian;
    }

    public void toggleObsidian() {
        obsidian = !obsidian;
    }

    public boolean lights() {
        return lights;
    }

    public void toggleLights() {
        lights = !lights;
    }

    public boolean customBlock() {
        return customBlock;
    }

    public void toggleCustomBlock() {
        customBlock = !customBlock;
    }

    public String customBlockId() {
        return customBlockId;
    }

    public void setCustomBlockId(String customBlockId) {
        String clean = customBlockId.trim().toLowerCase(java.util.Locale.ROOT);
        if (clean.length() > 160) {
            clean = clean.substring(0, 160);
        }
        this.customBlockId = clean;
    }

    public boolean removeLastCustomChar() {
        if (customBlockId.isEmpty()) {
            return false;
        }
        customBlockId = customBlockId.substring(0, customBlockId.length() - 1);
        return true;
    }

    public void appendCustomChar(String value) {
        if (customBlockId.length() >= 160) {
            return;
        }
        String clean = value.toLowerCase(java.util.Locale.ROOT);
        if (clean.matches("[a-z0-9_:.\\-/,; ]")) {
            customBlockId += clean;
        }
    }

    public boolean matches(BlockState state) {
        return selectedBlockIds.contains(BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString());
    }

    private boolean matchesLegacy(BlockState state) {
        Block block = state.getBlock();
        return (normalChests && isNormalChest(block))
                || (trappedChests && isTrappedChest(block))
                || (barrels && block == Blocks.BARREL)
                || (enderChests && block == Blocks.ENDER_CHEST)
                || (shulkers && isShulker(block))
                || (hoppers && block == Blocks.HOPPER)
                || (droppers && block == Blocks.DROPPER)
                || (dispensers && block == Blocks.DISPENSER)
                || (crafters && block == Blocks.CRAFTER)
                || (furnaces && isFurnace(block))
                || (pots && block == Blocks.DECORATED_POT)
                || (spawners && block == Blocks.SPAWNER)
                || (ancientDebris && block == Blocks.ANCIENT_DEBRIS)
                || (diamondOre && isDiamondOre(block))
                || (emeraldOre && isEmeraldOre(block))
                || (goldOre && isGoldOre(block))
                || (utility && isUtility(block))
                || (redstone && isRedstone(block))
                || (obsidian && isObsidian(block))
                || (lights && isLight(block))
                || (customBlock && isCustomBlock(block));
    }

    public int color(BlockState state) {
        Block block = state.getBlock();
        Integer customColor = blockColors.get(BuiltInRegistries.BLOCK.getKey(block).toString());
        if (customColor != null) {
            return customColor;
        }
        if (isNormalChest(block) || block == Blocks.BARREL) {
            return 0xFF00FF66;
        }
        if (isTrappedChest(block)) {
            return 0xFFFF7A00;
        }
        if (block == Blocks.ENDER_CHEST) {
            return 0xFF00D9FF;
        }
        if (isShulker(block)) {
            return 0xFFFF3DFF;
        }
        if (block == Blocks.HOPPER || block == Blocks.DROPPER || block == Blocks.DISPENSER || block == Blocks.CRAFTER) {
            return 0xFFFFFFFF;
        }
        if (isFurnace(block)) {
            return 0xFFFF3333;
        }
        if (block == Blocks.DECORATED_POT) {
            return 0xFF00FF66;
        }
        if (block == Blocks.SPAWNER) {
            return 0xFF66E3FF;
        }
        if (block == Blocks.ANCIENT_DEBRIS) {
            return 0xFFFF8A65;
        }
        if (isDiamondOre(block)) {
            return 0xFF64E8FF;
        }
        if (isEmeraldOre(block)) {
            return 0xFF58E88F;
        }
        if (isGoldOre(block)) {
            return 0xFFFFD35A;
        }
        if (isUtility(block)) {
            return 0xFFFFB86C;
        }
        if (isRedstone(block)) {
            return 0xFFFF5A6F;
        }
        if (isObsidian(block)) {
            return 0xFF9D7DFF;
        }
        if (isLight(block)) {
            return 0xFFFFF176;
        }
        if (isCustomBlock(block)) {
            return 0xFF90CAF9;
        }
        return 0xFF90CAF9;
    }

    public String label(BlockState state) {
        return state.getBlock().getName().getString();
    }

    private boolean isNormalChest(Block block) {
        return block == Blocks.CHEST
                || block == Blocks.COPPER_CHEST
                || block == Blocks.EXPOSED_COPPER_CHEST
                || block == Blocks.WEATHERED_COPPER_CHEST
                || block == Blocks.OXIDIZED_COPPER_CHEST
                || block == Blocks.WAXED_COPPER_CHEST
                || block == Blocks.WAXED_EXPOSED_COPPER_CHEST
                || block == Blocks.WAXED_WEATHERED_COPPER_CHEST
                || block == Blocks.WAXED_OXIDIZED_COPPER_CHEST;
    }

    private boolean isTrappedChest(Block block) {
        return block == Blocks.TRAPPED_CHEST;
    }

    private boolean isShulker(Block block) {
        return block == Blocks.SHULKER_BOX
                || block == Blocks.WHITE_SHULKER_BOX
                || block == Blocks.ORANGE_SHULKER_BOX
                || block == Blocks.MAGENTA_SHULKER_BOX
                || block == Blocks.LIGHT_BLUE_SHULKER_BOX
                || block == Blocks.YELLOW_SHULKER_BOX
                || block == Blocks.LIME_SHULKER_BOX
                || block == Blocks.PINK_SHULKER_BOX
                || block == Blocks.GRAY_SHULKER_BOX
                || block == Blocks.LIGHT_GRAY_SHULKER_BOX
                || block == Blocks.CYAN_SHULKER_BOX
                || block == Blocks.PURPLE_SHULKER_BOX
                || block == Blocks.BLUE_SHULKER_BOX
                || block == Blocks.BROWN_SHULKER_BOX
                || block == Blocks.GREEN_SHULKER_BOX
                || block == Blocks.RED_SHULKER_BOX
                || block == Blocks.BLACK_SHULKER_BOX;
    }

    private boolean isDiamondOre(Block block) {
        return block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE;
    }

    private boolean isEmeraldOre(Block block) {
        return block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE;
    }

    private boolean isGoldOre(Block block) {
        return block == Blocks.GOLD_ORE
                || block == Blocks.DEEPSLATE_GOLD_ORE
                || block == Blocks.NETHER_GOLD_ORE;
    }

    private boolean isFurnace(Block block) {
        return block == Blocks.FURNACE
                || block == Blocks.BLAST_FURNACE
                || block == Blocks.SMOKER;
    }

    private boolean isUtility(Block block) {
        return block == Blocks.CRAFTING_TABLE
                || block == Blocks.ANVIL
                || block == Blocks.CHIPPED_ANVIL
                || block == Blocks.DAMAGED_ANVIL
                || block == Blocks.ENCHANTING_TABLE
                || block == Blocks.BREWING_STAND
                || block == Blocks.CAULDRON
                || block == Blocks.RESPAWN_ANCHOR
                || block == Blocks.BEACON;
    }

    private boolean isRedstone(Block block) {
        return block == Blocks.REDSTONE_WIRE
                || block == Blocks.REPEATER
                || block == Blocks.COMPARATOR
                || block == Blocks.PISTON
                || block == Blocks.STICKY_PISTON
                || block == Blocks.OBSERVER
                || block == Blocks.DISPENSER
                || block == Blocks.DROPPER
                || block == Blocks.HOPPER;
    }

    private boolean isObsidian(Block block) {
        return block == Blocks.OBSIDIAN
                || block == Blocks.CRYING_OBSIDIAN
                || block == Blocks.NETHER_PORTAL;
    }

    private boolean isLight(Block block) {
        return block == Blocks.TORCH
                || block == Blocks.WALL_TORCH
                || block == Blocks.SOUL_TORCH
                || block == Blocks.SOUL_WALL_TORCH
                || block == Blocks.LANTERN
                || block == Blocks.SOUL_LANTERN
                || block == Blocks.REDSTONE_TORCH
                || block == Blocks.REDSTONE_WALL_TORCH
                || block == Blocks.GLOWSTONE
                || block == Blocks.SEA_LANTERN
                || block == Blocks.JACK_O_LANTERN
                || block == Blocks.REDSTONE_LAMP
                || block == Blocks.CAMPFIRE
                || block == Blocks.SOUL_CAMPFIRE;
    }

    private boolean isCustomBlock(Block block) {
        if (customBlockId.isBlank()) {
            return false;
        }
        String blockId = BuiltInRegistries.BLOCK.getKey(block).toString();
        String[] selectedBlocks = customBlockId.split("[,;\\s]+");
        for (String selectedBlock : selectedBlocks) {
            if (selectedBlock.isBlank()) {
                continue;
            }
            String selected = selectedBlock.contains(":") ? selectedBlock : "minecraft:" + selectedBlock;
            if (blockId.equals(selected)) {
                return true;
            }
        }
        return false;
    }
}
