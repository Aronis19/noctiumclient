package dev.prchl.donututilities.module;

import dev.prchl.donututilities.DonutUtilitiesClient;
import java.util.Locale;
import net.minecraft.util.Mth;

public final class HudSettings {
    public static final int MIN_POSITION = 0;
    public static final int MAX_POSITION = 100;
    private boolean baseScan = true;
    private boolean espStats = true;
    private boolean coordinates = true;
    private boolean realTime = true;
    private boolean ping = true;
    private boolean ticks = true;
    private boolean bps = true;
    private boolean singleRow;
    private boolean potions = true;
    private boolean keybinds = true;
    private boolean panelIcons = true;
    private String panelIconColorHex = "#FFFFFF";
    private int panelIconColor = 0xFFFFFFFF;
    private boolean panelIconRainbow;
    private int keybindPositionX;
    private int keybindPositionY;
    private boolean keybindPositionCustomized;
    private int potionPositionX;
    private int potionPositionY;
    private boolean potionPositionCustomized;

    public boolean baseScan() {
        return baseScan;
    }

    public void toggleBaseScan() {
        baseScan = !baseScan;
    }

    public boolean espStats() {
        return espStats;
    }

    public void toggleEspStats() {
        espStats = !espStats;
    }

    public boolean coordinates() {
        return coordinates;
    }

    public void toggleCoordinates() {
        coordinates = !coordinates;
    }

    public boolean realTime() {
        return realTime;
    }

    public void toggleRealTime() {
        realTime = !realTime;
    }

    public boolean ping() {
        return ping;
    }

    public void togglePing() {
        ping = !ping;
    }

    public boolean ticks() {
        return ticks;
    }

    public void toggleTicks() {
        ticks = !ticks;
    }

    public boolean bps() {
        return bps;
    }

    public void toggleBps() {
        bps = !bps;
    }

    public boolean singleRow() {
        return singleRow;
    }

    public void toggleSingleRow() {
        singleRow = !singleRow;
    }

    public boolean potions() {
        return potions;
    }

    public void togglePotions() {
        potions = !potions;
    }

    public boolean keybinds() {
        return keybinds;
    }

    public void toggleKeybinds() {
        keybinds = !keybinds;
    }

    public boolean panelIcons() {
        return panelIcons;
    }

    public void togglePanelIcons() {
        panelIcons = !panelIcons;
    }

    public String panelIconColorHex() {
        return panelIconColorHex;
    }

    public int panelIconColor() {
        return panelIconColor;
    }

    public void setPanelIconColorHex(String value) {
        String clean = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
        if (clean.startsWith("#")) {
            clean = clean.substring(1);
        }
        clean = clean.replaceAll("[^0-9A-F]", "");
        if (clean.length() > 6) {
            clean = clean.substring(0, 6);
        }
        panelIconColorHex = "#" + clean;
        if (clean.length() == 6) {
            try {
                panelIconColor = 0xFF000000 | Integer.parseInt(clean, 16);
            } catch (NumberFormatException ignored) {
                panelIconColor = 0xFFFFFFFF;
            }
        }
        DonutUtilitiesClient.markConfigDirty();
    }

    public boolean panelIconRainbow() {
        return panelIconRainbow;
    }

    public void togglePanelIconRainbow() {
        panelIconRainbow = !panelIconRainbow;
    }

    public int renderedPanelIconColor(long now) {
        if (!panelIconRainbow) {
            return panelIconColor;
        }
        float hue = (now % 6000L) / 6000.0F;
        return 0xFF000000 | Mth.hsvToRgb(hue, 0.72F, 1.0F);
    }

    public int keybindPositionX() {
        return keybindPositionX;
    }

    public void setKeybindPositionX(int value) {
        keybindPositionX = clampPosition(value);
        keybindPositionCustomized = true;
        DonutUtilitiesClient.markConfigDirty();
    }

    public int keybindPositionY() {
        return keybindPositionY;
    }

    public void setKeybindPositionY(int value) {
        keybindPositionY = clampPosition(value);
        keybindPositionCustomized = true;
        DonutUtilitiesClient.markConfigDirty();
    }

    public boolean keybindPositionCustomized() {
        return keybindPositionCustomized;
    }

    public void loadKeybindPosition(int x, int y, boolean customized) {
        keybindPositionX = clampPosition(x);
        keybindPositionY = clampPosition(y);
        keybindPositionCustomized = customized;
    }

    public int potionPositionX() {
        return potionPositionX;
    }

    public void setPotionPositionX(int value) {
        potionPositionX = clampPosition(value);
        potionPositionCustomized = true;
        DonutUtilitiesClient.markConfigDirty();
    }

    public int potionPositionY() {
        return potionPositionY;
    }

    public void setPotionPositionY(int value) {
        potionPositionY = clampPosition(value);
        potionPositionCustomized = true;
        DonutUtilitiesClient.markConfigDirty();
    }

    public boolean potionPositionCustomized() {
        return potionPositionCustomized;
    }

    public void loadPotionPosition(int x, int y, boolean customized) {
        potionPositionX = clampPosition(x);
        potionPositionY = clampPosition(y);
        potionPositionCustomized = customized;
    }

    private static int clampPosition(int value) {
        return Math.max(MIN_POSITION, Math.min(MAX_POSITION, value));
    }
}
