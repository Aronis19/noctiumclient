package dev.prchl.donututilities.gui;

import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.module.BlockEspSettings;
import dev.prchl.donututilities.module.ClickGuiLayoutSettings;
import dev.prchl.donututilities.module.EspSettings;
import dev.prchl.donututilities.module.FreecamModule;
import dev.prchl.donututilities.module.HudSettings;
import dev.prchl.donututilities.module.DonutRegionSettings;
import dev.prchl.donututilities.module.ItemInfoModule;
import dev.prchl.donututilities.module.Module;
import dev.prchl.donututilities.module.ModuleCategory;
import dev.prchl.donututilities.module.ModuleListSettings;
import dev.prchl.donututilities.module.NameProtectSettings;
import dev.prchl.donututilities.module.MenuScaleSettings;
import dev.prchl.donututilities.module.PopupSettings;
import dev.prchl.donututilities.module.PlayerInfoSettings;
import dev.prchl.donututilities.module.SusChunkSettings;
import dev.prchl.donututilities.module.SwingSpeedSettings;
import dev.prchl.donututilities.module.SkinProtectSettings;
import dev.prchl.donututilities.module.VisualsSettings;
import dev.prchl.donututilities.render.GuiTheme;
import dev.prchl.donututilities.render.shape.RoundedRectRenderer;
import dev.prchl.donututilities.render.shape.ShapeProperties;
import dev.prchl.donututilities.scan.BaseMarker;
import dev.prchl.donututilities.scan.MarkerType;
import java.util.EnumMap;
import java.util.ArrayList;
import java.awt.Color;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class ClickGuiScreen extends Screen {
    private enum SliderDrag {
        SUS,
        ESP,
        FREECAM,
        SWING_SPEED,
        MENU_SCALE,
        PLAYER_INFO_SCALE,
        ITEM_INFO_COLOR,
        ITEM_INFO_AMOUNT_COLOR,
        ITEM_INFO_POSITION,
        PLAYER_INFO_COLOR,
        MODULE_LIST_COLOR,
        VISUALS_COLOR,
        VISUALS_WATERMARK,
        HUD_PANEL_ICON_COLOR,
        HUD_KEYBINDS_POSITION,
        HUD_POTIONS_POSITION,
        DONUT_REGION
    }

    private static final int MAX_PANEL_WIDTH = 196;
    private static final int HEADER_HEIGHT = GuiTheme.HEADER_HEIGHT;
    private static final int ROW_HEIGHT = GuiTheme.ROW_HEIGHT;
    private static final int BASE_GAP = 10;
    private static final int BASE_LEFT = 34;
    private static final int TOP = 38;
    private static final int SEARCH_BOX_HEIGHT = 22;
    private static final int SEARCH_TOP_GAP = 4;
    private static final int SEARCH_RESULTS_GAP = 2;
    private static final int BACKDROP = 0x88000000;
    private static final int ACCENT = GuiTheme.ACCENT;
    private static final int BLUE = GuiTheme.ACCENT;
    private static final int TEXT = GuiTheme.TEXT;
    private static final int MUTED = GuiTheme.MUTED;
    private static final int SETTINGS_ROWS = 12;
    private static final int ESP_SETTINGS_ROWS = 6;
    private static final int BLOCK_ESP_ROWS = 1;
    private static final int FREECAM_SETTINGS_ROWS = 1;
    private static final int SWING_SPEED_SETTINGS_ROWS = 1;
    private static final int HUD_SETTINGS_ROWS = 15;
    private static final int MENU_SCALE_SETTINGS_ROWS = 1;
    private static final int POPUP_SETTINGS_ROWS = 1;
    private static final int ITEM_INFO_SETTINGS_ROWS = 3;
    private static final int PLAYER_INFO_SETTINGS_ROWS = 4;
    private static final int MODULE_LIST_SETTINGS_ROWS = 2;
    private static final int VISUALS_SETTINGS_ROWS = 10;
    private static final int NAME_PROTECT_SETTINGS_ROWS = 2;
    private static final int SKIN_PROTECT_SETTINGS_ROWS = 3;
    private static final int DONUT_REGION_SETTINGS_ROWS = 10;
    private static final int SEARCH_RESULTS = 8;
    private static final int CORNER = GuiTheme.RADIUS;
    private static final Identifier HUE_TEXTURE = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/hue.png");
    private static final int HUE_TEXTURE_WIDTH = 277;
    private static final int HUE_TEXTURE_HEIGHT = 6;
    private static final Identifier CHECKBOX_CHECKED_TEXTURE = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/checkbox_checked.png");
    private static final Identifier CHECKBOX_UNCHECKED_TEXTURE = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/checkbox_unchecked.png");
    private static final int CHECKBOX_TEXTURE_SIZE = 240;
    private static final Identifier TOGGLE_TRACK_ON_TEXTURE = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/toggle_track_on.png");
    private static final Identifier TOGGLE_TRACK_OFF_TEXTURE = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/toggle_track_off.png");
    private static final Identifier TOGGLE_KNOB_TEXTURE = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/toggle_knob.png");
    private static final int TOGGLE_TEXTURE_SIZE = 240;
    private static final Identifier SLIDER_KNOB_TEXTURE = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/slider_knob.png");
    private static final Identifier SLIDER_KNOB_WHITE_TEXTURE = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/slider_knob_white.png");
    private static final int SLIDER_KNOB_TEXTURE_SIZE = 240;
    private final Map<ModuleCategory, int[]> panelPositions = new EnumMap<>(ModuleCategory.class);
    private final Map<ModuleCategory, float[]> displayedPanelPositions = new EnumMap<>(ModuleCategory.class);
    private final Map<ModuleCategory, Boolean> collapsedCategories = new EnumMap<>(ModuleCategory.class);
    private final Map<String, Float> hoverAmounts = new java.util.HashMap<>();
    private final Map<String, Float> checkboxAmounts = new java.util.HashMap<>();
    private final Map<String, Float> moduleToggleAmounts = new java.util.HashMap<>();
    private final Map<String, Long> moduleToggleUpdateNanos = new java.util.HashMap<>();
    private boolean susSettingsOpen;
    private boolean espSettingsOpen;
    private boolean blockEspSettingsOpen;
    private boolean freecamSettingsOpen;
    private boolean swingSpeedSettingsOpen;
    private boolean hudSettingsOpen;
    private boolean menuScaleSettingsOpen;
    private boolean popupSettingsOpen;
    private boolean itemInfoSettingsOpen;
    private boolean playerInfoSettingsOpen;
    private boolean moduleListSettingsOpen;
    private boolean visualsSettingsOpen;
    private boolean nameProtectSettingsOpen;
    private boolean skinProtectSettingsOpen;
    private boolean donutRegionSettingsOpen;
    private String settingsModuleId;
    private String espSettingsAnchorId = "player_esp";
    private ModuleCategory draggingCategory;
    private boolean draggingSearch;
    private boolean searchCollapsed;
    private int dragOffsetX;
    private int dragOffsetY;
    private int searchX;
    private int searchY;
    private boolean searchPositionInitialized;
    private boolean searchFocused;
    private boolean blockInputFocused;
    private boolean itemInfoHexFocused;
    private boolean playerInfoHexFocused;
    private boolean moduleListHexFocused;
    private String searchText = "";
    private Module hoveredTooltipModule;
    private SliderDrag activeSlider;
    private int activeSliderRow;
    private int activeSliderX;
    private int activeSliderWidth;
    private String activeSliderModuleId;
    private Integer pendingMenuScalePercent;
    private float settingsOpenProgress = 1.0F;

    public ClickGuiScreen() {
        super(Component.literal("DonutSMP Utilities"));
        ClickGuiLayoutSettings layout = DonutUtilitiesClient.MODULES.clickGuiLayoutSettings();
        for (ModuleCategory category : ModuleCategory.values()) {
            ClickGuiLayoutSettings.Position position = layout.position(category);
            if (position != null) {
                panelPositions.put(category, new int[] {position.x(), position.y()});
                displayedPanelPositions.put(category, new float[] {position.x(), position.y()});
            }
            collapsedCategories.put(category, layout.collapsed(category));
        }
        ClickGuiLayoutSettings.Position searchPosition = layout.searchPosition();
        if (searchPosition != null) {
            searchX = searchPosition.x();
            searchY = searchPosition.y();
            searchPositionInitialized = true;
        }
        searchCollapsed = layout.searchCollapsed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        saveLayoutState();
        DonutUtilitiesClient.saveConfig();
        super.onClose();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(graphics);
        graphics.fill(0, 0, width, height, BACKDROP);
        updateSettingsOpenAnimation();

        float scale = menuScale();
        int virtualMouseX = (int) Math.floor(mouseX / scale);
        int virtualMouseY = (int) Math.floor(mouseY / scale);
        hoveredTooltipModule = null;
        graphics.pose().pushMatrix();
        graphics.pose().scale(scale, scale);
        int panelWidth = panelWidth();
        ensurePanelPositions(panelWidth);
        for (ModuleCategory category : ModuleCategory.values()) {
            int[] pos = displayedPanelPosition(category);
            drawPanel(graphics, category, pos[0], pos[1], virtualMouseX, virtualMouseY, panelWidth);
        }
        drawSearchPanel(graphics, searchX, searchY, virtualMouseX, virtualMouseY, panelWidth);
        drawModuleTooltip(graphics, hoveredTooltipModule, virtualMouseX, virtualMouseY);
        graphics.pose().popMatrix();

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private int panelWidth() {
        int count = ModuleCategory.values().length + 1;
        int available = virtualWidth() - layoutLeft() * 2 - (layoutGap() * (count - 1));
        return Math.min(MAX_PANEL_WIDTH, Math.max(90, available / count));
    }

    private void ensurePanelPositions(int panelWidth) {
        int virtualWidth = virtualWidth();
        int virtualHeight = virtualHeight();
        int x = layoutLeft();
        for (ModuleCategory category : ModuleCategory.values()) {
            if (!panelPositions.containsKey(category)) {
                panelPositions.put(category, new int[] {x, TOP});
            }
            int[] position = panelPositions.get(category);
            position[0] = clamp(position[0], 0, Math.max(0, virtualWidth - panelWidth));
            position[1] = clamp(position[1], 0, Math.max(0, virtualHeight - HEADER_HEIGHT));
            displayedPanelPositions.computeIfAbsent(category,
                    ignored -> new float[] {position[0], position[1]});
            x += panelWidth + layoutGap();
        }
        if (!searchPositionInitialized) {
            searchX = Math.min(x, Math.max(layoutLeft(), virtualWidth - layoutLeft() - panelWidth));
            searchY = TOP;
            if (x + panelWidth > virtualWidth - layoutLeft()) {
                searchX = layoutLeft();
                searchY = TOP + defaultSearchRowOffset();
            }
            searchPositionInitialized = true;
        }
        searchX = clamp(searchX, 0, Math.max(0, virtualWidth - panelWidth));
        searchY = clamp(searchY, 0, Math.max(0, virtualHeight - HEADER_HEIGHT));
    }

    private void drawPanel(GuiGraphics graphics, ModuleCategory category, int x, int y, int mouseX, int mouseY, int panelWidth) {
        List<Module> modules = DonutUtilitiesClient.MODULES.modules(category);
        boolean collapsed = collapsedCategories.getOrDefault(category, false);
        int height = collapsed ? HEADER_HEIGHT : panelHeight(modules);

        drawHudFrame(graphics, x, y, panelWidth, height);
        drawHudHeader(graphics, x, y, panelWidth, category.title(), collapsed);
        if (collapsed) {
            return;
        }

        int rowY = y + HEADER_HEIGHT;
        boolean firstModule = true;
        for (Module module : modules) {
            boolean hovered = mouseX >= x && mouseX <= x + panelWidth && mouseY >= rowY && mouseY <= rowY + ROW_HEIGHT;
            drawModuleRow(graphics, module, x, rowY, panelWidth, hovered, !firstModule);
            firstModule = false;
            rowY += ROW_HEIGHT;

            int settingsStartY = rowY;
            int fullSettingsHeight = module.id().equals(settingsModuleId) ? moduleSettingsHeight(module) : 0;
            if (fullSettingsHeight > 0) {
                beginSettingsReveal(graphics, x, settingsStartY, panelWidth, fullSettingsHeight);
            }

            if (module.id().equals(settingsModuleId)) {
                drawKeybindSettings(graphics, module, x, rowY, mouseX, mouseY, panelWidth);
                rowY += ROW_HEIGHT;
            }

            if (menuScaleSettingsOpen && module.id().equals("menu_scale")) {
                drawMenuScaleSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += menuScaleSettingsHeight();
            }

            if (popupSettingsOpen && module.id().equals("popup")) {
                drawPopupSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += popupSettingsHeight();
            }

            if (donutRegionSettingsOpen && module.id().equals("donut_region_map")) {
                drawDonutRegionSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += donutRegionSettingsHeight();
            }

            if (susSettingsOpen && module.id().equals("sus_chunk_finder")) {
                drawSusSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += susSettingsHeight();
            }

            if (espSettingsOpen && module.id().equals(espSettingsAnchorId)) {
                drawEspSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += espSettingsHeight();
            }

            if (blockEspSettingsOpen && module.id().equals("block_esp")) {
                drawBlockEspSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += blockEspSettingsHeight();
            }

            if (freecamSettingsOpen && module.id().equals("freecam")) {
                drawFreecamSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += freecamSettingsHeight();
            }

            if (swingSpeedSettingsOpen && module.id().equals("swing_speed")) {
                drawSwingSpeedSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += swingSpeedSettingsHeight();
            }

            if (hudSettingsOpen && module.id().equals("hud")) {
                drawHudSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += hudSettingsHeight();
            }


            if (itemInfoSettingsOpen && module.id().equals("item_info")) {
                drawItemInfoSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += itemInfoSettingsHeight();
            }

            if (playerInfoSettingsOpen && module.id().equals("player_info")) {
                drawPlayerInfoSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += playerInfoSettingsHeight();
            }

            if (moduleListSettingsOpen && module.id().equals("module_list")) {
                drawModuleListSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += moduleListSettingsHeight();
            }
            if (visualsSettingsOpen && module.id().equals("visuals")) {
                drawVisualsSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += visualsSettingsHeight();
            }
            if (nameProtectSettingsOpen && module.id().equals("name_protect")) {
                drawNameProtectSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += NAME_PROTECT_SETTINGS_ROWS * ROW_HEIGHT;
            }

            if (skinProtectSettingsOpen && module.id().equals("skin_protect")) {
                drawSkinProtectSettings(graphics, x, rowY, mouseX, mouseY, panelWidth);
                rowY += SKIN_PROTECT_SETTINGS_ROWS * ROW_HEIGHT;
            }
            if (fullSettingsHeight > 0) {
                graphics.disableScissor();
                rowY = settingsStartY + animatedSettingsHeight(fullSettingsHeight);
            }
        }
    }

    private void drawModuleRow(GuiGraphics graphics, Module module, int x, int y, int panelWidth,
            boolean hovered, boolean separator) {
        if (hovered) {
            hoveredTooltipModule = module;
        }
        drawModuleRowBackground(graphics, module.id(), x, y, panelWidth, hovered);
        if (separator) {
            graphics.fill(x + 9, y, x + panelWidth - 9, y + 1, 0x303E4148);
        }
        if (module.id().equals("menu_scale")) {
            drawHdText(graphics, fitText(module.name(), panelWidth - 70), x + 12, y + 8, TEXT);
            String value = displayedMenuScalePercent() + "%";
            drawHdText(graphics, value, x + panelWidth - 12 - GuiTheme.scaledWidth(value), y + 8, GuiTheme.ACCENT);
            return;
        }
        drawHdText(graphics, fitText(module.name(), panelWidth - 54), x + 9, y + 6, TEXT);
        drawSwitch(graphics, module.id(), x + panelWidth - 35, y + 4, module.enabled());
    }

    private void drawModuleTooltip(GuiGraphics graphics, Module module, int mouseX, int mouseY) {
        if (module == null || module.description() == null || module.description().isBlank()) {
            return;
        }
        List<String> lines = wrapTooltip(module.description(), 210);
        int tooltipWidth = 0;
        for (String line : lines) {
            tooltipWidth = Math.max(tooltipWidth, GuiTheme.scaledWidth(line));
        }
        tooltipWidth += 12;
        int tooltipHeight = lines.size() * 11 + 10;
        int x = clamp(mouseX + 11, 2, Math.max(2, virtualWidth() - tooltipWidth - 2));
        int y = clamp(mouseY + 13, 2, Math.max(2, virtualHeight() - tooltipHeight - 2));
        RoundedRectRenderer.render(ShapeProperties.create(graphics, x, y, tooltipWidth, tooltipHeight)
                .round(5.0F)
                .thickness(1.0F)
                .outlineColor(0xFF444648)
                .color(0xF0101115)
                .build());
        int textY = y + 5;
        for (String line : lines) {
            drawHdText(graphics, line, x + 6, textY, 0xFFFFFFFF);
            textY += 11;
        }
    }

    private List<String> wrapTooltip(String description, int maxWidth) {
        List<String> lines = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        for (String word : description.trim().split("\\s+")) {
            String candidate = current.isEmpty() ? word : current + " " + word;
            if (!current.isEmpty() && GuiTheme.scaledWidth(candidate) > maxWidth) {
                lines.add(current.toString());
                current.setLength(0);
                current.append(word);
            } else {
                current.setLength(0);
                current.append(candidate);
            }
        }
        if (!current.isEmpty()) {
            lines.add(current.toString());
        }
        return lines;
    }

    private int panelHeight(List<Module> modules) {
        int height = HEADER_HEIGHT + Math.max(1, modules.size()) * ROW_HEIGHT;
        if (settingsModuleId != null) {
            for (Module module : modules) {
                if (module.id().equals(settingsModuleId)) {
                    height += animatedSettingsHeight(moduleSettingsHeight(module));
                    break;
                }
            }
        }
        return height;
    }

    private int moduleSettingsHeight(Module module) {
        int specificHeight = switch (module.id()) {
            case "sus_chunk_finder" -> susSettingsHeight();
            case "block_esp" -> blockEspSettingsHeight();
            case "freecam" -> freecamSettingsHeight();
            case "swing_speed" -> swingSpeedSettingsHeight();
            case "hud" -> hudSettingsHeight();
            case "menu_scale" -> menuScaleSettingsHeight();
            case "popup" -> popupSettingsHeight();
            case "item_info" -> itemInfoSettingsHeight();
            case "player_info" -> playerInfoSettingsHeight();
            case "module_list" -> moduleListSettingsHeight();
            case "visuals" -> visualsSettingsHeight();
            case "name_protect" -> NAME_PROTECT_SETTINGS_ROWS * ROW_HEIGHT;
            case "skin_protect" -> SKIN_PROTECT_SETTINGS_ROWS * ROW_HEIGHT;
            case "donut_region_map" -> donutRegionSettingsHeight();
            default -> isEspSettingsModule(module) ? espSettingsHeight() : 0;
        };
        return ROW_HEIGHT + specificHeight;
    }

    private void beginSettingsReveal(GuiGraphics graphics, int x, int y, int width, int fullHeight) {
        int visibleHeight = animatedSettingsHeight(fullHeight);
        graphics.enableScissor(x, y, x + width, y + Math.max(1, visibleHeight));
    }

    private int animatedSettingsHeight(int fullHeight) {
        float inverse = 1.0F - settingsOpenProgress;
        float eased = 1.0F - inverse * inverse * inverse;
        return Math.max(0, Math.min(fullHeight, Math.round(fullHeight * eased)));
    }

    private void updateSettingsOpenAnimation() {
        if (settingsOpenProgress >= 1.0F) {
            return;
        }
        settingsOpenProgress += (1.0F - settingsOpenProgress) * 0.24F;
        if (settingsOpenProgress > 0.985F) {
            settingsOpenProgress = 1.0F;
        }
    }

    private int susSettingsHeight() {
        return SETTINGS_ROWS * ROW_HEIGHT;
    }

    private int espSettingsHeight() {
        return ESP_SETTINGS_ROWS * ROW_HEIGHT;
    }

    private int blockEspSettingsHeight() {
        return BLOCK_ESP_ROWS * ROW_HEIGHT;
    }

    private int freecamSettingsHeight() {
        return FREECAM_SETTINGS_ROWS * ROW_HEIGHT;
    }

    private int swingSpeedSettingsHeight() {
        return SWING_SPEED_SETTINGS_ROWS * ROW_HEIGHT;
    }

    private int hudSettingsHeight() {
        return HUD_SETTINGS_ROWS * ROW_HEIGHT;
    }

    private int menuScaleSettingsHeight() {
        return MENU_SCALE_SETTINGS_ROWS * ROW_HEIGHT;
    }

    private int popupSettingsHeight() {
        return POPUP_SETTINGS_ROWS * ROW_HEIGHT;
    }

    private int donutRegionSettingsHeight() {
        return DONUT_REGION_SETTINGS_ROWS * ROW_HEIGHT;
    }

    private int itemInfoSettingsHeight() {
        return ITEM_INFO_SETTINGS_ROWS * ROW_HEIGHT;
    }

    private int playerInfoSettingsHeight() {
        return PLAYER_INFO_SETTINGS_ROWS * ROW_HEIGHT;
    }

    private int moduleListSettingsHeight() {
        return MODULE_LIST_SETTINGS_ROWS * ROW_HEIGHT;
    }

    private int visualsSettingsHeight() {
        return VISUALS_SETTINGS_ROWS * ROW_HEIGHT;
    }

    private void drawSwitch(GuiGraphics graphics, String id, int x, int y, boolean enabled) {
        float target = enabled ? 1.0F : 0.0F;
        float amount = moduleToggleAmounts.computeIfAbsent(id, ignored -> target);
        long now = System.nanoTime();
        long previous = moduleToggleUpdateNanos.getOrDefault(id, now);
        moduleToggleUpdateNanos.put(id, now);
        double elapsedMs = Math.min(50.0D, Math.max(0.0D, (now - previous) / 1_000_000.0D));
        float smoothing = (float) (1.0D - Math.exp(-elapsedMs / 200.0D));
        amount += (target - amount) * smoothing;
        if (Math.abs(target - amount) < 0.001F) {
            amount = target;
        }
        moduleToggleAmounts.put(id, amount);

        float eased = amount * amount * (3.0F - 2.0F * amount);
        int trackX = x + 9;
        int trackY = y + 1;
        Identifier track = enabled ? TOGGLE_TRACK_ON_TEXTURE : TOGGLE_TRACK_OFF_TEXTURE;
        graphics.blit(RenderPipelines.GUI_TEXTURED, track, trackX, trackY, 10.0F, 50.0F,
                17, 10, 220, 140, TOGGLE_TEXTURE_SIZE, TOGGLE_TEXTURE_SIZE);
        int knobCenterX = trackX + Math.round(5.0F + eased * 7.0F);
        graphics.blit(RenderPipelines.GUI_TEXTURED, TOGGLE_KNOB_TEXTURE,
                knobCenterX - 3, trackY + 2, 28.0F, 64.0F,
                7, 7, 112, 112, TOGGLE_TEXTURE_SIZE, TOGGLE_TEXTURE_SIZE);
    }

    private void drawKeybindSettings(GuiGraphics graphics, Module module, int x, int y,
            int mouseX, int mouseY, int panelWidth) {
        GuiTheme.inset(graphics, x, y, panelWidth, ROW_HEIGHT);
        drawKeybindRow(graphics, x, y, panelWidth, module.keyName(), mouseX, mouseY);
    }

    private void drawKeybindRow(GuiGraphics graphics, int x, int y, int panelWidth, String value,
            int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + panelWidth && mouseY >= y && mouseY <= y + ROW_HEIGHT;
        drawRowBackground(graphics, x, y, panelWidth, hovered);
        drawHdText(graphics, "KEYBIND", x + 8, y + 6, TEXT);
        String fitted = fitText(value, Math.max(30, panelWidth - 78));
        int badgeWidth = GuiTheme.scaledWidth(fitted) + 10;
        int badgeX = x + panelWidth - badgeWidth - 7;
        RoundedRectRenderer.roundedRect(graphics, badgeX, y + 4, badgeWidth, ROW_HEIGHT - 8, 4, 0xFF444648);
        drawHdText(graphics, fitted, badgeX + 5, y + 6, 0xFFFFFFFF);
    }

    private void drawNameProtectSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY,
            int panelWidth) {
        NameProtectSettings settings = DonutUtilitiesClient.MODULES.nameProtectSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, NAME_PROTECT_SETTINGS_ROWS * ROW_HEIGHT);
        drawTextSettingRow(graphics, x, y, panelWidth, "FAKE NAME", settings.fakeName(),
                false, mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT, panelWidth, "HIDE OTHER NAMES",
                settings.hideOthers(), mouseX, mouseY);
    }

    private void drawSkinProtectSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY,
            int panelWidth) {
        SkinProtectSettings settings = DonutUtilitiesClient.MODULES.skinProtectSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, SKIN_PROTECT_SETTINGS_ROWS * ROW_HEIGHT);
        drawTextSettingRow(graphics, x, y, panelWidth, "SKIN OWNER", settings.skinOwner(),
                false, mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT, panelWidth, "CHANGE OWN SKIN",
                settings.changeOwnSkin(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 2, panelWidth, "CHANGE OTHERS SKIN",
                settings.changeOthersSkin(), mouseX, mouseY);
    }

    private void drawTextSettingRow(GuiGraphics graphics, int x, int y, int panelWidth, String label,
            String value, boolean focused, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + panelWidth && mouseY >= y && mouseY <= y + ROW_HEIGHT;
        drawRowBackground(graphics, x, y, panelWidth, hovered);
        drawHdText(graphics, label, x + 8, y + 6, MUTED);
        String shown = value + (focused && (System.currentTimeMillis() / 450L) % 2L == 0L ? "_" : "");
        drawHdText(graphics, fitText(shown, panelWidth - 88), x + 86, y + 6, 0xFFFFFFFF);
    }

    private void drawSusSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        SusChunkSettings settings = DonutUtilitiesClient.MODULES.susChunkSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, SETTINGS_ROWS * ROW_HEIGHT);

        int row = y;
        drawSlider(graphics, x, row, panelWidth, "SIMULATION DISTANCE", settings.simulationDistance(), 2, 12, mouseX, mouseY);
        row += ROW_HEIGHT;
        drawSlider(graphics, x, row, panelWidth, "SENSITIVITY", settings.sensitivity(), 1, 10, mouseX, mouseY);
        row += ROW_HEIGHT;
        drawSlider(graphics, x, row, panelWidth, "ALPHA", settings.alpha(), 10, 100, mouseX, mouseY);
        row += ROW_HEIGHT;
        drawSlider(graphics, x, row, panelWidth, "MIN SUS BLOCKS", settings.minimumSuspiciousBlocks(), 0, 64, mouseX, mouseY);
        row += ROW_HEIGHT;
        drawCheckbox(graphics, x, row, panelWidth, "SMART ADJUSTMENT", settings.smartAdjustment(), mouseX, mouseY);
        row += ROW_HEIGHT;
        drawCheckbox(graphics, x, row, panelWidth, "KELP", settings.kelp(), mouseX, mouseY);
        row += ROW_HEIGHT;
        drawCheckbox(graphics, x, row, panelWidth, "CAVE VINES", settings.caveVines(), mouseX, mouseY);
        row += ROW_HEIGHT;
        drawCheckbox(graphics, x, row, panelWidth, "VINES", settings.vines(), mouseX, mouseY);
        row += ROW_HEIGHT;
        drawCheckbox(graphics, x, row, panelWidth, "AMETHYST", settings.amethyst(), mouseX, mouseY);
        row += ROW_HEIGHT;
        drawCheckbox(graphics, x, row, panelWidth, "BAMBOO", settings.bamboo(), mouseX, mouseY);
        row += ROW_HEIGHT;
        drawCheckbox(graphics, x, row, panelWidth, "BEE NEST", settings.beeNest(), mouseX, mouseY);
        row += ROW_HEIGHT;
        drawCheckbox(graphics, x, row, panelWidth, "ROTATED DEEPSLATE", settings.rotatedDeepslate(), mouseX, mouseY);
    }

    private void drawEspSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        EspSettings settings = DonutUtilitiesClient.MODULES.espSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, ESP_SETTINGS_ROWS * ROW_HEIGHT);

        int row = y;
        drawCheckbox(graphics, x, row, panelWidth, "TRACES", settings.traces(), mouseX, mouseY);
        row += ROW_HEIGHT;
        drawCheckbox(graphics, x, row, panelWidth, "ENTITY TRACES", settings.entityTraces(), mouseX, mouseY);
        row += ROW_HEIGHT;
        drawCheckbox(graphics, x, row, panelWidth, "BLOCK TRACES", settings.blockTraces(), mouseX, mouseY);
        row += ROW_HEIGHT;
        drawSlider(graphics, x, row, panelWidth, "TRACE DISTANCE", settings.traceDistance(), 32, 1024, mouseX, mouseY);
        row += ROW_HEIGHT;
        drawSlider(graphics, x, row, panelWidth, "TRACE ALPHA", settings.traceAlpha(), 15, 100, mouseX, mouseY);
        row += ROW_HEIGHT;
        int traceColor = 0xFF000000
                | settings.traceRed(espSettingsAnchorId) << 16
                | settings.traceGreen(espSettingsAnchorId) << 8
                | settings.traceBlue(espSettingsAnchorId);
        String traceHex = String.format(Locale.ROOT, "#%06X", traceColor & 0xFFFFFF);
        drawHueSlider(graphics, x, row, panelWidth, "TRACER COLOR", traceHex, traceColor, mouseX, mouseY);
    }

    private void drawBlockEspSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        BlockEspSettings settings = DonutUtilitiesClient.MODULES.blockEspSettings();
        boolean hovered = mouseX >= x && mouseX <= x + panelWidth && mouseY >= y && mouseY <= y + ROW_HEIGHT;
        drawRowBackground(graphics, x, y, panelWidth, hovered);
        drawHdText(graphics, "CHOOSE...", x + 12, y + 8, GuiTheme.ACCENT);
        String count = settings.selectedCount() + " BLOCKS";
        drawHdText(graphics, fitText(count, panelWidth - 92), x + panelWidth - 82, y + 8, GuiTheme.MUTED);
    }

    private void drawFreecamSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        GuiTheme.inset(graphics, x, y, panelWidth, FREECAM_SETTINGS_ROWS * ROW_HEIGHT);
        drawSlider(graphics, x, y, panelWidth, "SPEED", DonutUtilitiesClient.MODULES.freecamModule().speed(), FreecamModule.MIN_SPEED, FreecamModule.MAX_SPEED, mouseX, mouseY);
    }

    private void drawSwingSpeedSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        SwingSpeedSettings settings = DonutUtilitiesClient.MODULES.swingSpeedSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, SWING_SPEED_SETTINGS_ROWS * ROW_HEIGHT);
        drawSlider(graphics, x, y, panelWidth, "SPEED", settings.speed(),
                SwingSpeedSettings.MIN_SPEED, SwingSpeedSettings.MAX_SPEED, mouseX, mouseY);
    }

    private void drawHudSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        HudSettings settings = DonutUtilitiesClient.MODULES.hudSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, HUD_SETTINGS_ROWS * ROW_HEIGHT);
        drawCheckbox(graphics, x, y, panelWidth, "COORDINATES", settings.coordinates(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT, panelWidth, "REAL TIME", settings.realTime(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 2, panelWidth, "PING", settings.ping(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 3, panelWidth, "TICKS", settings.ticks(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 4, panelWidth, "BPS", settings.bps(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 5, panelWidth, "SINGLE ROW", settings.singleRow(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 6, panelWidth, "POTIONS", settings.potions(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 7, panelWidth, "KEYBINDS", settings.keybinds(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 8, panelWidth, "PANEL ICONS",
                settings.panelIcons(), mouseX, mouseY);
        drawHueSlider(graphics, x, y + ROW_HEIGHT * 9, panelWidth, "PANEL ICON COLOR",
                settings.panelIconColorHex(), settings.panelIconColor(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 10, panelWidth, "PANEL ICON RAINBOW",
                settings.panelIconRainbow(), mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT * 11, panelWidth, "KEYBINDS X %",
                settings.keybindPositionX(), HudSettings.MIN_POSITION, HudSettings.MAX_POSITION, mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT * 12, panelWidth, "KEYBINDS Y %",
                settings.keybindPositionY(), HudSettings.MIN_POSITION, HudSettings.MAX_POSITION, mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT * 13, panelWidth, "POTIONS X %",
                settings.potionPositionX(), HudSettings.MIN_POSITION, HudSettings.MAX_POSITION, mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT * 14, panelWidth, "POTIONS Y %",
                settings.potionPositionY(), HudSettings.MIN_POSITION, HudSettings.MAX_POSITION, mouseX, mouseY);
    }

    private void drawItemInfoSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        GuiTheme.inset(graphics, x, y, panelWidth, ITEM_INFO_SETTINGS_ROWS * ROW_HEIGHT);
        ItemInfoModule settings = DonutUtilitiesClient.MODULES.itemInfoModule();
        drawHueSlider(graphics, x, y, panelWidth, "TEXT COLOR",
                settings.textColorHex(), settings.textColor(), mouseX, mouseY);
        drawHueSlider(graphics, x, y + ROW_HEIGHT, panelWidth, "AMOUNT COLOR",
                settings.amountColorHex(), settings.amountColor(), mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT * 2, panelWidth, "HEIGHT", settings.height(),
                ItemInfoModule.MIN_HEIGHT, ItemInfoModule.MAX_HEIGHT, mouseX, mouseY);
    }

    private void drawPlayerInfoSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        PlayerInfoSettings settings = DonutUtilitiesClient.MODULES.playerInfoSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, PLAYER_INFO_SETTINGS_ROWS * ROW_HEIGHT);
        drawSlider(graphics, x, y, panelWidth, "SCALE %", settings.scale(),
                PlayerInfoSettings.MIN_SCALE, PlayerInfoSettings.MAX_SCALE, mouseX, mouseY);

        int colorY = y + ROW_HEIGHT;
        drawHueSlider(graphics, x, colorY, panelWidth, "NICK COLOR",
                settings.nickColorHex(), settings.nickColor(), mouseX, mouseY);
        drawInfoRow(graphics, x, y + ROW_HEIGHT * 2, panelWidth, "ITEMS POSITION",
                settings.itemsBelowHealth() ? "BOTTOM" : "TOP", mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 3, panelWidth, "CUSTOM FONT",
                settings.customFont(), mouseX, mouseY);
    }

    private void drawModuleListSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        ModuleListSettings settings = DonutUtilitiesClient.MODULES.moduleListSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, MODULE_LIST_SETTINGS_ROWS * ROW_HEIGHT);

        drawHueSlider(graphics, x, y, panelWidth, "TEXT COLOR",
                settings.textColorHex(), settings.textColor(), mouseX, mouseY);

        int rainbowY = y + ROW_HEIGHT;
        drawCheckbox(graphics, x, rainbowY, panelWidth, "RAINBOW", settings.rainbow(), mouseX, mouseY);
    }

    private void drawVisualsSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        VisualsSettings settings = DonutUtilitiesClient.MODULES.visualsSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, VISUALS_SETTINGS_ROWS * ROW_HEIGHT);
        drawHueSlider(graphics, x, y, panelWidth, "ACCENT COLOR",
                settings.accentColorHex(), settings.accentColor(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT, panelWidth, "RAINBOW", settings.rainbow(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 2, panelWidth, "NC LOGO", settings.watermarkLogo(), mouseX, mouseY);
        drawHueSlider(graphics, x, y + ROW_HEIGHT * 3, panelWidth, "WATERMARK COLOR",
                settings.watermarkColorHex(), settings.watermarkColor(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 4, panelWidth, "WATERMARK RAINBOW",
                settings.watermarkRainbow(), mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT * 5, panelWidth, "TRANSPARENCY",
                settings.watermarkTransparency(), VisualsSettings.MIN_WATERMARK_TRANSPARENCY,
                VisualsSettings.MAX_WATERMARK_TRANSPARENCY, mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT * 6, panelWidth, "POSITION X %",
                settings.watermarkPositionX(), VisualsSettings.MIN_WATERMARK_POSITION,
                VisualsSettings.MAX_WATERMARK_POSITION, mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT * 7, panelWidth, "POSITION Y %",
                settings.watermarkPositionY(), VisualsSettings.MIN_WATERMARK_POSITION,
                VisualsSettings.MAX_WATERMARK_POSITION, mouseX, mouseY);
        drawHueSlider(graphics, x, y + ROW_HEIGHT * 8, panelWidth, "HUD ICON COLOR",
                settings.hudIconColorHex(), settings.hudIconColor(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 9, panelWidth, "HUD ICON RAINBOW",
                settings.hudIconRainbow(), mouseX, mouseY);
    }

    private void drawMenuScaleSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        MenuScaleSettings settings = DonutUtilitiesClient.MODULES.menuScaleSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, MENU_SCALE_SETTINGS_ROWS * ROW_HEIGHT);
        drawSlider(graphics, x, y, panelWidth, "GUI SCALE %", displayedMenuScalePercent(),
                MenuScaleSettings.MIN_PERCENT, MenuScaleSettings.MAX_PERCENT, mouseX, mouseY);
    }

    private void drawPopupSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        PopupSettings settings = DonutUtilitiesClient.MODULES.popupSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, POPUP_SETTINGS_ROWS * ROW_HEIGHT);
        drawInfoRow(graphics, x, y, panelWidth, "LOCATION", settings.position().displayName(), mouseX, mouseY);
    }

    private void drawDonutRegionSettings(GuiGraphics graphics, int x, int y, int mouseX, int mouseY,
            int panelWidth) {
        DonutRegionSettings settings = DonutUtilitiesClient.MODULES.donutRegionSettings();
        GuiTheme.inset(graphics, x, y, panelWidth, DONUT_REGION_SETTINGS_ROWS * ROW_HEIGHT);
        drawSlider(graphics, x, y, panelWidth, "POSITION X %", settings.positionX(),
                DonutRegionSettings.MIN_POSITION, DonutRegionSettings.MAX_POSITION, mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT, panelWidth, "POSITION Y %", settings.positionY(),
                DonutRegionSettings.MIN_POSITION, DonutRegionSettings.MAX_POSITION, mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT * 2, panelWidth, "CELL SIZE", settings.cellSize(),
                DonutRegionSettings.MIN_CELL_SIZE, DonutRegionSettings.MAX_CELL_SIZE, mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT * 3, panelWidth, "TRANSPARENCY", settings.transparency(),
                DonutRegionSettings.MIN_TRANSPARENCY, DonutRegionSettings.MAX_TRANSPARENCY, mouseX, mouseY);
        drawSlider(graphics, x, y + ROW_HEIGHT * 4, panelWidth, "LABEL SIZE %", settings.labelScale(),
                DonutRegionSettings.MIN_LABEL_SCALE, DonutRegionSettings.MAX_LABEL_SCALE, mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 5, panelWidth, "COORDINATES",
                settings.coordinates(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 6, panelWidth, "REGION LABELS",
                settings.regionLabels(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 7, panelWidth, "MAP GRID",
                settings.grid(), mouseX, mouseY);
        drawCheckbox(graphics, x, y + ROW_HEIGHT * 8, panelWidth, "PLAYER INDICATOR",
                settings.playerIndicator(), mouseX, mouseY);
        drawInfoRow(graphics, x, y + ROW_HEIGHT * 9, panelWidth, "FONT",
                settings.fontMode().displayName(), mouseX, mouseY);
    }

    private void drawInfoRow(GuiGraphics graphics, int x, int y, int panelWidth, String label, String value, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + panelWidth && mouseY >= y && mouseY <= y + ROW_HEIGHT;
        drawRowBackground(graphics, x, y, panelWidth, hovered);
        drawHdText(graphics, fitText(label, panelWidth - 60), x + 12, y + 8, TEXT);
        drawHdText(graphics, fitText(value, 48), x + panelWidth - 58, y + 8, BLUE);
    }

    private void drawBlockInput(GuiGraphics graphics, int x, int y, int panelWidth, String value, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + panelWidth && mouseY >= y && mouseY <= y + ROW_HEIGHT;
        drawRowBackground(graphics, x, y, panelWidth, hovered);
        String text = value.isBlank() && !blockInputFocused ? "minecraft:block_id" : value + (blockInputFocused && (System.currentTimeMillis() / 450L) % 2L == 0L ? "_" : "");
        int color = value.isBlank() && !blockInputFocused ? GuiTheme.DISABLED : TEXT;
        drawHdText(graphics, "ID", x + 12, y + 8, BLUE);
        drawHdText(graphics, fitText(text, panelWidth - 48), x + 34, y + 8, color);
    }

    private void drawSlider(GuiGraphics graphics, int x, int y, int panelWidth, String label, int value, int min, int max, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + panelWidth && mouseY >= y && mouseY <= y + ROW_HEIGHT;
        drawRowBackground(graphics, x, y, panelWidth, hovered);
        int trackStart = x + 12;
        int trackEnd = x + panelWidth - 12;
        int knobX = trackStart + Math.round((trackEnd - trackStart) * ((float) (value - min) / (float) (max - min)));
        drawRoundedRect(graphics, trackStart, y + ROW_HEIGHT - 6, trackEnd - trackStart, 3, 0xFF2B313A);
        drawRoundedRect(graphics, trackStart, y + ROW_HEIGHT - 6, Math.max(3, knobX - trackStart), 3, BLUE);
        graphics.blit(RenderPipelines.GUI_TEXTURED, SLIDER_KNOB_TEXTURE,
                knobX - 4, y + ROW_HEIGHT - 10, 20.0F, 20.0F,
                8, 8, 200, 200, SLIDER_KNOB_TEXTURE_SIZE, SLIDER_KNOB_TEXTURE_SIZE);
        drawHdText(graphics, fitText(label, panelWidth - 48), x + 12, y + 6, TEXT);
        drawHdText(graphics, Integer.toString(value), x + panelWidth - 29, y + 6, BLUE);
    }

    private void drawHueSlider(GuiGraphics graphics, int x, int y, int panelWidth, String label,
            String hex, int color, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + panelWidth && mouseY >= y && mouseY <= y + ROW_HEIGHT;
        drawRowBackground(graphics, x, y, panelWidth, hovered);
        drawHdText(graphics, fitText(label, panelWidth - 82), x + 12, y + 6, TEXT);
        drawHdText(graphics, hex, x + panelWidth - 12 - GuiTheme.scaledWidth(hex), y + 6, color);

        int trackStart = x + 12;
        int trackWidth = panelWidth - 24;
        int trackY = y + ROW_HEIGHT - 8;
        graphics.pose().pushMatrix();
        graphics.pose().translate(trackStart, trackY);
        graphics.pose().scale(trackWidth / (float) HUE_TEXTURE_WIDTH, 5.0F / HUE_TEXTURE_HEIGHT);
        graphics.blit(RenderPipelines.GUI_TEXTURED, HUE_TEXTURE, 0, 0, 0.0F, 0.0F,
                HUE_TEXTURE_WIDTH, HUE_TEXTURE_HEIGHT, HUE_TEXTURE_WIDTH, HUE_TEXTURE_HEIGHT);
        graphics.pose().popMatrix();

        int red = color >> 16 & 0xFF;
        int green = color >> 8 & 0xFF;
        int blue = color & 0xFF;
        int knobX = trackStart + Math.round(trackWidth * colorSliderPosition(red, green, blue));
        graphics.blit(RenderPipelines.GUI_TEXTURED, SLIDER_KNOB_WHITE_TEXTURE,
                knobX - 4, trackY - 2, 20.0F, 20.0F,
                8, 8, 200, 200, SLIDER_KNOB_TEXTURE_SIZE, SLIDER_KNOB_TEXTURE_SIZE);
    }

    private void drawCheckbox(GuiGraphics graphics, int x, int y, int panelWidth, String label, boolean checked, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + panelWidth && mouseY >= y && mouseY <= y + ROW_HEIGHT;
        drawRowBackground(graphics, x, y, panelWidth, hovered);
        float target = checked ? 1.0F : 0.0F;
        float amount = checkboxAmounts.computeIfAbsent(label, ignored -> target);
        amount += (target - amount) * 0.28F;
        if (Math.abs(target - amount) < 0.01F) {
            amount = target;
        }
        checkboxAmounts.put(label, amount);

        drawAnimatedCheckbox(graphics, x + 13, y + 11, amount);
        drawHdText(graphics, fitText(label, panelWidth - 34), x + 23, y + 6, TEXT);
    }

    private void drawAnimatedCheckbox(GuiGraphics graphics, int centerX, int centerY, float amount) {
        float transition = 1.0F - Math.abs(amount * 2.0F - 1.0F);
        Identifier texture = amount >= 0.5F ? CHECKBOX_CHECKED_TEXTURE : CHECKBOX_UNCHECKED_TEXTURE;
        int size = Math.max(8, Math.round(11.0F - transition * 2.0F));
        int drawX = centerX - size / 2;
        int drawY = centerY - size / 2;
        graphics.blit(RenderPipelines.GUI_TEXTURED, texture, drawX, drawY, 0.0F, 0.0F,
                size, size, CHECKBOX_TEXTURE_SIZE, CHECKBOX_TEXTURE_SIZE,
                CHECKBOX_TEXTURE_SIZE, CHECKBOX_TEXTURE_SIZE);
    }

    private void drawSearchPanel(GuiGraphics graphics, int x, int y, int mouseX, int mouseY, int panelWidth) {
        List<Module> results = searchResults();
        int searchBoxHeight = SEARCH_BOX_HEIGHT;
        int height = searchCollapsed ? HEADER_HEIGHT
                : HEADER_HEIGHT + SEARCH_TOP_GAP + searchBoxHeight + SEARCH_RESULTS_GAP + results.size() * ROW_HEIGHT + 8;
        drawHudFrame(graphics, x, y, panelWidth, height);
        drawHudHeader(graphics, x, y, panelWidth, "SEARCH", searchCollapsed);
        if (searchCollapsed) {
            return;
        }

        int inputY = y + HEADER_HEIGHT + SEARCH_TOP_GAP;
        String text = searchText.isEmpty() && !searchFocused ? "SEARCH MODULES" : searchText + (searchFocused && (System.currentTimeMillis() / 450L) % 2L == 0L ? "_" : "");
        GuiTheme.searchBox(graphics, x + 12, inputY, panelWidth - 24, searchBoxHeight, fitText(text, panelWidth - 42));

        int rowY = inputY + searchBoxHeight + SEARCH_RESULTS_GAP;
        boolean firstResult = true;
        for (Module module : results) {
            boolean hovered = mouseX >= x && mouseX <= x + panelWidth && mouseY >= rowY && mouseY <= rowY + ROW_HEIGHT;
            drawModuleRow(graphics, module, x, rowY, panelWidth, hovered, !firstResult);
            firstResult = false;
            rowY += ROW_HEIGHT;
        }
    }

    private List<Module> searchResults() {
        String query = searchText.trim().toLowerCase(Locale.ROOT);
        if (query.isEmpty()) {
            return List.of();
        }
        return DonutUtilitiesClient.MODULES.modules().stream()
                .filter(module -> module.name().toLowerCase(Locale.ROOT).contains(query) || module.id().contains(query))
                .limit(SEARCH_RESULTS)
                .toList();
    }

    private void drawHudFrame(GuiGraphics graphics, int x, int y, int width, int height) {
        GuiTheme.panel(graphics, x, y, width, height);
    }

    private void drawHudHeader(GuiGraphics graphics, int x, int y, int panelWidth, String title, boolean collapsed) {
        GuiTheme.header(graphics, x, y, panelWidth, HEADER_HEIGHT, title, false, collapsed);
    }

    private void drawRowBackground(GuiGraphics graphics, int x, int y, int panelWidth, boolean hovered) {
        RoundedRectRenderer.roundedRect(graphics, x, y, panelWidth, ROW_HEIGHT, 4,
                hovered ? 0xE0444648 : 0x5A000000);
    }

    private void drawModuleRowBackground(GuiGraphics graphics, String id, int x, int y, int panelWidth, boolean hovered) {
        float current = hoverAmounts.getOrDefault(id, 0.0F);
        float target = hovered ? 1.0F : 0.0F;
        current += (target - current) * 0.24F;
        if (Math.abs(target - current) < 0.01F) {
            current = target;
        }
        if (current <= 0.0F) {
            hoverAmounts.remove(id);
        } else {
            hoverAmounts.put(id, current);
        }

        GuiTheme.row(graphics, x, y, panelWidth, ROW_HEIGHT, current);
    }

    private void drawScanFooter(GuiGraphics graphics) {
        if (!DonutUtilitiesClient.MODULES.enabled("hud")) {
            return;
        }

        Minecraft client = Minecraft.getInstance();
        int footerX = layoutLeft();
        int footerY = virtualHeight() - 76;
        GuiTheme.panel(graphics, footerX, footerY, 420, 54);
        String pos = "No world loaded";
        if (client.player != null) {
            pos = "XYZ " + client.player.blockPosition().getX() + " " + client.player.blockPosition().getY() + " " + client.player.blockPosition().getZ();
        }
        drawHdText(graphics, "SCAN: " + DonutUtilitiesClient.SCANNER.markers().size() + " markers   " + pos, footerX + 10, footerY + 9, ACCENT);
        List<BaseMarker> strongest = DonutUtilitiesClient.SCANNER.strongestMarkers(3);
        int y = footerY + 25;
        for (BaseMarker marker : strongest) {
            drawHdText(graphics, marker.label() + " @ " + marker.pos().toShortString(), footerX + 10, y, MUTED);
            y += 10;
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (settingsOpenProgress < 1.0F) {
            return true;
        }
        double mouseX = virtualX(event.x());
        double mouseY = virtualY(event.y());
        if (event.button() != 0 && event.button() != 1) {
            return super.mouseClicked(event, doubleClick);
        }

        int panelWidth = panelWidth();
        ensurePanelPositions(panelWidth);
        if (handleSearchClick(event, panelWidth)) {
            return true;
        }

        for (ModuleCategory category : ModuleCategory.values()) {
            int[] pos = displayedPanelPosition(category);
            if (event.button() == 0 && inside(mouseX, mouseY,
                    pos[0] + panelWidth - 28, pos[1], 28, HEADER_HEIGHT)) {
                collapsedCategories.put(category, !collapsedCategories.getOrDefault(category, false));
                DonutUtilitiesClient.MODULES.clickGuiLayoutSettings().setCollapsed(
                        category, collapsedCategories.get(category));
                DonutUtilitiesClient.saveConfig();
                return true;
            }
            if (event.button() == 0 && inside(mouseX, mouseY, pos[0], pos[1], panelWidth, HEADER_HEIGHT)) {
                draggingCategory = category;
                dragOffsetX = (int) mouseX - pos[0];
                dragOffsetY = (int) mouseY - pos[1];
                searchFocused = false;
                blockInputFocused = false;
                itemInfoHexFocused = false;
                playerInfoHexFocused = false;
                return true;
            }

            if (handlePanelClick(event, category, pos[0], pos[1], panelWidth)) {
                searchFocused = false;
                return true;
            }
        }

        searchFocused = false;
        blockInputFocused = false;
        itemInfoHexFocused = false;
        playerInfoHexFocused = false;
        return super.mouseClicked(event, doubleClick);
    }

    private boolean handlePanelClick(MouseButtonEvent event, ModuleCategory category, int x, int y, int panelWidth) {
        if (collapsedCategories.getOrDefault(category, false)) {
            return false;
        }
        double mouseX = virtualX(event.x());
        double mouseY = virtualY(event.y());
        int rowY = y + HEADER_HEIGHT;
        for (Module module : DonutUtilitiesClient.MODULES.modules(category)) {
            if (inside(mouseX, mouseY, x, rowY, panelWidth, ROW_HEIGHT)) {
                handleModuleClick(event, module, x, panelWidth);
                return true;
            }
            rowY += ROW_HEIGHT;

            if (module.id().equals(settingsModuleId)) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, ROW_HEIGHT)) {
                    module.startCapturingKey();
                    searchFocused = false;
                    return true;
                }
                rowY += ROW_HEIGHT;
            }

            if (menuScaleSettingsOpen && module.id().equals("menu_scale")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, MENU_SCALE_SETTINGS_ROWS * ROW_HEIGHT)) {
                    handleMenuScaleSettingsClick(mouseX, x, panelWidth);
                    return true;
                }
                rowY += menuScaleSettingsHeight();
            }

            if (popupSettingsOpen && module.id().equals("popup")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, POPUP_SETTINGS_ROWS * ROW_HEIGHT)) {
                    DonutUtilitiesClient.MODULES.popupSettings().cyclePosition();
                    DonutUtilitiesClient.saveConfig();
                    return true;
                }
                rowY += popupSettingsHeight();
            }


            if (donutRegionSettingsOpen && module.id().equals("donut_region_map")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth,
                        DONUT_REGION_SETTINGS_ROWS * ROW_HEIGHT)) {
                    int settingRow = Math.max(0, Math.min(DONUT_REGION_SETTINGS_ROWS - 1,
                            ((int) mouseY - rowY) / ROW_HEIGHT));
                    if (settingRow <= 4) {
                        beginSliderDrag(SliderDrag.DONUT_REGION, settingRow, x, panelWidth);
                        updateActiveSlider(mouseX);
                    } else {
                        DonutRegionSettings settings = DonutUtilitiesClient.MODULES.donutRegionSettings();
                        switch (settingRow) {
                            case 5 -> settings.toggleCoordinates();
                            case 6 -> settings.toggleRegionLabels();
                            case 7 -> settings.toggleGrid();
                            case 8 -> settings.togglePlayerIndicator();
                            case 9 -> settings.cycleFontMode();
                            default -> {
                            }
                        }
                    }
                    DonutUtilitiesClient.saveConfig();
                    return true;
                }
                rowY += donutRegionSettingsHeight();
            }

            if (susSettingsOpen && module.id().equals("sus_chunk_finder")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, SETTINGS_ROWS * ROW_HEIGHT)) {
                    handleSusSettingsClick(mouseX, mouseY, rowY, x, panelWidth);
                    return true;
                }
                rowY += susSettingsHeight();
            }
            if (espSettingsOpen && module.id().equals(espSettingsAnchorId)) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, ESP_SETTINGS_ROWS * ROW_HEIGHT)) {
                    handleEspSettingsClick(mouseX, mouseY, rowY, x, panelWidth);
                    return true;
                }
                rowY += espSettingsHeight();
            }
            if (blockEspSettingsOpen && module.id().equals("block_esp")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, BLOCK_ESP_ROWS * ROW_HEIGHT)) {
                    handleBlockEspSettingsClick(mouseX, mouseY, rowY, x, panelWidth);
                    return true;
                }
                rowY += blockEspSettingsHeight();
            }
            if (freecamSettingsOpen && module.id().equals("freecam")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, FREECAM_SETTINGS_ROWS * ROW_HEIGHT)) {
                    handleFreecamSettingsClick(mouseX, mouseY, rowY, x, panelWidth);
                    return true;
                }
                rowY += freecamSettingsHeight();
            }
            if (swingSpeedSettingsOpen && module.id().equals("swing_speed")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, SWING_SPEED_SETTINGS_ROWS * ROW_HEIGHT)) {
                    handleSwingSpeedSettingsClick(mouseX, x, panelWidth);
                    return true;
                }
                rowY += swingSpeedSettingsHeight();
            }
            if (hudSettingsOpen && module.id().equals("hud")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, HUD_SETTINGS_ROWS * ROW_HEIGHT)) {
                    handleHudSettingsClick(mouseX, mouseY, rowY, x, panelWidth);
                    return true;
                }
                rowY += hudSettingsHeight();
            }
            if (itemInfoSettingsOpen && module.id().equals("item_info")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, ITEM_INFO_SETTINGS_ROWS * ROW_HEIGHT)) {
                    int settingRow = Math.max(0, Math.min(ITEM_INFO_SETTINGS_ROWS - 1,
                            ((int) mouseY - rowY) / ROW_HEIGHT));
                    SliderDrag drag = switch (settingRow) {
                        case 1 -> SliderDrag.ITEM_INFO_AMOUNT_COLOR;
                        case 2 -> SliderDrag.ITEM_INFO_POSITION;
                        default -> SliderDrag.ITEM_INFO_COLOR;
                    };
                    beginSliderDrag(drag, settingRow, x, panelWidth);
                    updateActiveSlider(mouseX);
                    itemInfoHexFocused = false;
                    searchFocused = false;
                    blockInputFocused = false;
                    DonutUtilitiesClient.saveConfig();
                    return true;
                }
                rowY += itemInfoSettingsHeight();
            }
            if (playerInfoSettingsOpen && module.id().equals("player_info")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, PLAYER_INFO_SETTINGS_ROWS * ROW_HEIGHT)) {
                    handlePlayerInfoSettingsClick(mouseX, mouseY, rowY, x, panelWidth);
                    return true;
                }
                rowY += playerInfoSettingsHeight();
            }
            if (moduleListSettingsOpen && module.id().equals("module_list")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, MODULE_LIST_SETTINGS_ROWS * ROW_HEIGHT)) {
                    handleModuleListSettingsClick(mouseX, mouseY, rowY, x, panelWidth);
                    return true;
                }
                rowY += moduleListSettingsHeight();
            }
            if (visualsSettingsOpen && module.id().equals("visuals")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, VISUALS_SETTINGS_ROWS * ROW_HEIGHT)) {
                    handleVisualsSettingsClick(mouseX, mouseY, rowY, x, panelWidth);
                    return true;
                }
                rowY += visualsSettingsHeight();
            }
            if (nameProtectSettingsOpen && module.id().equals("name_protect")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, NAME_PROTECT_SETTINGS_ROWS * ROW_HEIGHT)) {
                    int row = ((int) mouseY - rowY) / ROW_HEIGHT;
                    if (row == 0) {
                        NameProtectSettings settings = DonutUtilitiesClient.MODULES.nameProtectSettings();
                        minecraft.setScreen(new IdentityTextInputScreen(
                                this, "FAKE NAME", settings.fakeName(), settings::setFakeName));
                    } else {
                        DonutUtilitiesClient.MODULES.nameProtectSettings().toggleHideOthers();
                        DonutUtilitiesClient.saveConfig();
                    }
                    return true;
                }
                rowY += NAME_PROTECT_SETTINGS_ROWS * ROW_HEIGHT;
            }
            if (skinProtectSettingsOpen && module.id().equals("skin_protect")) {
                if (inside(mouseX, mouseY, x, rowY, panelWidth, SKIN_PROTECT_SETTINGS_ROWS * ROW_HEIGHT)) {
                    int row = ((int) mouseY - rowY) / ROW_HEIGHT;
                    if (row == 0) {
                        SkinProtectSettings settings = DonutUtilitiesClient.MODULES.skinProtectSettings();
                        minecraft.setScreen(new IdentityTextInputScreen(
                                this, "SKIN OWNER", settings.skinOwner(), settings::setSkinOwner));
                    } else if (row == 1) {
                        DonutUtilitiesClient.MODULES.skinProtectSettings().toggleChangeOwnSkin();
                        DonutUtilitiesClient.saveConfig();
                    } else {
                        DonutUtilitiesClient.MODULES.skinProtectSettings().toggleChangeOthersSkin();
                        DonutUtilitiesClient.saveConfig();
                    }
                    return true;
                }
                rowY += SKIN_PROTECT_SETTINGS_ROWS * ROW_HEIGHT;
            }
        }
        return false;
    }

    private boolean handleSearchClick(MouseButtonEvent event, int panelWidth) {
        double mouseX = virtualX(event.x());
        double mouseY = virtualY(event.y());
        if (event.button() == 0 && inside(mouseX, mouseY,
                searchX + panelWidth - 28, searchY, 28, HEADER_HEIGHT)) {
            searchCollapsed = !searchCollapsed;
            DonutUtilitiesClient.MODULES.clickGuiLayoutSettings().setSearchCollapsed(searchCollapsed);
            DonutUtilitiesClient.saveConfig();
            searchFocused = false;
            return true;
        }
        if (event.button() == 0 && inside(mouseX, mouseY, searchX, searchY, panelWidth, HEADER_HEIGHT)) {
            draggingSearch = true;
            dragOffsetX = (int) mouseX - searchX;
            dragOffsetY = (int) mouseY - searchY;
            blockInputFocused = false;
            return true;
        }

        if (searchCollapsed) {
            return false;
        }

        int inputY = searchY + HEADER_HEIGHT + SEARCH_TOP_GAP;
        int searchBoxHeight = SEARCH_BOX_HEIGHT;
        if (inside(mouseX, mouseY, searchX + 12, inputY, panelWidth - 24, searchBoxHeight)) {
            searchFocused = true;
            blockInputFocused = false;
            itemInfoHexFocused = false;
            playerInfoHexFocused = false;
            moduleListHexFocused = false;
            return true;
        }

        int rowY = inputY + searchBoxHeight + SEARCH_RESULTS_GAP;
        for (Module module : searchResults()) {
            if (inside(mouseX, mouseY, searchX, rowY, panelWidth, ROW_HEIGHT)) {
                handleModuleClick(event, module, searchX, panelWidth);
                searchFocused = true;
                return true;
            }
            rowY += ROW_HEIGHT;
        }
        return false;
    }

    private void handleModuleClick(MouseButtonEvent event, Module module, int panelX, int panelWidth) {
        if (event.button() == 1) {
            toggleModuleSettings(module);
            DonutUtilitiesClient.saveConfig();
            return;
        }
        if (module.id().equals("menu_scale")) {
            menuScaleSettingsOpen = !menuScaleSettingsOpen;
            return;
        }
        boolean clickedSwitch = virtualX(event.x()) >= panelX + panelWidth - 52;
        if (module.id().equals("block_esp") && event.button() == 0 && !clickedSwitch) {
            minecraft.setScreen(new BlockPickerScreen(this));
            return;
        }
        if (event.button() == 0) {
            module.toggle();
            if (module.id().equals("block_esp")) {
                DonutUtilitiesClient.SCANNER.clearType(MarkerType.BLOCK_ESP);
            }
        }
        DonutUtilitiesClient.saveConfig();
    }

    private void toggleModuleSettings(Module module) {
        boolean opening = !module.id().equals(settingsModuleId);
        settingsModuleId = opening ? module.id() : null;
        settingsOpenProgress = opening ? 0.0F : 1.0F;
        susSettingsOpen = false;
        espSettingsOpen = false;
        blockEspSettingsOpen = false;
        freecamSettingsOpen = false;
        swingSpeedSettingsOpen = false;
        hudSettingsOpen = false;
        menuScaleSettingsOpen = false;
        popupSettingsOpen = false;
        itemInfoSettingsOpen = false;
        playerInfoSettingsOpen = false;
        moduleListSettingsOpen = false;
        visualsSettingsOpen = false;
        nameProtectSettingsOpen = false;
        skinProtectSettingsOpen = false;
        donutRegionSettingsOpen = false;
        if (!opening) {
            return;
        }
        switch (module.id()) {
            case "sus_chunk_finder" -> susSettingsOpen = true;
            case "block_esp" -> blockEspSettingsOpen = true;
            case "freecam" -> freecamSettingsOpen = true;
            case "swing_speed" -> swingSpeedSettingsOpen = true;
            case "hud" -> hudSettingsOpen = true;
            case "menu_scale" -> menuScaleSettingsOpen = true;
            case "popup" -> popupSettingsOpen = true;
            case "item_info" -> itemInfoSettingsOpen = true;
            case "player_info" -> playerInfoSettingsOpen = true;
            case "module_list" -> moduleListSettingsOpen = true;
            case "visuals" -> visualsSettingsOpen = true;
            case "name_protect" -> nameProtectSettingsOpen = true;
            case "skin_protect" -> skinProtectSettingsOpen = true;
            case "donut_region_map" -> donutRegionSettingsOpen = true;
            default -> {
                if (isEspSettingsModule(module)) {
                    espSettingsOpen = true;
                    espSettingsAnchorId = module.id();
                }
            }
        }
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        int mouseX = (int) virtualX(event.x());
        int mouseY = (int) virtualY(event.y());
        if (activeSlider != null && event.button() == 0) {
            updateActiveSlider(mouseX);
            return true;
        }
        if (draggingCategory != null) {
            int nextX = clamp(mouseX - dragOffsetX, 0, Math.max(0, virtualWidth() - panelWidth()));
            int nextY = clamp(mouseY - dragOffsetY, 0, Math.max(0, virtualHeight() - HEADER_HEIGHT));
            panelPositions.put(draggingCategory, new int[] {nextX, nextY});
            DonutUtilitiesClient.MODULES.clickGuiLayoutSettings().setPosition(draggingCategory, nextX, nextY);
            return true;
        }
        if (draggingSearch) {
            searchX = clamp(mouseX - dragOffsetX, 0, Math.max(0, virtualWidth() - panelWidth()));
            searchY = clamp(mouseY - dragOffsetY, 0, Math.max(0, virtualHeight() - HEADER_HEIGHT));
            DonutUtilitiesClient.MODULES.clickGuiLayoutSettings().setSearchPosition(searchX, searchY);
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        boolean layoutChanged = draggingCategory != null || draggingSearch;
        if (activeSlider != null) {
            updateActiveSlider(virtualX(event.x()));
            if (activeSlider == SliderDrag.MENU_SCALE && pendingMenuScalePercent != null) {
                DonutUtilitiesClient.MODULES.menuScaleSettings().setPercent(pendingMenuScalePercent);
                pendingMenuScalePercent = null;
            }
            activeSlider = null;
            activeSliderModuleId = null;
            DonutUtilitiesClient.saveConfig();
        }
        draggingCategory = null;
        draggingSearch = false;
        if (layoutChanged) {
            saveLayoutState();
            DonutUtilitiesClient.saveConfig();
        }
        return super.mouseReleased(event);
    }

    private void saveLayoutState() {
        ClickGuiLayoutSettings layout = DonutUtilitiesClient.MODULES.clickGuiLayoutSettings();
        for (ModuleCategory category : ModuleCategory.values()) {
            int[] position = panelPositions.get(category);
            if (position != null) {
                layout.setPosition(category, position[0], position[1]);
            }
            layout.setCollapsed(category, collapsedCategories.getOrDefault(category, false));
        }
        if (searchPositionInitialized) {
            layout.setSearchPosition(searchX, searchY);
        }
        layout.setSearchCollapsed(searchCollapsed);
    }

    private int[] displayedPanelPosition(ModuleCategory category) {
        int[] target = panelPositions.get(category);
        if (target == null) return new int[] {0, 0};
        float[] displayed = displayedPanelPositions.computeIfAbsent(category,
                ignored -> new float[] {target[0], target[1]});
        float smoothing = category == draggingCategory ? 0.42F : 0.30F;
        displayed[0] += (target[0] - displayed[0]) * smoothing;
        displayed[1] += (target[1] - displayed[1]) * smoothing;
        if (Math.abs(target[0] - displayed[0]) < 0.1F) displayed[0] = target[0];
        if (Math.abs(target[1] - displayed[1]) < 0.1F) displayed[1] = target[1];
        return new int[] {Math.round(displayed[0]), Math.round(displayed[1])};
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (!searchFocused || !event.isAllowedChatCharacter()) {
            if (blockInputFocused && event.isAllowedChatCharacter()) {
                DonutUtilitiesClient.MODULES.blockEspSettings().appendCustomChar(event.codepointAsString());
                DonutUtilitiesClient.SCANNER.clearType(MarkerType.BLOCK_ESP);
                return true;
            }
            if (itemInfoHexFocused && event.isAllowedChatCharacter()) {
                DonutUtilitiesClient.MODULES.itemInfoModule().appendTextColorChar(event.codepointAsString());
                DonutUtilitiesClient.saveConfig();
                return true;
            }
            if (playerInfoHexFocused && event.isAllowedChatCharacter()) {
                DonutUtilitiesClient.MODULES.playerInfoSettings().appendNickColorChar(event.codepointAsString());
                DonutUtilitiesClient.saveConfig();
                return true;
            }
            if (moduleListHexFocused && event.isAllowedChatCharacter()) {
                DonutUtilitiesClient.MODULES.moduleListSettings().appendTextColorChar(event.codepointAsString());
                DonutUtilitiesClient.saveConfig();
                return true;
            }
            return super.charTyped(event);
        }
        if (searchText.length() < 32) {
            searchText += event.codepointAsString();
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        for (Module module : DonutUtilitiesClient.MODULES.modules()) {
            if (module.capturingKey()) {
                module.setKeyCode(event.key());
                DonutUtilitiesClient.saveConfig();
                return true;
            }
        }
        if (searchFocused) {
            if (event.key() == GLFW.GLFW_KEY_BACKSPACE && !searchText.isEmpty()) {
                searchText = searchText.substring(0, searchText.length() - 1);
                return true;
            }
            if (event.key() == GLFW.GLFW_KEY_ESCAPE || event.key() == GLFW.GLFW_KEY_ENTER) {
                searchFocused = false;
                return true;
            }
        }
        if (blockInputFocused) {
            if (event.key() == GLFW.GLFW_KEY_BACKSPACE) {
                boolean changed = DonutUtilitiesClient.MODULES.blockEspSettings().removeLastCustomChar();
                if (changed) {
                    DonutUtilitiesClient.SCANNER.clearType(MarkerType.BLOCK_ESP);
                }
                return changed;
            }
            if (event.key() == GLFW.GLFW_KEY_ESCAPE || event.key() == GLFW.GLFW_KEY_ENTER) {
                blockInputFocused = false;
                return true;
            }
        }
        if (itemInfoHexFocused) {
            if (event.key() == GLFW.GLFW_KEY_BACKSPACE) {
                boolean changed = DonutUtilitiesClient.MODULES.itemInfoModule().removeLastTextColorChar();
                if (changed) {
                    DonutUtilitiesClient.saveConfig();
                }
                return changed;
            }
            if (event.key() == GLFW.GLFW_KEY_ESCAPE || event.key() == GLFW.GLFW_KEY_ENTER) {
                itemInfoHexFocused = false;
                DonutUtilitiesClient.saveConfig();
                return true;
            }
        }
        if (playerInfoHexFocused) {
            if (event.key() == GLFW.GLFW_KEY_BACKSPACE) {
                boolean changed = DonutUtilitiesClient.MODULES.playerInfoSettings().removeLastNickColorChar();
                if (changed) {
                    DonutUtilitiesClient.saveConfig();
                }
                return changed;
            }
            if (event.key() == GLFW.GLFW_KEY_ESCAPE || event.key() == GLFW.GLFW_KEY_ENTER) {
                playerInfoHexFocused = false;
                DonutUtilitiesClient.saveConfig();
                return true;
            }
        }
        if (moduleListHexFocused) {
            if (event.key() == GLFW.GLFW_KEY_BACKSPACE) {
                boolean changed = DonutUtilitiesClient.MODULES.moduleListSettings().removeLastTextColorChar();
                if (changed) {
                    DonutUtilitiesClient.saveConfig();
                }
                return changed;
            }
            if (event.key() == GLFW.GLFW_KEY_ESCAPE || event.key() == GLFW.GLFW_KEY_ENTER) {
                moduleListHexFocused = false;
                DonutUtilitiesClient.saveConfig();
                return true;
            }
        }
        return super.keyPressed(event);
    }

    private void beginSliderDrag(SliderDrag slider, int row, int x, int panelWidth) {
        activeSlider = slider;
        activeSliderRow = row;
        activeSliderX = x;
        activeSliderWidth = panelWidth;
        activeSliderModuleId = slider == SliderDrag.ESP ? espSettingsAnchorId : null;
    }

    private void updateActiveSlider(double mouseX) {
        int value = sliderValue(mouseX, activeSliderX, activeSliderWidth);
        switch (activeSlider) {
            case SUS -> {
                SusChunkSettings settings = DonutUtilitiesClient.MODULES.susChunkSettings();
                switch (activeSliderRow) {
                    case 0 -> settings.setSimulationDistance(2 + Math.round(value / 100.0f * 10));
                    case 1 -> settings.setSensitivity(1 + Math.round(value / 100.0f * 9));
                    case 2 -> settings.setAlpha(10 + Math.round(value / 100.0f * 90));
                    case 3 -> settings.setMinimumSuspiciousBlocks(Math.round(value / 100.0f * 64));
                    default -> {
                    }
                }
            }
            case ESP -> {
                EspSettings settings = DonutUtilitiesClient.MODULES.espSettings();
                String moduleId = activeSliderModuleId == null ? espSettingsAnchorId : activeSliderModuleId;
                switch (activeSliderRow) {
                    case 3 -> settings.setTraceDistance(32 + Math.round(value / 100.0f * 992));
                    case 4 -> settings.setTraceAlpha(15 + Math.round(value / 100.0f * 85));
                    case 5 -> {
                        int rgb = sliderColor(value);
                        settings.setTraceColor(moduleId, rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF);
                    }
                    default -> {
                    }
                }
            }
            case FREECAM -> DonutUtilitiesClient.MODULES.freecamModule().setSpeed(
                    FreecamModule.MIN_SPEED + Math.round(value / 100.0f * (FreecamModule.MAX_SPEED - FreecamModule.MIN_SPEED)));
            case SWING_SPEED -> DonutUtilitiesClient.MODULES.swingSpeedSettings().setSpeed(
                    SwingSpeedSettings.MIN_SPEED + Math.round(value / 100.0f
                            * (SwingSpeedSettings.MAX_SPEED - SwingSpeedSettings.MIN_SPEED)));
            case MENU_SCALE -> {
                int range = MenuScaleSettings.MAX_PERCENT - MenuScaleSettings.MIN_PERCENT;
                pendingMenuScalePercent = MenuScaleSettings.MIN_PERCENT
                        + Math.round(value / 100.0F * range);
            }
            case PLAYER_INFO_SCALE -> {
                int range = PlayerInfoSettings.MAX_SCALE - PlayerInfoSettings.MIN_SCALE;
                DonutUtilitiesClient.MODULES.playerInfoSettings().setScale(
                        PlayerInfoSettings.MIN_SCALE + Math.round(value / 100.0F * range));
            }
            case ITEM_INFO_COLOR -> DonutUtilitiesClient.MODULES.itemInfoModule().setTextColorHex(hueHex(value));
            case ITEM_INFO_AMOUNT_COLOR -> DonutUtilitiesClient.MODULES.itemInfoModule().setAmountColorHex(hueHex(value));
            case ITEM_INFO_POSITION -> {
                int range = ItemInfoModule.MAX_HEIGHT - ItemInfoModule.MIN_HEIGHT;
                DonutUtilitiesClient.MODULES.itemInfoModule().setHeight(
                        ItemInfoModule.MIN_HEIGHT + Math.round(value / 100.0F * range));
            }
            case PLAYER_INFO_COLOR -> DonutUtilitiesClient.MODULES.playerInfoSettings().setNickColorHex(hueHex(value));
            case MODULE_LIST_COLOR -> DonutUtilitiesClient.MODULES.moduleListSettings().setTextColorHex(hueHex(value));
            case VISUALS_COLOR -> DonutUtilitiesClient.MODULES.visualsSettings().setAccentColorHex(hueHex(value));
            case HUD_PANEL_ICON_COLOR -> DonutUtilitiesClient.MODULES.hudSettings().setPanelIconColorHex(hueHex(value));
            case HUD_KEYBINDS_POSITION -> {
                HudSettings settings = DonutUtilitiesClient.MODULES.hudSettings();
                if (activeSliderRow == 11) {
                    settings.setKeybindPositionX(value);
                } else if (activeSliderRow == 12) {
                    settings.setKeybindPositionY(value);
                }
            }
            case HUD_POTIONS_POSITION -> {
                HudSettings settings = DonutUtilitiesClient.MODULES.hudSettings();
                if (activeSliderRow == 13) {
                    settings.setPotionPositionX(value);
                } else if (activeSliderRow == 14) {
                    settings.setPotionPositionY(value);
                }
            }
            case VISUALS_WATERMARK -> {
                VisualsSettings settings = DonutUtilitiesClient.MODULES.visualsSettings();
                switch (activeSliderRow) {
                    case 3 -> settings.setWatermarkColorHex(hueHex(value));
                    case 5 -> settings.setWatermarkTransparency(
                            VisualsSettings.MIN_WATERMARK_TRANSPARENCY + Math.round(value / 100.0F
                                    * (VisualsSettings.MAX_WATERMARK_TRANSPARENCY
                                    - VisualsSettings.MIN_WATERMARK_TRANSPARENCY)));
                    case 6 -> settings.setWatermarkPositionX(value);
                    case 7 -> settings.setWatermarkPositionY(value);
                    case 8 -> settings.setHudIconColorHex(hueHex(value));
                    default -> {
                    }
                }
            }
            case DONUT_REGION -> {
                DonutRegionSettings settings = DonutUtilitiesClient.MODULES.donutRegionSettings();
                switch (activeSliderRow) {
                    case 0 -> settings.setPositionX(value);
                    case 1 -> settings.setPositionY(value);
                    case 2 -> settings.setCellSize(DonutRegionSettings.MIN_CELL_SIZE + Math.round(value / 100.0F
                            * (DonutRegionSettings.MAX_CELL_SIZE - DonutRegionSettings.MIN_CELL_SIZE)));
                    case 3 -> settings.setTransparency(DonutRegionSettings.MIN_TRANSPARENCY + Math.round(value / 100.0F
                            * (DonutRegionSettings.MAX_TRANSPARENCY - DonutRegionSettings.MIN_TRANSPARENCY)));
                    case 4 -> settings.setLabelScale(DonutRegionSettings.MIN_LABEL_SCALE + Math.round(value / 100.0F
                            * (DonutRegionSettings.MAX_LABEL_SCALE - DonutRegionSettings.MIN_LABEL_SCALE)));
                    default -> {
                    }
                }
            }
        }
    }

    private String hueHex(int sliderValue) {
        int rgb = sliderColor(sliderValue) & 0xFFFFFF;
        return String.format(Locale.ROOT, "#%06X", rgb);
    }

    private int sliderColor(int sliderValue) {
        int value = Math.max(0, Math.min(100, sliderValue));
        if (value <= 94) {
            return Color.HSBtoRGB(value / 94.0F, 1.0F, 1.0F);
        }

        float saturation = (100 - value) / 6.0F;
        return Color.HSBtoRGB(0.0F, Math.max(0.0F, Math.min(1.0F, saturation)), 1.0F);
    }

    private float colorSliderPosition(int red, int green, int blue) {
        float[] hsb = Color.RGBtoHSB(red, green, blue, null);
        if (hsb[1] < 0.98F) {
            return 0.94F + (1.0F - hsb[1]) * 0.06F;
        }
        return hsb[0] * 0.94F;
    }

    private void handleEspSettingsClick(double mouseX, double mouseY, int settingsY, int x, int panelWidth) {
        EspSettings settings = DonutUtilitiesClient.MODULES.espSettings();
        int row = Math.max(0, Math.min(ESP_SETTINGS_ROWS - 1, ((int) mouseY - settingsY) / ROW_HEIGHT));
        int sliderValue = sliderValue(mouseX, x, panelWidth);
        if (row >= 3) {
            beginSliderDrag(SliderDrag.ESP, row, x, panelWidth);
        }
        switch (row) {
            case 0 -> settings.toggleTraces();
            case 1 -> settings.toggleEntityTraces();
            case 2 -> settings.toggleBlockTraces();
            case 3 -> settings.setTraceDistance(32 + Math.round(sliderValue / 100.0f * 992));
            case 4 -> settings.setTraceAlpha(15 + Math.round(sliderValue / 100.0f * 85));
            case 5 -> {
                int rgb = sliderColor(sliderValue);
                settings.setTraceColor(espSettingsAnchorId,
                        rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF);
            }
            default -> {
            }
        }
        DonutUtilitiesClient.saveConfig();
    }

    private boolean isEspSettingsModule(Module module) {
        return module.id().equals("block_entity_debug")
                || module.id().equals("hole_esp")
                || module.id().equals("light_finder")
                || module.id().equals("player_esp")
                || module.id().equals("mob_esp")
                || module.id().equals("storage_esp")
                || module.id().equals("block_esp")
                || module.id().equals("suspicious_esp");
    }

    private void handleBlockEspSettingsClick(double mouseX, double mouseY, int settingsY, int x, int panelWidth) {
        searchFocused = false;
        blockInputFocused = false;
        minecraft.setScreen(new BlockPickerScreen(this));
    }

    private void handleSusSettingsClick(double mouseX, double mouseY, int settingsY, int x, int panelWidth) {
        SusChunkSettings settings = DonutUtilitiesClient.MODULES.susChunkSettings();
        int row = Math.max(0, Math.min(SETTINGS_ROWS - 1, ((int) mouseY - settingsY) / ROW_HEIGHT));
        int sliderValue = sliderValue(mouseX, x, panelWidth);
        if (row <= 3) {
            beginSliderDrag(SliderDrag.SUS, row, x, panelWidth);
        }
        switch (row) {
            case 0 -> settings.setSimulationDistance(2 + Math.round(sliderValue / 100.0f * 10));
            case 1 -> settings.setSensitivity(1 + Math.round(sliderValue / 100.0f * 9));
            case 2 -> settings.setAlpha(10 + Math.round(sliderValue / 100.0f * 90));
            case 3 -> settings.setMinimumSuspiciousBlocks(Math.round(sliderValue / 100.0f * 64));
            case 4 -> settings.toggleSmartAdjustment();
            case 5 -> settings.toggleKelp();
            case 6 -> settings.toggleCaveVines();
            case 7 -> settings.toggleVines();
            case 8 -> settings.toggleAmethyst();
            case 9 -> settings.toggleBamboo();
            case 10 -> settings.toggleBeeNest();
            case 11 -> settings.toggleRotatedDeepslate();
            default -> {
            }
        }
        DonutUtilitiesClient.saveConfig();
    }

    private void handleFreecamSettingsClick(double mouseX, double mouseY, int settingsY, int x, int panelWidth) {
        int row = Math.max(0, Math.min(FREECAM_SETTINGS_ROWS - 1, ((int) mouseY - settingsY) / ROW_HEIGHT));
        if (row == 0) {
            beginSliderDrag(SliderDrag.FREECAM, row, x, panelWidth);
            int sliderValue = sliderValue(mouseX, x, panelWidth);
            DonutUtilitiesClient.MODULES.freecamModule().setSpeed(FreecamModule.MIN_SPEED + Math.round(sliderValue / 100.0f * (FreecamModule.MAX_SPEED - FreecamModule.MIN_SPEED)));
        }
        DonutUtilitiesClient.saveConfig();
    }

    private void handleSwingSpeedSettingsClick(double mouseX, int x, int panelWidth) {
        beginSliderDrag(SliderDrag.SWING_SPEED, 0, x, panelWidth);
        int sliderValue = sliderValue(mouseX, x, panelWidth);
        int speed = SwingSpeedSettings.MIN_SPEED + Math.round(sliderValue / 100.0f
                * (SwingSpeedSettings.MAX_SPEED - SwingSpeedSettings.MIN_SPEED));
        DonutUtilitiesClient.MODULES.swingSpeedSettings().setSpeed(speed);
        DonutUtilitiesClient.saveConfig();
    }

    private void handleHudSettingsClick(double mouseX, double mouseY, int settingsY, int x, int panelWidth) {
        HudSettings settings = DonutUtilitiesClient.MODULES.hudSettings();
        int row = Math.max(0, Math.min(HUD_SETTINGS_ROWS - 1, ((int) mouseY - settingsY) / ROW_HEIGHT));
        switch (row) {
            case 0 -> settings.toggleCoordinates();
            case 1 -> settings.toggleRealTime();
            case 2 -> settings.togglePing();
            case 3 -> settings.toggleTicks();
            case 4 -> settings.toggleBps();
            case 5 -> settings.toggleSingleRow();
            case 6 -> settings.togglePotions();
            case 7 -> settings.toggleKeybinds();
            case 8 -> settings.togglePanelIcons();
            case 9 -> {
                beginSliderDrag(SliderDrag.HUD_PANEL_ICON_COLOR, row, x, panelWidth);
                updateActiveSlider(mouseX);
            }
            case 10 -> settings.togglePanelIconRainbow();
            case 11, 12 -> {
                beginSliderDrag(SliderDrag.HUD_KEYBINDS_POSITION, row, x, panelWidth);
                updateActiveSlider(mouseX);
            }
            case 13, 14 -> {
                beginSliderDrag(SliderDrag.HUD_POTIONS_POSITION, row, x, panelWidth);
                updateActiveSlider(mouseX);
            }
            default -> {
            }
        }
        DonutUtilitiesClient.saveConfig();
    }

    private void handleMenuScaleSettingsClick(double mouseX, int x, int panelWidth) {
        beginSliderDrag(SliderDrag.MENU_SCALE, 0, x, panelWidth);
        int sliderValue = sliderValue(mouseX, x, panelWidth);
        int range = MenuScaleSettings.MAX_PERCENT - MenuScaleSettings.MIN_PERCENT;
        pendingMenuScalePercent = MenuScaleSettings.MIN_PERCENT
                + Math.round(sliderValue / 100.0F * range);
    }

    private void handlePlayerInfoSettingsClick(double mouseX, double mouseY, int settingsY, int x, int panelWidth) {
        PlayerInfoSettings settings = DonutUtilitiesClient.MODULES.playerInfoSettings();
        int row = Math.max(0, Math.min(PLAYER_INFO_SETTINGS_ROWS - 1, ((int) mouseY - settingsY) / ROW_HEIGHT));
        if (row == 0) {
            beginSliderDrag(SliderDrag.PLAYER_INFO_SCALE, row, x, panelWidth);
            int sliderValue = sliderValue(mouseX, x, panelWidth);
            int range = PlayerInfoSettings.MAX_SCALE - PlayerInfoSettings.MIN_SCALE;
            settings.setScale(PlayerInfoSettings.MIN_SCALE + Math.round(sliderValue / 100.0F * range));
            playerInfoHexFocused = false;
        } else if (row == 1) {
            beginSliderDrag(SliderDrag.PLAYER_INFO_COLOR, row, x, panelWidth);
            updateActiveSlider(mouseX);
            playerInfoHexFocused = false;
            searchFocused = false;
            blockInputFocused = false;
            itemInfoHexFocused = false;
        } else if (row == 2) {
            settings.toggleItemsPosition();
            playerInfoHexFocused = false;
        } else {
            settings.toggleCustomFont();
            playerInfoHexFocused = false;
        }
        DonutUtilitiesClient.saveConfig();
    }

    private void handleModuleListSettingsClick(double mouseX, double mouseY, int settingsY, int x, int panelWidth) {
        int row = Math.max(0, Math.min(MODULE_LIST_SETTINGS_ROWS - 1, ((int) mouseY - settingsY) / ROW_HEIGHT));
        if (row == 0) {
            beginSliderDrag(SliderDrag.MODULE_LIST_COLOR, row, x, panelWidth);
            updateActiveSlider(mouseX);
            moduleListHexFocused = false;
            searchFocused = false;
            blockInputFocused = false;
            itemInfoHexFocused = false;
            playerInfoHexFocused = false;
        } else {
            DonutUtilitiesClient.MODULES.moduleListSettings().toggleRainbow();
            moduleListHexFocused = false;
        }
        DonutUtilitiesClient.saveConfig();
    }

    private void handleVisualsSettingsClick(double mouseX, double mouseY, int settingsY, int x, int panelWidth) {
        VisualsSettings settings = DonutUtilitiesClient.MODULES.visualsSettings();
        int row = Math.max(0, Math.min(VISUALS_SETTINGS_ROWS - 1, ((int) mouseY - settingsY) / ROW_HEIGHT));
        if (row == 0) {
            beginSliderDrag(SliderDrag.VISUALS_COLOR, row, x, panelWidth);
            updateActiveSlider(mouseX);
        } else if (row == 1) {
            settings.toggleRainbow();
        } else if (row == 2) {
            settings.toggleWatermarkLogo();
        } else if (row == 4) {
            settings.toggleWatermarkRainbow();
        } else if (row == 9) {
            settings.toggleHudIconRainbow();
        } else {
            beginSliderDrag(SliderDrag.VISUALS_WATERMARK, row, x, panelWidth);
            updateActiveSlider(mouseX);
        }
        DonutUtilitiesClient.saveConfig();
    }

    private int sliderValue(double mouseX, int x, int panelWidth) {
        int trackStart = x + 12;
        int trackEnd = x + panelWidth - 12;
        double clamped = Math.max(trackStart, Math.min(trackEnd, mouseX));
        return (int) Math.round(((clamped - trackStart) / (trackEnd - trackStart)) * 100.0);
    }

    private boolean inside(double mouseX, double mouseY, int x, int y, int w, int h) {
        return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private int layoutLeft() {
        int width = virtualWidth();
        if (width < 1000) {
            return 12;
        }
        if (width < 1400) {
            return 36;
        }
        return BASE_LEFT;
    }

    private int layoutGap() {
        int width = virtualWidth();
        if (width < 1000) {
            return 6;
        }
        if (width < 1400) {
            return 10;
        }
        return BASE_GAP;
    }

    private int defaultSearchRowOffset() {
        return HEADER_HEIGHT + ROW_HEIGHT * 5 + 22;
    }

    private float menuScale() {
        return DonutUtilitiesClient.MODULES.menuScaleSettings().scale();
    }

    private int displayedMenuScalePercent() {
        return pendingMenuScalePercent != null
                ? pendingMenuScalePercent
                : DonutUtilitiesClient.MODULES.menuScaleSettings().percent();
    }

    private int virtualWidth() {
        return Math.max(1, (int) Math.floor(width / menuScale()));
    }

    private int virtualHeight() {
        return Math.max(1, (int) Math.floor(height / menuScale()));
    }

    private double virtualX(double x) {
        return x / menuScale();
    }

    private double virtualY(double y) {
        return y / menuScale();
    }

    private String fitText(String text, int maxWidth) {
        String value = text;
        while (!value.isEmpty() && GuiTheme.scaledWidth(value) > maxWidth) {
            value = value.substring(0, value.length() - 1);
        }
        return value;
    }

    private void drawHdText(GuiGraphics graphics, String text, int x, int y, int color) {
        GuiTheme.text(graphics, text, x, y, color);
    }

    private void drawRoundedRect(GuiGraphics graphics, int x, int y, int width, int height, int color) {
        RoundedRectRenderer.roundedRect(graphics, x, y, width, height, CORNER, color);
    }

}
