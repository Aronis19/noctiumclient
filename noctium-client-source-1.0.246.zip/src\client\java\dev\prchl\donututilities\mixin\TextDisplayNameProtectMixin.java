package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.render.IdentityProtect;
import net.minecraft.client.renderer.entity.DisplayRenderer;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(DisplayRenderer.TextDisplayRenderer.class)
public abstract class TextDisplayNameProtectMixin {
    @ModifyVariable(method = "splitLines", at = @At("HEAD"), argsOnly = true)
    private Component donututilities$protectDisplayText(Component text) {
        return IdentityProtect.protectedText(text);
    }
}
