package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.freecam.FreecamController;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Shadow
    private Minecraft minecraft;

    @Shadow
    private double accumulatedDX;

    @Shadow
    private double accumulatedDY;

    @Inject(method = "turnPlayer", at = @At("HEAD"), cancellable = true)
    private void donututilities$turnFreecamOnly(double deltaTime, CallbackInfo info) {
        if (!FreecamController.active() || minecraft.player == null) {
            return;
        }

        double sensitivity = minecraft.options.sensitivity().get() * 0.6000000238418579D + 0.20000000298023224D;
        double cubic = sensitivity * sensitivity * sensitivity;
        double multiplier = cubic * 8.0D;
        double dx = accumulatedDX * multiplier;
        double dy = accumulatedDY * multiplier;
        if (minecraft.options.invertMouseX().get()) {
            dx = -dx;
        }
        if (minecraft.options.invertMouseY().get()) {
            dy = -dy;
        }

        FreecamController.turn(dx, dy);
        info.cancel();
    }
}
