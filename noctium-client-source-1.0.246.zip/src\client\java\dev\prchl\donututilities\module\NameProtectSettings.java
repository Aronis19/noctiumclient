package dev.prchl.donututilities.module;

public final class NameProtectSettings {
    private String fakeName = "Protected";
    private boolean hideOthers;

    public String fakeName() {
        return fakeName;
    }

    public void setFakeName(String fakeName) {
        String value = sanitize(fakeName);
        if (!value.isBlank()) {
            this.fakeName = value;
        }
    }

    public boolean appendFakeName(String value) {
        if (fakeName.length() >= 16) return false;
        String clean = sanitize(value);
        if (clean.isEmpty()) return false;
        fakeName += clean;
        return true;
    }

    public boolean removeLastFakeNameChar() {
        if (fakeName.isEmpty()) return false;
        fakeName = fakeName.substring(0, fakeName.length() - 1);
        return true;
    }

    public boolean hideOthers() {
        return hideOthers;
    }

    public void toggleHideOthers() {
        hideOthers = !hideOthers;
    }

    private String sanitize(String value) {
        return value == null ? "" : value.replaceAll("[^A-Za-z0-9_]", "");
    }
}
