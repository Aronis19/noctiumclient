package dev.prchl.donututilities.gui;

import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.render.GuiTheme;
import dev.prchl.donututilities.render.shape.RoundedRectRenderer;
import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public final class IdentityTextInputScreen extends Screen {
    private static final int PANEL_WIDTH = 330;
    private static final int PANEL_HEIGHT = 104;
    private final Screen parent;
    private final String heading;
    private final Consumer<String> saver;
    private String value;
    private boolean replaceOnType = true;

    public IdentityTextInputScreen(Screen parent, String heading, String initialValue, Consumer<String> saver) {
        super(Component.literal(heading));
        this.parent = parent;
        this.heading = heading;
        this.value = initialValue == null ? "" : initialValue;
        this.saver = saver;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(graphics);
        graphics.fill(0, 0, width, height, 0x99000000);
        int x = (width - PANEL_WIDTH) / 2;
        int y = (height - PANEL_HEIGHT) / 2;
        RoundedRectRenderer.roundedRect(graphics, x, y, PANEL_WIDTH, PANEL_HEIGHT, 7, 0xF0191B1F);
        graphics.fill(x + 7, y, x + PANEL_WIDTH - 7, y + 1, 0xFF444648);
        graphics.fill(x, y + 27, x + PANEL_WIDTH, y + 28, 0xFF4677FF);

        drawCentered(graphics, heading, x + PANEL_WIDTH / 2, y + 9, 0xFFFFFFFF);
        RoundedRectRenderer.roundedRect(graphics, x + 12, y + 37, PANEL_WIDTH - 24, 24, 5, 0xD9000000);
        graphics.fill(x + 12, y + 37, x + PANEL_WIDTH - 12, y + 38, 0xFF444648);
        String shown = value + ((System.currentTimeMillis() / 450L) % 2L == 0L ? "_" : "");
        GuiTheme.text(graphics, shown, x + 19, y + 44, 0xFFFFFFFF);

        GuiTheme.mutedText(graphics, "PRESS ESCAPE TO CANCEL", x + 12, y + 79);
        drawButton(graphics, x + PANEL_WIDTH - 112, y + 72, 48, 22, "CANCEL", false);
        drawButton(graphics, x + PANEL_WIDTH - 58, y + 72, 46, 22, "SAVE", true);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private void drawButton(GuiGraphics graphics, int x, int y, int width, int height, String text, boolean primary) {
        RoundedRectRenderer.roundedRect(graphics, x, y, width, height, 5,
                primary ? 0xFF4677FF : 0xFF444648);
        drawCentered(graphics, text, x + width / 2, y + 7, 0xFFFFFFFF);
    }

    private void drawCentered(GuiGraphics graphics, String text, int centerX, int y, int color) {
        GuiTheme.text(graphics, text, centerX - GuiTheme.scaledWidth(text) / 2, y, color);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (!event.isAllowedChatCharacter() || value.length() >= 16) return false;
        String clean = event.codepointAsString().replaceAll("[^A-Za-z0-9_]", "");
        if (clean.isEmpty()) return false;
        if (replaceOnType) {
            value = "";
            replaceOnType = false;
        }
        value += clean;
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_BACKSPACE) {
            if (replaceOnType) {
                value = "";
                replaceOnType = false;
            } else if (!value.isEmpty()) {
                value = value.substring(0, value.length() - 1);
            }
            return true;
        }
        if (event.key() == GLFW.GLFW_KEY_ENTER) {
            saveAndClose();
            return true;
        }
        if (event.key() == GLFW.GLFW_KEY_ESCAPE) {
            cancelAndClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        int x = (width - PANEL_WIDTH) / 2;
        int y = (height - PANEL_HEIGHT) / 2;
        if (inside(event.x(), event.y(), x + PANEL_WIDTH - 112, y + 72, 48, 22)) {
            cancelAndClose();
            return true;
        }
        if (inside(event.x(), event.y(), x + PANEL_WIDTH - 58, y + 72, 46, 22)) {
            saveAndClose();
            return true;
        }
        return true;
    }

    @Override
    public void onClose() {
        cancelAndClose();
    }

    private void saveAndClose() {
        if (!value.isBlank()) {
            saver.accept(value);
            DonutUtilitiesClient.saveConfig();
        }
        minecraft.setScreen(parent);
    }

    private void cancelAndClose() {
        minecraft.setScreen(parent);
    }

    private boolean inside(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}
