package dev.prchl.donututilities.render.shape;

import net.minecraft.client.gui.GuiGraphics;

public final class RoundedRectRenderer {
    private RoundedRectRenderer() {
    }

    public static void render(ShapeProperties properties) {
        if (properties.width() <= 0 || properties.height() <= 0) {
            return;
        }

        int thickness = Math.max(0, Math.round(properties.thickness()));
        if (thickness > 0 && alpha(properties.outlineColor()) > 0) {
            roundedRect(properties.graphics(), properties.x(), properties.y(), properties.width(), properties.height(),
                    Math.round(properties.radius()), properties.outlineColor());
        }

        int inset = thickness > 0 ? thickness : 0;
        if (alpha(properties.color()) > 0) {
            roundedRect(properties.graphics(), properties.x() + inset, properties.y() + inset,
                    properties.width() - inset * 2, properties.height() - inset * 2,
                    Math.max(0, Math.round(properties.radius()) - inset), properties.color());
        }
    }

    public static void roundedRect(GuiGraphics graphics, int x, int y, int width, int height, int radius, int color) {
        if (width <= 0 || height <= 0 || alpha(color) <= 0) {
            return;
        }

        int r = Math.min(Math.max(0, radius), Math.min(width, height) / 2);
        if (r <= 0) {
            graphics.fill(x, y, x + width, y + height, color);
            return;
        }

        graphics.fill(x, y + r, x + width, y + height - r, color);
        for (int row = 0; row < r; row++) {
            double exactInset = roundedInsetExact(r, row);
            int inset = Math.max(1, (int) Math.ceil(exactInset));
            int edgeColor = scaleAlpha(color, inset - exactInset);
            graphics.fill(x + inset, y + row, x + width - inset, y + row + 1, color);
            graphics.fill(x + inset, y + height - row - 1, x + width - inset, y + height - row, color);
            graphics.fill(x + inset - 1, y + row, x + inset, y + row + 1, edgeColor);
            graphics.fill(x + width - inset, y + row, x + width - inset + 1, y + row + 1, edgeColor);
            graphics.fill(x + inset - 1, y + height - row - 1, x + inset, y + height - row, edgeColor);
            graphics.fill(x + width - inset, y + height - row - 1,
                    x + width - inset + 1, y + height - row, edgeColor);
        }
    }

    public static void roundedTopRect(GuiGraphics graphics, int x, int y, int width, int height, int radius, int color) {
        if (width <= 0 || height <= 0 || alpha(color) <= 0) {
            return;
        }

        int r = Math.min(Math.max(0, radius), Math.min(width, height + radius) / 2);
        graphics.fill(x, y + r, x + width, y + height, color);
        for (int row = 0; row < r; row++) {
            double exactInset = roundedInsetExact(r, row);
            int inset = Math.max(1, (int) Math.ceil(exactInset));
            int edgeColor = scaleAlpha(color, inset - exactInset);
            graphics.fill(x + inset, y + row, x + width - inset, y + row + 1, color);
            graphics.fill(x + inset - 1, y + row, x + inset, y + row + 1, edgeColor);
            graphics.fill(x + width - inset, y + row, x + width - inset + 1, y + row + 1, edgeColor);
        }
    }

    public static void roundedLeftRect(GuiGraphics graphics, int x, int y, int width, int height, int radius,
            int color) {
        if (width <= 0 || height <= 0 || alpha(color) <= 0) {
            return;
        }
        int r = Math.min(Math.max(0, radius), Math.min(width, height) / 2);
        if (r <= 0) {
            graphics.fill(x, y, x + width, y + height, color);
            return;
        }
        graphics.fill(x, y + r, x + width, y + height - r, color);
        for (int row = 0; row < r; row++) {
            double exactInset = roundedInsetExact(r, row);
            int inset = Math.max(1, (int) Math.ceil(exactInset));
            int edgeColor = scaleAlpha(color, inset - exactInset);
            graphics.fill(x + inset, y + row, x + width, y + row + 1, color);
            graphics.fill(x + inset, y + height - row - 1, x + width, y + height - row, color);
            graphics.fill(x + inset - 1, y + row, x + inset, y + row + 1, edgeColor);
            graphics.fill(x + inset - 1, y + height - row - 1, x + inset, y + height - row, edgeColor);
        }
    }

    private static double roundedInsetExact(int radius, int row) {
        double yOffset = radius - row - 0.5D;
        return radius - Math.sqrt(Math.max(0.0D, radius * radius - yOffset * yOffset));
    }

    private static int scaleAlpha(int color, double coverage) {
        int scaledAlpha = (int) Math.round(alpha(color) * Math.max(0.0D, Math.min(1.0D, coverage)));
        return (scaledAlpha << 24) | (color & 0x00FFFFFF);
    }

    private static int alpha(int color) {
        return color >>> 24;
    }
}
