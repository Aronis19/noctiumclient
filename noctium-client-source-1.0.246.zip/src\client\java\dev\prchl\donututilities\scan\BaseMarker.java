package dev.prchl.donututilities.scan;

import net.minecraft.core.BlockPos;

public record BaseMarker(BlockPos pos, MarkerType type, String label, int color, int score, long seenAtTick) {
}
