package dev.prchl.donututilities.freecam;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class FreecamController {
    private static Vec3 position = Vec3.ZERO;
    private static float yRot;
    private static float xRot;
    private static boolean active;
    private static long lastFrameNanos;

    private FreecamController() {
    }

    public static void enable(Minecraft client) {
        if (client.player == null) {
            active = false;
            return;
        }

        position = new Vec3(client.player.getX(), client.player.getEyeY(), client.player.getZ());
        yRot = client.player.getYRot();
        xRot = client.player.getXRot();
        lastFrameNanos = System.nanoTime();
        active = true;
    }

    public static void disable() {
        active = false;
        lastFrameNanos = 0L;
    }

    public static boolean active() {
        return active;
    }

    public static Vec3 position() {
        return position;
    }

    public static float yRot() {
        return yRot;
    }

    public static float xRot() {
        return xRot;
    }

    public static void tick(Minecraft client, int speedSetting) {
        if (!active || client.player == null || client.level == null) {
            active = false;
            lastFrameNanos = 0L;
            return;
        }
    }

    public static void updateForRender(Minecraft client, float renderYRot, float renderXRot, int speedSetting) {
        if (!active || client.player == null || client.level == null) {
            active = false;
            lastFrameNanos = 0L;
            return;
        }

        long now = System.nanoTime();
        if (lastFrameNanos == 0L) {
            lastFrameNanos = now;
            return;
        }

        double deltaSeconds = Math.min(0.05D, Math.max(0.0D, (now - lastFrameNanos) / 1_000_000_000.0D));
        lastFrameNanos = now;

        double forward = impulse(client.options.keyUp.isDown(), client.options.keyDown.isDown());
        double side = impulse(client.options.keyLeft.isDown(), client.options.keyRight.isDown());
        double vertical = impulse(client.options.keyJump.isDown(), client.options.keyShift.isDown());
        if (forward == 0.0D && side == 0.0D && vertical == 0.0D) {
            return;
        }

        double speed = speedSetting * 2.4D * deltaSeconds;
        if (client.options.keySprint.isDown()) {
            speed *= 2.5D;
        }

        double yawRadians = Math.toRadians(yRot);
        Vec3 forwardVector = new Vec3(-Math.sin(yawRadians), 0.0D, Math.cos(yawRadians));
        Vec3 sideVector = new Vec3(forwardVector.z, 0.0D, -forwardVector.x);
        Vec3 movement = forwardVector.scale(forward).add(sideVector.scale(side)).add(0.0D, vertical, 0.0D);
        if (movement.lengthSqr() > 1.0D) {
            movement = movement.normalize();
        }

        position = position.add(movement.scale(speed));
    }

    public static void turn(double xDelta, double yDelta) {
        if (!active) {
            return;
        }

        xRot = Mth.clamp(xRot + (float) yDelta * 0.15F, -90.0F, 90.0F);
        yRot += (float) xDelta * 0.15F;
    }

    private static double impulse(boolean positive, boolean negative) {
        if (positive == negative) {
            return 0.0D;
        }
        return positive ? 1.0D : -1.0D;
    }
}
