package dev.prchl.donututilities;

import dev.prchl.donututilities.gui.ClickGuiScreen;
import dev.prchl.donututilities.config.ClientConfig;
import dev.prchl.donututilities.module.ModuleManager;
import dev.prchl.donututilities.render.ChunkOverlayRenderer;
import dev.prchl.donututilities.render.ModuleToastManager;
import dev.prchl.donututilities.render.ItemInfoRenderer;
import dev.prchl.donututilities.render.PlayerInfoRenderer;
import dev.prchl.donututilities.scan.ScanManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class DonutUtilitiesClient implements ClientModInitializer {
    public static final String MOD_ID = "donututilities";
    public static final String BUILD = "SMOOTH-HUD-ICONS";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final ModuleManager MODULES = new ModuleManager();
    public static final ScanManager SCANNER = new ScanManager();

    private static final long CONFIG_SAVE_DELAY_MS = 750L;
    private static final long DOUBLE_SHIFT_WINDOW_MS = 360L;
    private static boolean rawMenuKeyWasDown;
    private static long lastRightShiftTapMs;
    private static long lastTickWarningMs;
    private static boolean configReady;
    private static boolean configDirty;
    private static long configDirtyAt;

    @Override
    public void onInitializeClient() {
        MODULES.registerDefaults();
        ClientConfig.load(MODULES);
        configReady = true;
        MODULES.registerKeybinds();
        ChunkOverlayRenderer.register();
        ItemInfoRenderer.register();
        PlayerInfoRenderer.register();

        ClientTickEvents.END_CLIENT_TICK.register(DonutUtilitiesClient::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            flushConfigOnShutdown();
        });
        LOGGER.info("DonutSMP Utilities loaded");
    }

    private static void tick(Minecraft client) {
        long window = client.getWindow().handle();
        boolean rightShiftDown = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        boolean insertDown = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_INSERT) == GLFW.GLFW_PRESS;
        boolean rawMenuKeyDown = rightShiftDown || insertDown;
        if (rawMenuKeyDown && !rawMenuKeyWasDown) {
            if (rightShiftDown && isDoubleRightShift()) {
                openMeteorMenu(client);
            } else {
                toggleMenu(client);
            }
        }
        rawMenuKeyWasDown = rawMenuKeyDown;

        MODULES.tickKeybinds(client);
        MODULES.tick(client);
        ModuleToastManager.tick(MODULES);
        flushConfigIfNeeded();
        try {
            SCANNER.tick(client, MODULES);
        } catch (Throwable exception) {
            SCANNER.clear();
            long now = System.currentTimeMillis();
            if (now - lastTickWarningMs > 5000L) {
                LOGGER.warn("Skipped scanner tick to prevent a client crash", exception);
                lastTickWarningMs = now;
            }
        }
    }

    private static void toggleMenu(Minecraft client) {
        if (client.screen instanceof ClickGuiScreen) {
            client.setScreen(null);
        } else {
            client.setScreen(new ClickGuiScreen());
        }
    }

    private static boolean isDoubleRightShift() {
        long now = System.currentTimeMillis();
        boolean doubled = now - lastRightShiftTapMs <= DOUBLE_SHIFT_WINDOW_MS;
        lastRightShiftTapMs = now;
        return doubled;
    }

    private static void openMeteorMenu(Minecraft client) {
        if (!meteorAndGlazedLoaded()) {
            LOGGER.warn("Meteor ClickGUI requested, but Meteor Client and Glazed addon were not both detected.");
            return;
        }

        Screen screen = createMeteorScreen();
        if (screen == null) {
            LOGGER.warn("Meteor ClickGUI requested, but no compatible Meteor screen API was found.");
            return;
        }
        client.setScreen(screen);
    }

    private static boolean meteorAndGlazedLoaded() {
        FabricLoader loader = FabricLoader.getInstance();
        boolean meteor = loader.isModLoaded("meteor-client") || loader.isModLoaded("meteorclient");
        boolean glazed = loader.isModLoaded("glazed")
                || loader.isModLoaded("glazedaddon")
                || loader.isModLoaded("glazed-addon")
                || loader.getAllMods().stream().anyMatch(container ->
                        container.getMetadata().getId().toLowerCase(java.util.Locale.ROOT).contains("glazed"));
        return meteor && glazed;
    }

    private static Screen createMeteorScreen() {
        Screen themed = createMeteorThemedScreen();
        if (themed != null) {
            return themed;
        }

        return instantiateScreen("meteordevelopment.meteorclient.gui.screens.ClickGuiScreen");
    }

    private static Screen createMeteorThemedScreen() {
        try {
            Class<?> guiThemesClass = Class.forName("meteordevelopment.meteorclient.gui.GuiThemes");
            Object theme = guiThemesClass.getMethod("get").invoke(null);
            if (theme == null) {
                return null;
            }

            Object screen = theme.getClass().getMethod("screen").invoke(theme);
            return screen instanceof Screen meteorScreen ? meteorScreen : null;
        } catch (ReflectiveOperationException | LinkageError exception) {
            return null;
        }
    }

    private static Screen instantiateScreen(String className) {
        try {
            Object screen = Class.forName(className).getDeclaredConstructor().newInstance();
            return screen instanceof Screen meteorScreen ? meteorScreen : null;
        } catch (ReflectiveOperationException | LinkageError exception) {
            return null;
        }
    }

    public static void saveConfig() {
        configDirty = false;
        ClientConfig.save();
    }

    public static void markConfigDirty() {
        if (!configReady) {
            return;
        }
        configDirty = true;
        configDirtyAt = System.currentTimeMillis();
    }

    private static void flushConfigIfNeeded() {
        if (configDirty && System.currentTimeMillis() - configDirtyAt >= CONFIG_SAVE_DELAY_MS) {
            saveConfig();
        }
    }

    private static void flushConfigOnShutdown() {
        if (configDirty) {
            saveConfig();
        }
    }

}

