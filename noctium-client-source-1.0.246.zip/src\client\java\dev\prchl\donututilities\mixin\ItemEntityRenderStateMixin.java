package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.DonutUtilitiesClient;
import net.minecraft.client.renderer.entity.ItemEntityRenderer;
import net.minecraft.client.renderer.entity.state.ItemEntityRenderState;
import net.minecraft.world.entity.item.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntityRenderer.class)
public abstract class ItemEntityRenderStateMixin {
    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/item/ItemEntity;Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;F)V", at = @At("RETURN"))
    private void donututilities$itemInfoNameTag(ItemEntity item, ItemEntityRenderState state, float partialTick, CallbackInfo info) {
        if (!DonutUtilitiesClient.MODULES.enabled("item_info") || item.getItem().isEmpty()) {
            return;
        }

        state.nameTag = null;
        state.nameTagAttachment = null;
    }
}
