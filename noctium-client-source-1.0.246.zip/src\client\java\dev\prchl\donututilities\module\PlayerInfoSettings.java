package dev.prchl.donututilities.module;

import dev.prchl.donututilities.DonutUtilitiesClient;
import java.util.Locale;

public final class PlayerInfoSettings {
    public static final int MIN_SCALE = 50;
    public static final int MAX_SCALE = 175;
    private static final int DEFAULT_NICK_COLOR = 0xFFB8BBC1;

    private int scale = 100;
    private String nickColorHex = "#B8BBC1";
    private int nickColor = DEFAULT_NICK_COLOR;
    private boolean itemsBelowHealth;
    private boolean customFont = true;

    public int scale() {
        return scale;
    }

    public void setScale(int scale) {
        this.scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, scale));
        DonutUtilitiesClient.markConfigDirty();
    }

    public String nickColorHex() {
        return nickColorHex;
    }

    public int nickColor() {
        return nickColor;
    }

    public boolean itemsBelowHealth() {
        return itemsBelowHealth;
    }

    public void toggleItemsPosition() {
        setItemsBelowHealth(!itemsBelowHealth);
    }

    public void setItemsBelowHealth(boolean itemsBelowHealth) {
        this.itemsBelowHealth = itemsBelowHealth;
        DonutUtilitiesClient.markConfigDirty();
    }

    public boolean customFont() {
        return customFont;
    }

    public void toggleCustomFont() {
        customFont = !customFont;
        DonutUtilitiesClient.markConfigDirty();
    }

    public void setNickColorHex(String value) {
        String clean = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
        if (clean.startsWith("#")) {
            clean = clean.substring(1);
        }
        clean = clean.replaceAll("[^0-9A-F]", "");
        if (clean.length() > 6) {
            clean = clean.substring(0, 6);
        }
        nickColorHex = "#" + clean;
        if (clean.length() == 6) {
            try {
                nickColor = 0xFF000000 | Integer.parseInt(clean, 16);
            } catch (NumberFormatException ignored) {
                nickColor = DEFAULT_NICK_COLOR;
            }
        }
        DonutUtilitiesClient.markConfigDirty();
    }

    public void appendNickColorChar(String value) {
        if (value != null && !value.isBlank()) {
            setNickColorHex(nickColorHex + value);
        }
    }

    public boolean removeLastNickColorChar() {
        String clean = nickColorHex.startsWith("#") ? nickColorHex.substring(1) : nickColorHex;
        if (clean.isEmpty()) {
            return false;
        }
        setNickColorHex(clean.substring(0, clean.length() - 1));
        return true;
    }
}
