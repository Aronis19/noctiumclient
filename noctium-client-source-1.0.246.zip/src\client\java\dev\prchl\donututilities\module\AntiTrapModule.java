package dev.prchl.donututilities.module;

public final class AntiTrapModule extends Module {
    public AntiTrapModule() {
        super("anti_trap", "Anti-Trap", ModuleCategory.DONUT,
                "Hides armor stands and signs locally for a clear trap escape view.", 0xFF75E08A);
    }
}
