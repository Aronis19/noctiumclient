package dev.prchl.donututilities.module;

import java.util.Locale;
import net.minecraft.world.item.ItemStack;

public final class ItemInfoModule extends Module {
    public static final String NAMETAG_MARKER = "\uE000";
    public static final int MIN_HEIGHT = 50;
    public static final int MAX_HEIGHT = 250;
    private static final int DEFAULT_TEXT_COLOR = 0xFFE2E4EA;
    private static final int DEFAULT_AMOUNT_COLOR = 0xFF75E08A;
    private String textColorHex = "#E2E4EA";
    private int textColor = DEFAULT_TEXT_COLOR;
    private String amountColorHex = "#75E08A";
    private int amountColor = DEFAULT_AMOUNT_COLOR;
    private int height = 115;

    public ItemInfoModule() {
        super("item_info", "Item Info", ModuleCategory.MISC, "Shows floating item stack labels in the world.", 0xFFB0BEC5);
    }

    public String textColorHex() {
        return textColorHex;
    }

    public int textColor() {
        return textColor;
    }

    public String amountColorHex() {
        return amountColorHex;
    }

    public int amountColor() {
        return amountColor;
    }

    public int height() {
        return height;
    }

    public double heightOffset() {
        return height / 100.0D;
    }

    public void setTextColorHex(String value) {
        String clean = cleanHex(value);
        textColorHex = "#" + clean;
        if (clean.length() == 6) {
            try {
                textColor = 0xFF000000 | Integer.parseInt(clean, 16);
            } catch (NumberFormatException ignored) {
                textColor = DEFAULT_TEXT_COLOR;
            }
        }
    }

    public void setAmountColorHex(String value) {
        String clean = cleanHex(value);
        amountColorHex = "#" + clean;
        if (clean.length() == 6) {
            try {
                amountColor = 0xFF000000 | Integer.parseInt(clean, 16);
            } catch (NumberFormatException ignored) {
                amountColor = DEFAULT_AMOUNT_COLOR;
            }
        }
    }

    public void setHeight(int height) {
        this.height = Math.max(MIN_HEIGHT, Math.min(MAX_HEIGHT, height));
    }

    public void appendTextColorChar(String value) {
        if (value == null || value.isBlank()) {
            return;
        }
        setTextColorHex(textColorHex + value);
    }

    public boolean removeLastTextColorChar() {
        String clean = textColorHex.startsWith("#") ? textColorHex.substring(1) : textColorHex;
        if (clean.isEmpty()) {
            return false;
        }
        setTextColorHex(clean.substring(0, clean.length() - 1));
        return true;
    }

    public static String label(ItemStack stack) {
        String name = stack.getHoverName().getString();
        if (name.isBlank()) {
            name = stack.getItem().toString().toLowerCase(Locale.ROOT);
        }
        return name + " " + stack.getCount() + "x";
    }

    public static String itemName(ItemStack stack) {
        String name = stack.getHoverName().getString();
        return name.isBlank() ? stack.getItem().toString().toLowerCase(Locale.ROOT) : name;
    }

    private static String cleanHex(String value) {
        String clean = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
        if (clean.startsWith("#")) clean = clean.substring(1);
        clean = clean.replaceAll("[^0-9A-F]", "");
        return clean.length() > 6 ? clean.substring(0, 6) : clean;
    }
}
