package dev.prchl.donututilities.scan;

import dev.prchl.donututilities.module.ModuleManager;
import dev.prchl.donututilities.module.SusChunkSettings;
import dev.prchl.donututilities.freecam.FreecamController;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

public final class ScanManager {
    private static final int MAX_MARKERS = 60000;
    private static final int MAX_SCAN_RADIUS_CHUNKS = 96;
    private static final int KEEP_TICKS = 20 * 240;
    private static final int FAST_ESP_KEEP_TICKS = 20 * 180;
    private static final int ESP_KEEP_TICKS = 20 * 180;
    private static final int LIGHT_BLOCK_SCAN_BUDGET = 4096;
    private static final int HEAVY_BLOCK_SCAN_BUDGET = 1024;
    private static final int FAST_BLOCK_ESP_MAX_HITS_PER_CHUNK = 2048;
    private static final int FOCUSED_BLOCK_ESP_MAX_HITS_PER_CHUNK = 16384;
    private static final int ESP_BURST_TICKS = 20 * 3;
    private static final int ESP_BURST_MAX_CHUNKS = 128;
    private static final int ESP_BACKGROUND_MAX_CHUNKS = 24;
    private static final long ESP_BURST_BUDGET_NANOS = 2_500_000L;
    private static final int AUTO_SUS_CANDIDATES_PER_TICK = 1024;
    private static final int AUTO_SUS_MAX_FULL_SCANS_PER_TICK = 4;
    private static final long AUTO_SUS_BUDGET_NANOS = 2_500_000L;
    private static final long AUTO_SUS_RESCAN_TICKS = 20L * 45L;

    private final Map<String, BaseMarker> markers = new HashMap<>();
    private final Map<Long, Set<String>> markerKeysByChunk = new HashMap<>();
    private final Map<Long, Integer> blockScanCursors = new HashMap<>();
    private final Map<Long, Long> automaticSusScans = new HashMap<>();
    private final List<ChunkPos> scanOrder = new ArrayList<>();
    private int scanIndex;
    private int automaticSusScanIndex;
    private long ticks;
    private BlockPos lastPlayerPos;
    private BlockPos lastScanCenter;
    private int lastScanRadius = -1;
    private long lastFocusedBlockEspChunk = Long.MIN_VALUE;
    private long lastOverlayBlockEspChunk = Long.MIN_VALUE;
    private boolean lastBlockEspEnabled;
    private boolean lastStorageEspEnabled;
    private boolean lastLightFinderEnabled;
    private boolean lastAutomaticSusEnabled;
    private int espBurstTicksRemaining;

    public void tick(Minecraft client, ModuleManager modules) {
        ticks++;
        if (client.level == null || client.player == null) {
            clearAllMarkers();
            blockScanCursors.clear();
            automaticSusScans.clear();
            scanOrder.clear();
            lastPlayerPos = null;
            lastScanCenter = null;
            lastBlockEspEnabled = false;
            lastStorageEspEnabled = false;
            lastLightFinderEnabled = false;
            lastAutomaticSusEnabled = false;
            automaticSusScanIndex = 0;
            espBurstTicksRemaining = 0;
            lastOverlayBlockEspChunk = Long.MIN_VALUE;
            return;
        }

        BlockPos playerPos = client.player.blockPosition();
        int clientRenderDistance = client.options.renderDistance().get();
        int scanRadius = Math.max(2, Math.min(MAX_SCAN_RADIUS_CHUNKS,
                Math.max(modules.susChunkSettings().simulationDistance(), clientRenderDistance)));
        BlockPos overlayPos = FreecamController.active()
                ? BlockPos.containing(FreecamController.position())
                : playerPos;
        boolean freecamActive = FreecamController.active();
        // Chunk discovery follows data sent around the real player. Freecam only
        // changes the focused visual ESP origin, matching the 1.0.153 behavior.
        BlockPos scanCenter = playerPos;
        boolean scanOrderChanged = lastScanCenter == null || movedChunk(scanCenter, lastScanCenter)
                || scanRadius != lastScanRadius;
        if (scanOrderChanged) {
            rebuildScanOrder(playerPos, scanRadius);
        }

        if (modules.enabled("rtp_base_finder") && lastPlayerPos != null && playerPos.distSqr(lastPlayerPos) > 250000.0) {
            clearAllMarkers();
            rebuildScanOrder(scanCenter, scanRadius);
        }
        lastPlayerPos = playerPos;
        lastScanCenter = scanCenter;
        lastOverlayBlockEspChunk = freecamActive ? ChunkPos.asLong(overlayPos.getX() >> 4, overlayPos.getZ() >> 4) : Long.MIN_VALUE;
        if (scanOrderChanged || ticks % 10L == 0L) {
            removeOutOfScopeMarkers(client.level, playerPos, clientRenderDistance);
        }
        if (ticks % 40L == 0L) {
            pruneIgnoredChunkFinderMarkers(client.level);
        }

        // Remove visual ESP state immediately when its module is switched off.
        // This runs before the scan-order early return, so old boxes cannot
        // remain visible while the client is between loaded chunks.
        boolean blockEspEnabled = modules.enabled("block_esp");
        boolean storageEspEnabled = modules.enabled("storage_esp");
        boolean lightFinderEnabled = modules.enabled("light_finder");
        if (!blockEspEnabled && lastBlockEspEnabled) {
            clearType(MarkerType.BLOCK_ESP);
            lastFocusedBlockEspChunk = Long.MIN_VALUE;
        }
        if (!storageEspEnabled && lastStorageEspEnabled) {
            clearType(MarkerType.STORAGE);
        }
        if (!lightFinderEnabled && lastLightFinderEnabled) {
            clearType(MarkerType.LIGHT);
        }

        if (scanOrder.isEmpty()) {
            return;
        }

        boolean automaticSusEnabled = modules.enabled("sus_chunk_finder")
                || modules.enabled("prime_chunk_finder") || modules.enabled("seed_chunk_finder");
        if (automaticSusEnabled && !lastAutomaticSusEnabled) {
            automaticSusScans.clear();
            automaticSusScanIndex = 0;
        }
        lastAutomaticSusEnabled = automaticSusEnabled;
        if (automaticSusEnabled) {
            scanAutomaticLoadedSusChunk(client.level, modules);
        }

        boolean espEnabled = blockEspEnabled || storageEspEnabled || lightFinderEnabled;
        if (espEnabled && (scanOrderChanged || blockEspEnabled != lastBlockEspEnabled
                || storageEspEnabled != lastStorageEspEnabled || lightFinderEnabled != lastLightFinderEnabled)) {
            espBurstTicksRemaining = ESP_BURST_TICKS;
        }
        lastBlockEspEnabled = blockEspEnabled;
        lastStorageEspEnabled = storageEspEnabled;
        lastLightFinderEnabled = lightFinderEnabled;

        if (blockEspEnabled) {
            scanFocusedCurrentBlockEsp(client.level, overlayPos, modules);
        }
        if (FreecamController.active() && storageEspEnabled) {
            int freecamChunkX = overlayPos.getX() >> 4;
            int freecamChunkZ = overlayPos.getZ() >> 4;
            if (client.level.hasChunk(freecamChunkX, freecamChunkZ)) {
                scanStorageEsp(client.level, client.level.getChunk(freecamChunkX, freecamChunkZ));
            }
        }
        if (espEnabled) {
            scanEspBurst(client.level, modules, espBurstTicksRemaining > 0 ? ESP_BURST_MAX_CHUNKS : ESP_BACKGROUND_MAX_CHUNKS);
            if (espBurstTicksRemaining > 0) {
                espBurstTicksRemaining--;
            }
        }

        boolean heavyScan = heavyScan(modules);
        if (heavyScan && ticks % 2L != 0L) {
            if (blockEspEnabled) {
                scanFastBlockEspOnly(client.level, modules, 24);
            }
            if (ticks % 20L == 0L) {
                removeExpiredMarkers();
                trimMarkers();
            }
            return;
        }

        int chunksPerTick = blockEspEnabled ? (heavyScan ? 16 : 32) : (heavyScan ? 3 : 8);
        int loadedScans = 0;
        int attempts = 0;
        while (loadedScans < chunksPerTick && attempts < scanOrder.size()) {
            ChunkPos chunkPos = scanOrder.get(scanIndex);
            scanIndex = (scanIndex + 1) % scanOrder.size();
            attempts++;
            if (!client.level.hasChunk(chunkPos.x, chunkPos.z)) {
                continue;
            }
            scanChunk(client.level, chunkPos, modules);
            loadedScans++;
        }

        if (ticks % 20L == 0L) {
            removeExpiredMarkers();
            trimMarkers();
        }
    }

    public List<BaseMarker> markers() {
        return List.copyOf(markers.values());
    }

    public int markerCount() {
        return markers.size();
    }

    public List<BaseMarker> strongestMarkers(int count) {
        return markers.values().stream()
                .sorted(Comparator.comparingInt(BaseMarker::score).reversed())
                .limit(count)
                .toList();
    }

    public void clear() {
        clearAllMarkers();
        blockScanCursors.clear();
        scanOrder.clear();
        automaticSusScans.clear();
        lastPlayerPos = null;
        lastScanRadius = -1;
        scanIndex = 0;
        automaticSusScanIndex = 0;
        lastAutomaticSusEnabled = false;
    }

    public void clearType(MarkerType type) {
        removeMarkersIf(marker -> marker.type() == type);
    }

    private boolean movedChunk(BlockPos current, BlockPos previous) {
        return (current.getX() >> 4) != (previous.getX() >> 4) || (current.getZ() >> 4) != (previous.getZ() >> 4);
    }

    private boolean heavyScan(ModuleManager modules) {
        return modules.enabled("sus_chunk_finder")
                && (modules.enabled("suspicious_esp")
                || modules.enabled("block_esp")
                || modules.enabled("light_finder")
                || modules.enabled("hole_esp")
                || modules.enabled("storage_esp")
                || modules.enabled("block_entity_debug"));
    }

    private void rebuildScanOrder(BlockPos center, int chunkRadius) {
        scanOrder.clear();
        if (blockScanCursors.size() > 65536) {
            blockScanCursors.clear();
        }
        lastScanRadius = chunkRadius;
        int chunkX = center.getX() >> 4;
        int chunkZ = center.getZ() >> 4;

        scanOrder.add(new ChunkPos(chunkX, chunkZ));
        for (int radius = 1; radius <= chunkRadius; radius++) {
            int minX = chunkX - radius;
            int maxX = chunkX + radius;
            int minZ = chunkZ - radius;
            int maxZ = chunkZ + radius;
            for (int x = minX; x <= maxX; x++) {
                scanOrder.add(new ChunkPos(x, minZ));
                scanOrder.add(new ChunkPos(x, maxZ));
            }
            for (int z = minZ + 1; z < maxZ; z++) {
                scanOrder.add(new ChunkPos(minX, z));
                scanOrder.add(new ChunkPos(maxX, z));
            }
        }
        scanIndex = 0;
        automaticSusScanIndex = 0;
        if (automaticSusScans.size() > MAX_SCAN_RADIUS_CHUNKS * MAX_SCAN_RADIUS_CHUNKS * 4) {
            automaticSusScans.clear();
        }
    }

    private void scanAutomaticLoadedSusChunk(ClientLevel level, ModuleManager modules) {
        long deadline = System.nanoTime() + AUTO_SUS_BUDGET_NANOS;
        int candidates = 0;
        int scanned = 0;
        while (candidates < Math.min(AUTO_SUS_CANDIDATES_PER_TICK, scanOrder.size())
                && System.nanoTime() < deadline) {
            ChunkPos chunkPos = scanOrder.get(automaticSusScanIndex);
            automaticSusScanIndex = (automaticSusScanIndex + 1) % scanOrder.size();
            candidates++;
            if (!level.hasChunk(chunkPos.x, chunkPos.z)) {
                continue;
            }

            long chunkKey = chunkPos.toLong();
            long lastScan = automaticSusScans.getOrDefault(chunkKey, Long.MIN_VALUE / 2L);
            if (ticks - lastScan < AUTO_SUS_RESCAN_TICKS) {
                continue;
            }

            scanSusChunkFully(level, level.getChunk(chunkPos.x, chunkPos.z), modules);
            automaticSusScans.put(chunkKey, ticks);
            scanned++;
            if (scanned >= AUTO_SUS_MAX_FULL_SCANS_PER_TICK || System.nanoTime() >= deadline) {
                return;
            }
        }
    }

    private void scanFreecamSusArea(ClientLevel level, BlockPos center, ModuleManager modules) {
        int centerChunkX = center.getX() >> 4;
        int centerChunkZ = center.getZ() >> 4;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                int chunkX = centerChunkX + dx;
                int chunkZ = centerChunkZ + dz;
                if (level.hasChunk(chunkX, chunkZ)) {
                    scanSusChunkFully(level, level.getChunk(chunkX, chunkZ), modules);
                }
            }
        }
    }

    private void scanSusChunkFully(ClientLevel level, LevelChunk chunk, ModuleManager modules) {
        ChunkPos chunkPos = chunk.getPos();
        clearChunkFinderMarkers(chunkPos);
        if (containsSpawnerRoom(chunk) || containsAmethystRoom(chunk)
                || (containsTrialChamber(chunk) || containsMineshaftSignature(chunk) || containsLushCaveSignature(chunk))
                && !hasUndergroundStorage(level, chunk)) {
            return;
        }
        ChunkScore score = new ChunkScore(chunkPos);
        for (Map.Entry<BlockPos, BlockEntity> entry : chunk.getBlockEntities().entrySet()) {
            BlockPos pos = entry.getKey();
            BlockEntity blockEntity = entry.getValue();
            Block block = level.getBlockState(pos).getBlock();
            boolean storageByBlock = isStorageBlock(block);
            boolean storageByEntity = isStorageBlockEntity(blockEntity);
            score.blockEntity();
            if (storageByEntity && !storageByBlock) {
                score.leak();
            }
            if (storageByBlock || storageByEntity) {
                if (pos.getY() < 0) {
                    score.undergroundStorage();
                } else {
                    score.storage();
                }
            }
        }

        SusChunkSettings settings = modules.susChunkSettings();
        LevelChunkSection[] sections = chunk.getSections();
        int minY = Math.max(level.getMinY(), -64);
        int maxY = Math.min(level.getMaxY(), 160);
        int minSectionY = level.getMinSectionY();
        for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
            LevelChunkSection section = sections[sectionIndex];
            int sectionBaseY = (minSectionY + sectionIndex) << 4;
            int sectionTopY = sectionBaseY + 16;
            if (sectionTopY <= minY || sectionBaseY >= maxY || section.hasOnlyAir()
                    || !section.maybeHas(state -> isLightBlock(state.getBlock()) || suspiciousWeight(state, settings) > 0)) {
                continue;
            }

            int localMinY = Math.max(0, minY - sectionBaseY);
            int localMaxY = Math.min(16, maxY - sectionBaseY);
            for (int y = localMinY; y < localMaxY; y++) {
                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        BlockState state = section.getBlockState(x, y, z);
                        if (y + sectionBaseY < 0 && isStorageBlock(state.getBlock())) {
                            score.undergroundStorage();
                        }
                        if (settings.kelp() && isKelp(state.getBlock())) {
                            score.kelp();
                            continue;
                        }
                        if (isLightBlock(state.getBlock())) {
                            score.light();
                        }
                        int weight = suspiciousWeight(state, settings);
                        if (weight > 0 && !isLightBlock(state.getBlock())) {
                            if (y + sectionBaseY < 0) {
                                score.suspicious(weight);
                            }
                        }
                    }
                }
            }
        }

        int centerX = (chunkPos.x << 4) + 8;
        int centerZ = (chunkPos.z << 4) + 8;
        BlockPos center = new BlockPos(centerX, Math.max(level.getMinY() + 4, 64), centerZ);
        int threshold = susThreshold(settings);
        if (modules.enabled("sus_chunk_finder") && isProbableBaseChunk(score, threshold, settings)) {
            put(center, MarkerType.SUS_CHUNK, "Loaded Sus " + score.label(), 0xFFFF5C8A, score.score());
        }
        if (modules.enabled("prime_chunk_finder") && isProbableBaseChunk(score, threshold + 18, settings)) {
            put(center.above(2), MarkerType.PRIME_CHUNK, "Loaded Prime " + score.label(), 0xFFFF7A90, score.score() + 10);
        }
        if (modules.enabled("seed_chunk_finder") && isProbableBaseChunk(score, threshold + 6, settings)) {
            put(center.above(4), MarkerType.SEED_PATTERN, "Loaded Pattern " + score.label(), 0xFF63B3FF, score.score());
        }
    }

    private void scanChunk(ClientLevel level, ChunkPos chunkPos, ModuleManager modules) {
        if (!level.hasChunk(chunkPos.x, chunkPos.z)) {
            return;
        }

        LevelChunk chunk = level.getChunk(chunkPos.x, chunkPos.z);
        clearChunkFinderMarkers(chunkPos);
        if (modules.enabled("block_entity_debug")) {
            clearMarkersInChunk(MarkerType.BLOCK_ENTITY, chunkPos);
        }
        boolean ignoredStructure = containsSpawnerRoom(chunk) || containsAmethystRoom(chunk)
                || ((containsTrialChamber(chunk)
                || containsMineshaftSignature(chunk) || containsLushCaveSignature(chunk))
                && !hasUndergroundStorage(level, chunk));
        ChunkScore score = new ChunkScore(chunkPos);

        if (modules.enabled("block_entity_debug") || modules.enabled("storage_esp") || modules.enabled("sus_chunk_finder") || modules.enabled("prime_chunk_finder")) {
            for (Map.Entry<BlockPos, BlockEntity> entry : chunk.getBlockEntities().entrySet()) {
                BlockPos pos = entry.getKey();
                BlockEntity blockEntity = entry.getValue();
                Block block = level.getBlockState(pos).getBlock();
                boolean storageByBlock = isStorageBlock(block);
                boolean storageByEntity = isStorageBlockEntity(blockEntity);
                if (!ignoredStructure) {
                    score.blockEntity();
                    if (storageByEntity && !storageByBlock) {
                        score.leak();
                    }
                }

                if (storageByBlock || storageByEntity) {
                    if (!ignoredStructure) {
                        if (pos.getY() < 0) {
                            score.undergroundStorage();
                        } else {
                            score.storage();
                        }
                    }
                    if (!ignoredStructure && modules.enabled("storage_esp") && pos.getY() < 0) {
                        put(pos, MarkerType.STORAGE, storageLabel(blockEntity, block),
                                storageByBlock ? storageColor(block) : 0xFFB887FF, 12);
                    }
                }

                if (modules.enabled("block_entity_debug")) {
                    put(pos, MarkerType.BLOCK_ENTITY, entry.getValue().getType().toString(), 0xFF71F5E8, 8);
                }
            }
        }

        boolean scanBlocks = modules.enabled("light_finder") || modules.enabled("hole_esp") || modules.enabled("suspicious_esp")
                || modules.enabled("sus_chunk_finder") || modules.enabled("prime_chunk_finder")
                || modules.enabled("seed_chunk_finder");
        if (scanBlocks) {
            scanBlocks(level, chunkPos, modules, score, !ignoredStructure);
        }
        if (modules.enabled("block_esp")) {
            scanBlockEspFast(level, chunk, modules);
        }

        int centerX = (chunkPos.x << 4) + 8;
        int centerZ = (chunkPos.z << 4) + 8;
        int y = Math.max(level.getMinY() + 4, 64);
        BlockPos center = new BlockPos(centerX, y, centerZ);

        int susThreshold = susThreshold(modules.susChunkSettings());
        if (modules.enabled("sus_chunk_finder") && isProbableBaseChunk(score, susThreshold, modules.susChunkSettings())) {
            put(center, MarkerType.SUS_CHUNK, "Sus Chunk " + score.label(), 0xFFFF5C8A, score.score());
        }
        if (modules.enabled("prime_chunk_finder") && isProbableBaseChunk(score, susThreshold + 18, modules.susChunkSettings())) {
            put(center.above(2), MarkerType.PRIME_CHUNK, "Prime Chunk " + score.label(), 0xFFFF7A90, score.score() + 10);
        }
        if (modules.enabled("seed_chunk_finder") && isProbableBaseChunk(score, susThreshold + 6, modules.susChunkSettings())) {
            put(center.above(4), MarkerType.SEED_PATTERN, "Pattern Chunk " + score.label(), 0xFF63B3FF, score.score());
        }
    }

    private void scanFastBlockEspOnly(ClientLevel level, ModuleManager modules, int chunks) {
        if (scanOrder.isEmpty()) {
            return;
        }

        for (int i = 0; i < chunks; i++) {
            ChunkPos chunkPos = scanOrder.get(scanIndex);
            scanIndex = (scanIndex + 1) % scanOrder.size();
            if (!level.hasChunk(chunkPos.x, chunkPos.z)) {
                continue;
            }

            scanBlockEspFast(level, level.getChunk(chunkPos.x, chunkPos.z), modules);
        }
    }

    private void scanEspBurst(ClientLevel level, ModuleManager modules, int maxChunks) {
        if (scanOrder.isEmpty()) {
            return;
        }

        long deadline = System.nanoTime() + ESP_BURST_BUDGET_NANOS;
        int loadedChunks = 0;
        int attempts = 0;
        while (loadedChunks < maxChunks && attempts < scanOrder.size() && System.nanoTime() < deadline) {
            ChunkPos chunkPos = scanOrder.get(scanIndex);
            scanIndex = (scanIndex + 1) % scanOrder.size();
            attempts++;
            if (!level.hasChunk(chunkPos.x, chunkPos.z)) {
                continue;
            }
            loadedChunks++;

            LevelChunk chunk = level.getChunk(chunkPos.x, chunkPos.z);
            if (modules.enabled("storage_esp")) {
                scanStorageEsp(level, chunk);
            }
            if (modules.enabled("block_esp")) {
                scanBlockEspFast(level, chunk, modules);
            }
            if (modules.enabled("light_finder")) {
                scanLightFinder(level, chunk, 1024);
            }
        }
    }

    private void scanLightFinder(ClientLevel level, LevelChunk chunk, int maxHits) {
        clearMarkersInChunk(MarkerType.LIGHT, chunk.getPos());
        LevelChunkSection[] sections = chunk.getSections();
        int minSectionY = level.getMinSectionY();
        int sourceHits = 0;
        boolean[] lightSections = new boolean[sections.length];

        for (int sectionIndex = 0; sectionIndex < sections.length && sourceHits < maxHits; sectionIndex++) {
            LevelChunkSection section = sections[sectionIndex];
            int sectionBaseY = (minSectionY + sectionIndex) << 4;
            if (section.hasOnlyAir() || !section.maybeHas(state -> isLightBlock(state.getBlock()))) {
                continue;
            }
            lightSections[sectionIndex] = true;

            for (int y = 0; y < 16 && sourceHits < maxHits; y++) {
                for (int x = 0; x < 16 && sourceHits < maxHits; x++) {
                    for (int z = 0; z < 16 && sourceHits < maxHits; z++) {
                        BlockState state = section.getBlockState(x, y, z);
                        if (!isLightBlock(state.getBlock())) {
                            continue;
                        }

                        BlockPos pos = new BlockPos(chunk.getPos().getMinBlockX() + x, sectionBaseY + y,
                                chunk.getPos().getMinBlockZ() + z);
                        put(pos, MarkerType.LIGHT, state.getBlock().getName().getString(), 0xFFFFD25A, 10);
                        sourceHits++;
                    }
                }
            }
        }

        boolean[] volumeSections = new boolean[sections.length];
        for (int index = 0; index < lightSections.length; index++) {
            if (!lightSections[index]) {
                continue;
            }
            volumeSections[index] = true;
            if (index > 0) volumeSections[index - 1] = true;
            if (index + 1 < volumeSections.length) volumeSections[index + 1] = true;
        }

        int volumeHits = 0;
        for (int sectionIndex = 0; sectionIndex < sections.length && volumeHits < maxHits; sectionIndex++) {
            if (!volumeSections[sectionIndex]) {
                continue;
            }
            LevelChunkSection section = sections[sectionIndex];
            int sectionBaseY = (minSectionY + sectionIndex) << 4;
            for (int y = 0; y < 16 && volumeHits < maxHits; y++) {
                for (int x = 0; x < 16 && volumeHits < maxHits; x++) {
                    for (int z = 0; z < 16 && volumeHits < maxHits; z++) {
                        if (!section.getBlockState(x, y, z).isAir()) {
                            continue;
                        }
                        BlockPos pos = new BlockPos(chunk.getPos().getMinBlockX() + x, sectionBaseY + y,
                                chunk.getPos().getMinBlockZ() + z);
                        int lightLevel = level.getBrightness(LightLayer.BLOCK, pos);
                        if (lightLevel < 2) {
                            continue;
                        }
                        put(pos, MarkerType.LIGHT, "$LIGHT_VOLUME", 0xFFFFF01C, lightLevel);
                        volumeHits++;
                    }
                }
            }
        }
    }

    private void scanStorageEsp(ClientLevel level, LevelChunk chunk) {
        clearMarkersInChunk(MarkerType.STORAGE, chunk.getPos());
        for (Map.Entry<BlockPos, BlockEntity> entry : chunk.getBlockEntities().entrySet()) {
            BlockPos pos = entry.getKey();
            if (pos.getY() >= 0) {
                continue;
            }

            Block block = level.getBlockState(pos).getBlock();
            boolean storageByBlock = isStorageBlock(block);
            boolean storageByEntity = isStorageBlockEntity(entry.getValue());
            if (storageByBlock || storageByEntity) {
                put(pos, MarkerType.STORAGE, storageLabel(entry.getValue(), block),
                        storageByBlock ? storageColor(block) : 0xFFB887FF, 12);
            }
        }
    }

    private void scanFocusedCurrentBlockEsp(ClientLevel level, BlockPos playerPos, ModuleManager modules) {
        int chunkX = playerPos.getX() >> 4;
        int chunkZ = playerPos.getZ() >> 4;
        long chunkKey = ChunkPos.asLong(chunkX, chunkZ);
        if (chunkKey == lastFocusedBlockEspChunk && ticks % 20L != 0L) {
            return;
        }
        lastFocusedBlockEspChunk = chunkKey;

        if (level.hasChunk(chunkX, chunkZ)) {
            scanBlockEsp(level, level.getChunk(chunkX, chunkZ), modules, FOCUSED_BLOCK_ESP_MAX_HITS_PER_CHUNK);
        }
    }

    private void scanBlocks(ClientLevel level, ChunkPos chunkPos, ModuleManager modules, ChunkScore score, boolean scoreChunk) {
        BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();
        int minY = Math.max(level.getMinY(), -64);
        int maxY = Math.min(level.getMaxY(), 160);
        int height = Math.max(1, maxY - minY);
        int total = 16 * 16 * height;
        long chunkKey = chunkPos.toLong();
        int cursor = blockScanCursors.getOrDefault(chunkKey, 0);
        int budget = blockScanBudget(modules);

        for (int checked = 0; checked < budget && checked < total; checked++) {
            int index = (cursor + checked) % total;
            int yOffset = index % height;
            int zOffset = (index / height) & 15;
            int xOffset = (index / height / 16) & 15;
            mutable.set(chunkPos.getMinBlockX() + xOffset, minY + yOffset, chunkPos.getMinBlockZ() + zOffset);
            BlockState state = level.getBlockState(mutable);
            Block block = state.getBlock();

            if (scoreChunk && mutable.getY() < 0 && isStorageBlock(block)) {
                score.undergroundStorage();
            }

            if (modules.susChunkSettings().kelp() && isKelp(block)) {
                score.kelp();
                continue;
            }

            if (isLightBlock(block)) {
                if (scoreChunk) {
                    score.light();
                }
                if (modules.enabled("light_finder")) {
                    put(mutable.immutable(), MarkerType.LIGHT, block.getName().getString(), 0xFFFFD25A, 10);
                }
            }

            int suspiciousWeight = suspiciousWeight(state, modules.susChunkSettings());
            if (suspiciousWeight > 0 && !isLightBlock(block)) {
                if (scoreChunk && mutable.getY() < 0) {
                    score.suspicious(suspiciousWeight);
                }
                if (modules.enabled("suspicious_esp") && !isStorageBlock(block) && !isLightBlock(block)) {
                    put(mutable.immutable(), MarkerType.SUSPICIOUS, suspiciousLabel(state, modules.susChunkSettings()), 0xFFB48CFF, suspiciousWeight + 5);
                }
            }

            if (modules.enabled("hole_esp") && isHole(level, mutable)) {
                put(mutable.immutable(), MarkerType.HOLE, "Hole", 0xFF8DE96B, 5);
            }
        }

        blockScanCursors.put(chunkKey, (cursor + budget) % total);
    }

    private int blockScanBudget(ModuleManager modules) {
        if (modules.enabled("hole_esp") || modules.enabled("suspicious_esp")) {
            return HEAVY_BLOCK_SCAN_BUDGET;
        }
        return LIGHT_BLOCK_SCAN_BUDGET;
    }

    private void scanBlockEspFast(ClientLevel level, LevelChunk chunk, ModuleManager modules) {
        scanBlockEsp(level, chunk, modules, FAST_BLOCK_ESP_MAX_HITS_PER_CHUNK);
    }

    private void scanBlockEsp(ClientLevel level, LevelChunk chunk, ModuleManager modules, int maxHits) {
        clearMarkersInChunk(MarkerType.BLOCK_ESP, chunk.getPos());
        if (modules.blockEspSettings().selectedCount() <= 0) {
            return;
        }
        LevelChunkSection[] sections = chunk.getSections();
        int minY = Math.max(level.getMinY(), -64);
        int maxY = Math.min(level.getMaxY(), 0);
        if (minY >= maxY) {
            return;
        }

        int minSectionY = level.getMinSectionY();
        int hits = 0;

        for (int sectionIndex = 0; sectionIndex < sections.length && hits < maxHits; sectionIndex++) {
            LevelChunkSection section = sections[sectionIndex];
            int sectionBaseY = (minSectionY + sectionIndex) << 4;
            int sectionTopY = sectionBaseY + 16;
            if (sectionTopY <= minY || sectionBaseY >= maxY || section.hasOnlyAir()
                    || !section.maybeHas(state -> modules.blockEspSettings().matches(state))) {
                continue;
            }

            int localMinY = Math.max(0, minY - sectionBaseY);
            int localMaxY = Math.min(16, maxY - sectionBaseY);
            for (int y = localMinY; y < localMaxY && hits < maxHits; y++) {
                for (int x = 0; x < 16 && hits < maxHits; x++) {
                    for (int z = 0; z < 16 && hits < maxHits; z++) {
                        BlockState state = section.getBlockState(x, y, z);
                        if (!modules.blockEspSettings().matches(state)) {
                            continue;
                        }

                        BlockPos pos = new BlockPos(chunk.getPos().getMinBlockX() + x, sectionBaseY + y, chunk.getPos().getMinBlockZ() + z);
                        put(pos, MarkerType.BLOCK_ESP, modules.blockEspSettings().label(state), modules.blockEspSettings().color(state), 14);
                        hits++;
                    }
                }
            }
        }
    }

    private boolean isHole(ClientLevel level, BlockPos pos) {
        if (!level.getBlockState(pos).isAir() || !level.getBlockState(pos.above()).isAir()) {
            return false;
        }

        return solid(level, pos.below())
                && solid(level, pos.north())
                && solid(level, pos.south())
                && solid(level, pos.east())
                && solid(level, pos.west());
    }

    private boolean solid(ClientLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return !state.isAir() && state.blocksMotion();
    }

    private boolean isStorageBlock(Block block) {
        return block == Blocks.CHEST
                || block == Blocks.TRAPPED_CHEST
                || block == Blocks.COPPER_CHEST
                || block == Blocks.EXPOSED_COPPER_CHEST
                || block == Blocks.WEATHERED_COPPER_CHEST
                || block == Blocks.OXIDIZED_COPPER_CHEST
                || block == Blocks.WAXED_COPPER_CHEST
                || block == Blocks.WAXED_EXPOSED_COPPER_CHEST
                || block == Blocks.WAXED_WEATHERED_COPPER_CHEST
                || block == Blocks.WAXED_OXIDIZED_COPPER_CHEST
                || block == Blocks.BARREL
                || block == Blocks.ENDER_CHEST
                || block == Blocks.SHULKER_BOX
                || block == Blocks.WHITE_SHULKER_BOX
                || block == Blocks.ORANGE_SHULKER_BOX
                || block == Blocks.MAGENTA_SHULKER_BOX
                || block == Blocks.LIGHT_BLUE_SHULKER_BOX
                || block == Blocks.YELLOW_SHULKER_BOX
                || block == Blocks.LIME_SHULKER_BOX
                || block == Blocks.PINK_SHULKER_BOX
                || block == Blocks.GRAY_SHULKER_BOX
                || block == Blocks.LIGHT_GRAY_SHULKER_BOX
                || block == Blocks.CYAN_SHULKER_BOX
                || block == Blocks.PURPLE_SHULKER_BOX
                || block == Blocks.BLUE_SHULKER_BOX
                || block == Blocks.BROWN_SHULKER_BOX
                || block == Blocks.GREEN_SHULKER_BOX
                || block == Blocks.RED_SHULKER_BOX
                || block == Blocks.BLACK_SHULKER_BOX
                || block == Blocks.HOPPER
                || block == Blocks.FURNACE
                || block == Blocks.BLAST_FURNACE
                || block == Blocks.SMOKER
                || block == Blocks.DISPENSER
                || block == Blocks.DROPPER;
    }

    private boolean isStorageBlockEntity(BlockEntity blockEntity) {
        String id = blockEntity.getType().toString().toLowerCase(java.util.Locale.ROOT);
        return id.contains("chest")
                || id.contains("barrel")
                || id.contains("shulker")
                || id.contains("hopper")
                || id.contains("furnace")
                || id.contains("smoker")
                || id.contains("dispenser")
                || id.contains("dropper");
    }

    private String storageLabel(BlockEntity blockEntity, Block block) {
        if (isStorageBlock(block)) {
            return block.getName().getString();
        }
        String id = blockEntity.getType().toString();
        int slash = id.lastIndexOf(':');
        return slash >= 0 ? "Leaked " + id.substring(slash + 1) : "Leaked Storage";
    }

    private int storageColor(Block block) {
        if (block == Blocks.ENDER_CHEST) {
            return 0xFFB069FF;
        }
        if (block == Blocks.TRAPPED_CHEST) {
            return 0xFFFF8D6B;
        }
        if (isShulkerBlock(block)) {
            return 0xFFB887FF;
        }
        if (block == Blocks.BARREL) {
            return 0xFFD6A45F;
        }
        if (block == Blocks.HOPPER) {
            return 0xFF90A4AE;
        }
        if (block == Blocks.DISPENSER || block == Blocks.DROPPER) {
            return 0xFF81C784;
        }
        if (block == Blocks.FURNACE || block == Blocks.BLAST_FURNACE || block == Blocks.SMOKER) {
            return 0xFFFFB74D;
        }
        return 0xFFE6C55C;
    }

    private boolean isShulkerBlock(Block block) {
        return block == Blocks.SHULKER_BOX
                || block == Blocks.WHITE_SHULKER_BOX
                || block == Blocks.ORANGE_SHULKER_BOX
                || block == Blocks.MAGENTA_SHULKER_BOX
                || block == Blocks.LIGHT_BLUE_SHULKER_BOX
                || block == Blocks.YELLOW_SHULKER_BOX
                || block == Blocks.LIME_SHULKER_BOX
                || block == Blocks.PINK_SHULKER_BOX
                || block == Blocks.GRAY_SHULKER_BOX
                || block == Blocks.LIGHT_GRAY_SHULKER_BOX
                || block == Blocks.CYAN_SHULKER_BOX
                || block == Blocks.PURPLE_SHULKER_BOX
                || block == Blocks.BLUE_SHULKER_BOX
                || block == Blocks.BROWN_SHULKER_BOX
                || block == Blocks.GREEN_SHULKER_BOX
                || block == Blocks.RED_SHULKER_BOX
                || block == Blocks.BLACK_SHULKER_BOX;
    }

    private boolean isLightBlock(Block block) {
        return block == Blocks.TORCH
                || block == Blocks.WALL_TORCH
                || block == Blocks.SOUL_TORCH
                || block == Blocks.SOUL_WALL_TORCH
                || block == Blocks.LANTERN
                || block == Blocks.SOUL_LANTERN
                || block == Blocks.REDSTONE_TORCH
                || block == Blocks.REDSTONE_WALL_TORCH
                || block == Blocks.GLOWSTONE
                || block == Blocks.SEA_LANTERN
                || block == Blocks.JACK_O_LANTERN
                || block == Blocks.REDSTONE_LAMP
                || block == Blocks.CAMPFIRE
                || block == Blocks.SOUL_CAMPFIRE
                || block == Blocks.END_ROD
                || block == Blocks.BEACON
                || block == Blocks.CONDUIT
                || block == Blocks.SHROOMLIGHT
                || block == Blocks.OCHRE_FROGLIGHT
                || block == Blocks.VERDANT_FROGLIGHT
                || block == Blocks.PEARLESCENT_FROGLIGHT
                || block == Blocks.CANDLE
                || block == Blocks.LIGHT;
    }

    private int suspiciousWeight(BlockState state, SusChunkSettings settings) {
        Block block = state.getBlock();
        if (isStorageBlock(block)) {
            return 8;
        }
        if (isLightBlock(block)) {
            return 6;
        }
        if (block == Blocks.CRAFTING_TABLE
                || block == Blocks.ANVIL
                || block == Blocks.CHIPPED_ANVIL
                || block == Blocks.DAMAGED_ANVIL
                || block == Blocks.ENCHANTING_TABLE
                || block == Blocks.BREWING_STAND
                || block == Blocks.CAULDRON
                || block == Blocks.RESPAWN_ANCHOR) {
            return 7;
        }
        if (block == Blocks.OBSIDIAN || block == Blocks.NETHER_PORTAL) {
            return 5;
        }
        if (block == Blocks.REDSTONE_WIRE
                || block == Blocks.REPEATER
                || block == Blocks.COMPARATOR
                || block == Blocks.PISTON
                || block == Blocks.STICKY_PISTON) {
            return 5;
        }
        if (block == Blocks.RAIL
                || block == Blocks.POWERED_RAIL
                || block == Blocks.DETECTOR_RAIL
                || block == Blocks.ACTIVATOR_RAIL
                || block == Blocks.LADDER
                || block == Blocks.SCAFFOLDING) {
            return 3;
        }
        if (settings.caveVines() && (block == Blocks.CAVE_VINES || block == Blocks.CAVE_VINES_PLANT)) {
            return 4;
        }
        if (settings.vines() && block == Blocks.VINE) {
            return 3;
        }
        if (settings.kelp() && (block == Blocks.KELP || block == Blocks.KELP_PLANT)) {
            return 4;
        }
        if (settings.amethyst() && (block == Blocks.AMETHYST_BLOCK || block == Blocks.BUDDING_AMETHYST || block == Blocks.AMETHYST_CLUSTER)) {
            return 5;
        }
        if (settings.bamboo() && (block == Blocks.BAMBOO || block == Blocks.BAMBOO_SAPLING)) {
            return 4;
        }
        if (settings.beeNest() && (block == Blocks.BEE_NEST || block == Blocks.BEEHIVE)) {
            return 4;
        }
        if (settings.rotatedDeepslate() && isRotatedDeepslate(state)) {
            return 6;
        }
        return 0;
    }

    private int susThreshold(SusChunkSettings settings) {
        return Math.max(2, 24 - settings.sensitivity() * 2);
    }

    private boolean isProbableBaseChunk(ChunkScore score, int threshold, SusChunkSettings settings) {
        int minimumSuspiciousBlocks = settings.minimumSuspiciousBlocks();
        if (settings.smartAdjustment()) {
            if (score.leakCount() >= 1 || score.undergroundStorageCount() >= 2) {
                minimumSuspiciousBlocks = Math.max(2, minimumSuspiciousBlocks / 3);
                threshold = Math.max(10, threshold - 4);
            } else if (score.undergroundStorageCount() == 1) {
                minimumSuspiciousBlocks = Math.max(4, minimumSuspiciousBlocks / 2);
                threshold = Math.max(12, threshold - 2);
            } else {
                minimumSuspiciousBlocks = Math.min(64,
                        minimumSuspiciousBlocks + Math.max(6, minimumSuspiciousBlocks / 2));
                threshold += 10;
            }
        }
        if (score.leakCount() >= 1 && score.undergroundStorageCount() >= 1) {
            return score.score() >= Math.max(18, threshold - 2);
        }
        if (score.leakCount() >= 2) {
            return score.score() >= Math.max(22, threshold);
        }
        if (score.undergroundStorageCount() >= 2) {
            return score.score() >= Math.max(18, threshold - 4)
                    && (score.suspiciousCount() >= Math.max(2, minimumSuspiciousBlocks / 3)
                    || score.blockEntityCount() >= 4);
        }
        if (score.undergroundStorageCount() == 1) {
            return score.score() >= threshold + 10
                    && (score.suspiciousCount() >= minimumSuspiciousBlocks
                    || score.blockEntityCount() >= 5
                    || score.lightsCount() >= 4);
        }
        return score.storageCount() >= 4
                && score.blockEntityCount() >= 4
                && score.suspiciousCount() >= minimumSuspiciousBlocks
                && score.score() >= threshold + 28;
    }

    private String suspiciousLabel(BlockState state, SusChunkSettings settings) {
        if (settings.rotatedDeepslate() && isRotatedDeepslate(state)) {
            return "Rotated Deepslate";
        }
        return state.getBlock().getName().getString();
    }

    private boolean isRotatedDeepslate(BlockState state) {
        if (state.getBlock() != Blocks.DEEPSLATE) {
            return false;
        }

        if (state.hasProperty(RotatedPillarBlock.AXIS)) {
            return state.getValue(RotatedPillarBlock.AXIS).isHorizontal();
        }

        return false;
    }

    private boolean containsTrialChamber(LevelChunk chunk) {
        boolean trialCore = false;
        boolean trialBuilding = false;
        for (LevelChunkSection section : chunk.getSections()) {
            if (section.hasOnlyAir()) {
                continue;
            }
            trialCore |= section.maybeHas(state ->
                    state.getBlock() == Blocks.TRIAL_SPAWNER || state.getBlock() == Blocks.VAULT);
            trialBuilding |= section.maybeHas(state ->
                    state.getBlock() == Blocks.TUFF_BRICKS
                            || state.getBlock() == Blocks.CHISELED_TUFF
                            || state.getBlock() == Blocks.POLISHED_TUFF
                            || state.getBlock() == Blocks.COPPER_GRATE
                            || state.getBlock() == Blocks.EXPOSED_COPPER_GRATE);
            if (trialCore) {
                return true;
            }
        }
        return trialBuilding && containsTrialBuildingCluster(chunk);
    }

    private boolean containsTrialBuildingCluster(LevelChunk chunk) {
        int matchingSections = 0;
        for (LevelChunkSection section : chunk.getSections()) {
            if (!section.hasOnlyAir() && section.maybeHas(state ->
                    state.getBlock() == Blocks.TUFF_BRICKS || state.getBlock() == Blocks.CHISELED_TUFF
                            || state.getBlock() == Blocks.POLISHED_TUFF || state.getBlock() == Blocks.COPPER_GRATE
                            || state.getBlock() == Blocks.EXPOSED_COPPER_GRATE)) {
                matchingSections++;
                if (matchingSections >= 2) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean containsSpawnerRoom(LevelChunk chunk) {
        for (LevelChunkSection section : chunk.getSections()) {
            if (section.hasOnlyAir()) {
                continue;
            }
            if (section.maybeHas(state -> state.getBlock() == Blocks.SPAWNER)) {
                return true;
            }
        }
        for (BlockEntity blockEntity : chunk.getBlockEntities().values()) {
            if (blockEntity.getType().toString().toLowerCase(java.util.Locale.ROOT).contains("spawner")) {
                return true;
            }
        }
        return false;
    }

    private boolean containsAmethystRoom(LevelChunk chunk) {
        for (LevelChunkSection section : chunk.getSections()) {
            if (!section.hasOnlyAir() && section.maybeHas(state ->
                    state.getBlock() == Blocks.BUDDING_AMETHYST)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasUndergroundStorage(ClientLevel level, LevelChunk chunk) {
        for (Map.Entry<BlockPos, BlockEntity> entry : chunk.getBlockEntities().entrySet()) {
            BlockPos pos = entry.getKey();
            if (pos.getY() < 0 && (isStorageBlock(level.getBlockState(pos).getBlock())
                    || isStorageBlockEntity(entry.getValue()))) {
                return true;
            }
        }
        return false;
    }

    private boolean containsMineshaftSignature(LevelChunk chunk) {
        boolean rails = false;
        boolean cobwebs = false;
        boolean supports = false;
        for (LevelChunkSection section : chunk.getSections()) {
            if (section.hasOnlyAir()) {
                continue;
            }
            rails |= section.maybeHas(state -> isRail(state.getBlock()));
            cobwebs |= section.maybeHas(state -> state.getBlock() == Blocks.COBWEB);
            supports |= section.maybeHas(state -> state.getBlock() == Blocks.OAK_PLANKS
                    || state.getBlock() == Blocks.OAK_FENCE);
            if (rails && (cobwebs || supports)) {
                return true;
            }
        }
        return false;
    }

    private boolean containsLushCaveSignature(LevelChunk chunk) {
        boolean moss = false;
        boolean lushFeature = false;
        for (LevelChunkSection section : chunk.getSections()) {
            if (section.hasOnlyAir()) {
                continue;
            }
            moss |= section.maybeHas(state -> state.getBlock() == Blocks.MOSS_BLOCK
                    || state.getBlock() == Blocks.MOSS_CARPET);
            lushFeature |= section.maybeHas(state -> state.getBlock() == Blocks.SPORE_BLOSSOM
                    || state.getBlock() == Blocks.AZALEA
                    || state.getBlock() == Blocks.FLOWERING_AZALEA
                    || state.getBlock() == Blocks.CAVE_VINES
                    || state.getBlock() == Blocks.CAVE_VINES_PLANT);
            if (moss && lushFeature) {
                return true;
            }
        }
        return false;
    }

    private boolean isKelp(Block block) {
        return block == Blocks.KELP || block == Blocks.KELP_PLANT;
    }

    private boolean isRail(Block block) {
        return block == Blocks.RAIL
                || block == Blocks.POWERED_RAIL
                || block == Blocks.DETECTOR_RAIL
                || block == Blocks.ACTIVATOR_RAIL;
    }

    private void removeOutOfScopeMarkers(ClientLevel level, BlockPos centerPos, int renderDistance) {
        int playerChunkX = centerPos.getX() >> 4;
        int playerChunkZ = centerPos.getZ() >> 4;
        int radius = Math.min(MAX_SCAN_RADIUS_CHUNKS, Math.max(2, renderDistance + 2));
        removeMarkersIf(marker -> {
            BlockPos markerPos = marker.pos();
            int chunkX = markerPos.getX() >> 4;
            int chunkZ = markerPos.getZ() >> 4;
            return Math.abs(chunkX - playerChunkX) > radius
                    || Math.abs(chunkZ - playerChunkZ) > radius
                    || !level.hasChunk(chunkX, chunkZ);
        });
    }

    private void clearMarkersInChunk(MarkerType type, ChunkPos chunkPos) {
        long chunkKey = chunkPos.toLong();
        Set<String> keys = markerKeysByChunk.get(chunkKey);
        if (keys == null || keys.isEmpty()) {
            return;
        }
        keys.removeIf(key -> {
            BaseMarker marker = markers.get(key);
            if (marker == null) {
                return true;
            }
            if (marker.type() != type) {
                return false;
            }
            markers.remove(key);
            return true;
        });
        if (keys.isEmpty()) {
            markerKeysByChunk.remove(chunkKey);
        }
    }

    private void clearChunkFinderMarkers(ChunkPos chunkPos) {
        clearMarkersInChunk(MarkerType.SUS_CHUNK, chunkPos);
        clearMarkersInChunk(MarkerType.PRIME_CHUNK, chunkPos);
        clearMarkersInChunk(MarkerType.SEED_PATTERN, chunkPos);
    }

    private void pruneIgnoredChunkFinderMarkers(ClientLevel level) {
        Set<Long> ignoredChunks = new HashSet<>();
        removeMarkersIf(marker -> {
            if (marker.type() != MarkerType.SUS_CHUNK
                    && marker.type() != MarkerType.PRIME_CHUNK
                    && marker.type() != MarkerType.SEED_PATTERN) {
                return false;
            }

            BlockPos pos = marker.pos();
            int chunkX = pos.getX() >> 4;
            int chunkZ = pos.getZ() >> 4;
            long key = ChunkPos.asLong(chunkX, chunkZ);
            if (ignoredChunks.contains(key)) {
                return true;
            }
            if (!level.hasChunk(chunkX, chunkZ)) {
                return false;
            }

            LevelChunk chunk = level.getChunk(chunkX, chunkZ);
            boolean ignored = containsSpawnerRoom(chunk) || containsAmethystRoom(chunk)
                    || ((containsTrialChamber(chunk)
                    || containsMineshaftSignature(chunk)
                    || containsLushCaveSignature(chunk))
                    && !hasUndergroundStorage(level, chunk));
            if (ignored) {
                ignoredChunks.add(key);
            }
            return ignored;
        });
    }

    private void put(BlockPos pos, MarkerType type, String label, int color, int score) {
        String key = type.name() + ":" + pos.asLong();
        markers.put(key, new BaseMarker(pos, type, label, color, score, ticks));
        long chunkKey = ChunkPos.asLong(pos.getX() >> 4, pos.getZ() >> 4);
        markerKeysByChunk.computeIfAbsent(chunkKey, ignored -> new HashSet<>()).add(key);
    }

    private void removeExpiredMarkers() {
        removeMarkersIf(marker -> {
            MarkerType type = marker.type();
            if (type == MarkerType.BLOCK_ESP || type == MarkerType.STORAGE) {
                return false;
            }
            return ticks - marker.seenAtTick() > keepTicks(type);
        });
    }

    private int keepTicks(MarkerType type) {
        return switch (type) {
            case BLOCK_ESP -> FAST_ESP_KEEP_TICKS;
            case STORAGE, BLOCK_ENTITY, LIGHT, SUSPICIOUS -> ESP_KEEP_TICKS;
            case HOLE -> 20 * 60;
            case SUS_CHUNK, PRIME_CHUNK, SEED_PATTERN -> KEEP_TICKS;
        };
    }

    private void trimMarkers() {
        if (markers.size() <= MAX_MARKERS) {
            return;
        }

        List<BaseMarker> keep = strongestMarkers(MAX_MARKERS);
        clearAllMarkers();
        for (BaseMarker marker : keep) {
            put(marker.pos(), marker.type(), marker.label(), marker.color(), marker.score());
        }
    }

    private void removeMarkersIf(java.util.function.Predicate<BaseMarker> predicate) {
        boolean changed = markers.entrySet().removeIf(entry -> predicate.test(entry.getValue()));
        if (changed) {
            rebuildMarkerIndex();
        }
    }

    private void rebuildMarkerIndex() {
        markerKeysByChunk.clear();
        for (Map.Entry<String, BaseMarker> entry : markers.entrySet()) {
            BlockPos pos = entry.getValue().pos();
            long chunkKey = ChunkPos.asLong(pos.getX() >> 4, pos.getZ() >> 4);
            markerKeysByChunk.computeIfAbsent(chunkKey, ignored -> new HashSet<>()).add(entry.getKey());
        }
    }

    private void clearAllMarkers() {
        markers.clear();
        markerKeysByChunk.clear();
    }
}

