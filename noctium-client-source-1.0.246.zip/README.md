# DonutSMP Utilities

Fabric 1.21.11 client-side utility mod with a right-Shift click menu and loaded-world basefinding helpers.

## Included Modules

- Block Entity Debug
- Hole ESP
- Light Finder
- Prime Chunk Finder
- RTP Base Finder
- Sus Chunk Finder
- Suspicious ESP
- Seed Chunk Finder
- Storage ESP
- Block ESP
- Player ESP
- Mob ESP
- HUD
- Fullbright
- Freecam
- Coordinates
- Weather Notifier
- Waypoint Logger

## Controls

- Right Shift or Insert opens/closes the module menu.
- F4 toggles Freecam.
- Left click a module row to toggle it.
- Right click Sus Chunk Finder to open its settings.
- Right click Block ESP to choose storage groups, utility groups, ores, and custom block IDs.
- Right click Freecam to change camera speed.

## Notes

The scanner only uses chunks, blocks, block entities, and entities that the Minecraft client has actually loaded. It does not extract a server seed and it cannot scan unloaded chunks.

## License and Credits

This project is distributed under GPL-3.0-or-later.

Chest/storage ESP grouping and GPL packaging are based on the GPL-3.0-or-later ChestESP project by Alexander01998 / WiMods. DonutSMP Utilities modifies the idea for extra block groups, custom block IDs, DonutSMP-oriented markers, and the bundled click GUI.

Freecam behavior is based on the MIT-licensed MinecraftFreecam/Freecam project idea: a separate client-side camera, default F4 keybind, and configurable movement speed. DonutSMP Utilities does not include anti-cheat bypass logic.
