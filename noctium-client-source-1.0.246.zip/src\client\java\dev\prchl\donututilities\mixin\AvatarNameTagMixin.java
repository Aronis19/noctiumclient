package dev.prchl.donututilities.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.prchl.donututilities.DonutUtilitiesClient;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.state.CameraRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AvatarRenderer.class)
public abstract class AvatarNameTagMixin {
    @Inject(method = "submitNameTag(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
            at = @At("HEAD"), cancellable = true)
    private void donututilities$hideVanillaPlayerNameTag(AvatarRenderState state, PoseStack matrices,
            SubmitNodeCollector commandQueue, CameraRenderState cameraState, CallbackInfo info) {
        if (DonutUtilitiesClient.MODULES.enabled("player_info")) {
            info.cancel();
        }
    }
}
