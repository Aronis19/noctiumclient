package dev.prchl.donututilities.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.module.BlockEspSettings;
import dev.prchl.donututilities.module.ClickGuiLayoutSettings;
import dev.prchl.donututilities.module.NameProtectSettings;
import dev.prchl.donututilities.module.SkinProtectSettings;
import dev.prchl.donututilities.module.BrandSpooferSettings;
import dev.prchl.donututilities.module.EspSettings;
import dev.prchl.donututilities.module.Module;
import dev.prchl.donututilities.module.ModuleManager;
import dev.prchl.donututilities.module.MenuScaleSettings;
import dev.prchl.donututilities.module.PopupSettings;
import dev.prchl.donututilities.module.HudSettings;
import dev.prchl.donututilities.module.DonutRegionSettings;
import dev.prchl.donututilities.module.SusChunkSettings;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.client.Minecraft;

public final class ClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ClientConfig() {
    }

    public static void load(ModuleManager modules) {
        Path path = path();
        JsonObject root = readConfigWithBackup(path);
        if (root == null) {
            return;
        }

        try {
            JsonObject moduleObject = object(root, "modules");
            for (Module module : modules.modules()) {
                if (moduleObject.has(module.id())) {
                    module.setEnabled(moduleObject.get(module.id()).getAsBoolean());
                }
            }
            JsonObject keybindObject = object(root, "moduleKeybinds");
            for (Module module : modules.modules()) {
                if (keybindObject.has(module.id())) {
                    module.setStoredKeyCode(keybindObject.get(module.id()).getAsInt());
                }
            }

            loadSus(modules.susChunkSettings(), object(root, "susChunkFinder"));
            loadEsp(modules.espSettings(), object(root, "esp"));
            loadBlockEsp(modules.blockEspSettings(), object(root, "blockEsp"));
            loadHud(modules.hudSettings(), object(root, "hud"));
            loadMenuScale(modules.menuScaleSettings(), object(root, "menuScale"));
            loadDonutRegion(modules.donutRegionSettings(), object(root, "donutRegionMap"));
            loadClickGuiLayout(modules.clickGuiLayoutSettings(), object(root, "clickGuiLayout"));
            loadNameProtect(modules.nameProtectSettings(), object(root, "nameProtect"));
            loadSkinProtect(modules.skinProtectSettings(), object(root, "skinProtect"));
            loadPopup(modules.popupSettings(), object(root, "popup"));
            loadBrandSpoofer(modules.brandSpooferSettings(), object(root, "brandSpoofer"));
            loadItemInfo(modules.itemInfoModule(), object(root, "itemInfo"));
            loadPlayerInfo(modules.playerInfoSettings(), object(root, "playerInfo"));
            loadModuleList(modules.moduleListSettings(), object(root, "moduleList"));
            loadVisuals(modules.visualsSettings(), object(root, "visuals"));
            JsonObject swingSpeed = object(root, "swingSpeed");
            if (swingSpeed.has("speed")) {
                modules.swingSpeedSettings().setSpeed(swingSpeed.get("speed").getAsInt());
            }
            JsonObject freecam = object(root, "freecam");
            if (freecam.has("speed")) {
                modules.freecamModule().setSpeed(freecam.get("speed").getAsInt());
            }
            if (freecam.has("keyCode")) {
                modules.freecamModule().setStoredKeyCode(freecam.get("keyCode").getAsInt());
            }
        } catch (Exception exception) {
            DonutUtilitiesClient.LOGGER.warn("Could not load client config", exception);
        }
    }

    public static void save() {
        try {
            Path path = path();
            Files.createDirectories(path.getParent());

            JsonObject root = new JsonObject();
            JsonObject moduleObject = new JsonObject();
            for (Module module : DonutUtilitiesClient.MODULES.modules()) {
                moduleObject.addProperty(module.id(), module.enabled());
            }
            root.add("modules", moduleObject);
            JsonObject keybindObject = new JsonObject();
            for (Module module : DonutUtilitiesClient.MODULES.modules()) {
                keybindObject.addProperty(module.id(), module.keyCode());
            }
            root.add("moduleKeybinds", keybindObject);
            root.add("susChunkFinder", saveSus(DonutUtilitiesClient.MODULES.susChunkSettings()));
            root.add("esp", saveEsp(DonutUtilitiesClient.MODULES.espSettings()));
            root.add("blockEsp", saveBlockEsp(DonutUtilitiesClient.MODULES.blockEspSettings()));
            root.add("hud", saveHud(DonutUtilitiesClient.MODULES.hudSettings()));
            root.add("menuScale", saveMenuScale(DonutUtilitiesClient.MODULES.menuScaleSettings()));
            root.add("donutRegionMap", saveDonutRegion(DonutUtilitiesClient.MODULES.donutRegionSettings()));
            root.add("clickGuiLayout", saveClickGuiLayout(DonutUtilitiesClient.MODULES.clickGuiLayoutSettings()));
            root.add("nameProtect", saveNameProtect(DonutUtilitiesClient.MODULES.nameProtectSettings()));
            root.add("skinProtect", saveSkinProtect(DonutUtilitiesClient.MODULES.skinProtectSettings()));
            root.add("popup", savePopup(DonutUtilitiesClient.MODULES.popupSettings()));
            root.add("brandSpoofer", saveBrandSpoofer(DonutUtilitiesClient.MODULES.brandSpooferSettings()));
            root.add("itemInfo", saveItemInfo(DonutUtilitiesClient.MODULES.itemInfoModule()));
            root.add("playerInfo", savePlayerInfo(DonutUtilitiesClient.MODULES.playerInfoSettings()));
            root.add("moduleList", saveModuleList(DonutUtilitiesClient.MODULES.moduleListSettings()));
            root.add("visuals", saveVisuals(DonutUtilitiesClient.MODULES.visualsSettings()));
            JsonObject swingSpeed = new JsonObject();
            swingSpeed.addProperty("speed", DonutUtilitiesClient.MODULES.swingSpeedSettings().speed());
            root.add("swingSpeed", swingSpeed);

            JsonObject freecam = new JsonObject();
            freecam.addProperty("speed", DonutUtilitiesClient.MODULES.freecamModule().speed());
            freecam.addProperty("keyCode", DonutUtilitiesClient.MODULES.freecamModule().keyCode());
            root.add("freecam", freecam);

            preservePreviousBlockSelection(path, root);
            writeWithBackup(path, GSON.toJson(root));
        } catch (Exception exception) {
            DonutUtilitiesClient.LOGGER.warn("Could not save client config", exception);
        }
    }

    private static JsonObject saveSus(SusChunkSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("simulationDistance", settings.simulationDistance());
        json.addProperty("sensitivity", settings.sensitivity());
        json.addProperty("alpha", settings.alpha());
        json.addProperty("minimumSuspiciousBlocks", settings.minimumSuspiciousBlocks());
        json.addProperty("smartAdjustment", settings.smartAdjustment());
        json.addProperty("caveVines", settings.caveVines());
        json.addProperty("vines", settings.vines());
        json.addProperty("amethyst", settings.amethyst());
        json.addProperty("bamboo", settings.bamboo());
        json.addProperty("beeNest", settings.beeNest());
        json.addProperty("rotatedDeepslate", settings.rotatedDeepslate());
        json.addProperty("kelp", settings.kelp());
        return json;
    }

    private static void loadSus(SusChunkSettings settings, JsonObject json) {
        if (json.has("simulationDistance")) settings.setSimulationDistance(json.get("simulationDistance").getAsInt());
        if (json.has("sensitivity")) settings.setSensitivity(json.get("sensitivity").getAsInt());
        if (json.has("alpha")) settings.setAlpha(json.get("alpha").getAsInt());
        if (json.has("minimumSuspiciousBlocks")) settings.setMinimumSuspiciousBlocks(json.get("minimumSuspiciousBlocks").getAsInt());
        setBoolean(json, "smartAdjustment", settings.smartAdjustment(), settings::toggleSmartAdjustment);
        setBoolean(json, "caveVines", settings.caveVines(), settings::toggleCaveVines);
        setBoolean(json, "vines", settings.vines(), settings::toggleVines);
        setBoolean(json, "amethyst", settings.amethyst(), settings::toggleAmethyst);
        setBoolean(json, "bamboo", settings.bamboo(), settings::toggleBamboo);
        setBoolean(json, "beeNest", settings.beeNest(), settings::toggleBeeNest);
        setBoolean(json, "rotatedDeepslate", settings.rotatedDeepslate(), settings::toggleRotatedDeepslate);
        setBoolean(json, "kelp", settings.kelp(), settings::toggleKelp);
    }

    private static JsonObject saveEsp(EspSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("traces", settings.traces());
        json.addProperty("entityTraces", settings.entityTraces());
        json.addProperty("blockTraces", settings.blockTraces());
        json.addProperty("traceDistance", settings.traceDistance());
        json.addProperty("traceAlpha", settings.traceAlpha());
        json.addProperty("traceRed", settings.traceRed());
        json.addProperty("traceGreen", settings.traceGreen());
        json.addProperty("traceBlue", settings.traceBlue());
        JsonObject colors = new JsonObject();
        settings.traceColors().forEach((moduleId, color) -> {
            JsonObject value = new JsonObject();
            value.addProperty("red", color[0]);
            value.addProperty("green", color[1]);
            value.addProperty("blue", color[2]);
            colors.add(moduleId, value);
        });
        json.add("traceColors", colors);
        return json;
    }

    private static void loadEsp(EspSettings settings, JsonObject json) {
        setBoolean(json, "traces", settings.traces(), settings::toggleTraces);
        setBoolean(json, "entityTraces", settings.entityTraces(), settings::toggleEntityTraces);
        setBoolean(json, "blockTraces", settings.blockTraces(), settings::toggleBlockTraces);
        if (json.has("traceDistance")) settings.setTraceDistance(json.get("traceDistance").getAsInt());
        if (json.has("traceAlpha")) settings.setTraceAlpha(json.get("traceAlpha").getAsInt());
        if (json.has("traceRed")) settings.setTraceRed(json.get("traceRed").getAsInt());
        if (json.has("traceGreen")) settings.setTraceGreen(json.get("traceGreen").getAsInt());
        if (json.has("traceBlue")) settings.setTraceBlue(json.get("traceBlue").getAsInt());
        if (json.has("traceColors") && json.get("traceColors").isJsonObject()) {
            for (var entry : json.getAsJsonObject("traceColors").entrySet()) {
                if (!entry.getValue().isJsonObject()) {
                    continue;
                }
                JsonObject color = entry.getValue().getAsJsonObject();
                settings.setTraceColor(entry.getKey(),
                        intValue(color, "red", settings.traceRed()),
                        intValue(color, "green", settings.traceGreen()),
                        intValue(color, "blue", settings.traceBlue()));
            }
        }
    }

    private static int intValue(JsonObject json, String key, int fallback) {
        return json.has(key) && json.get(key).isJsonPrimitive() ? json.get(key).getAsInt() : fallback;
    }

    private static JsonObject saveBlockEsp(BlockEspSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("explicitSelection", settings.explicitSelection());
        JsonArray selected = new JsonArray();
        settings.selectedBlockIds().forEach(selected::add);
        json.add("selectedBlocks", selected);
        JsonObject colors = new JsonObject();
        settings.blockColors().forEach(colors::addProperty);
        json.add("blockColors", colors);
        json.addProperty("customBlockId", settings.customBlockId());
        json.addProperty("customBlock", settings.customBlock());
        return json;
    }

    private static void loadBlockEsp(BlockEspSettings settings, JsonObject json) {
        Set<String> selected = new LinkedHashSet<>();
        if (json.has("selectedBlocks") && json.get("selectedBlocks").isJsonArray()) {
            for (JsonElement element : json.getAsJsonArray("selectedBlocks")) {
                if (element.isJsonPrimitive()) {
                    selected.add(element.getAsString());
                }
            }
        }
        settings.setSelectedBlockIds(selected, true);
        if (json.has("blockColors") && json.get("blockColors").isJsonObject()) {
            for (var entry : json.getAsJsonObject("blockColors").entrySet()) {
                if (entry.getValue().isJsonPrimitive()) {
                    settings.setBlockColor(entry.getKey(), entry.getValue().getAsInt());
                }
            }
        }
        if (json.has("customBlockId")) settings.setCustomBlockId(json.get("customBlockId").getAsString());
        setBoolean(json, "customBlock", settings.customBlock(), settings::toggleCustomBlock);
    }

    private static JsonObject saveHud(HudSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("baseScan", settings.baseScan());
        json.addProperty("espStats", settings.espStats());
        json.addProperty("coordinates", settings.coordinates());
        json.addProperty("realTime", settings.realTime());
        json.addProperty("ping", settings.ping());
        json.addProperty("ticks", settings.ticks());
        json.addProperty("bps", settings.bps());
        json.addProperty("singleRow", settings.singleRow());
        json.addProperty("potions", settings.potions());
        json.addProperty("keybinds", settings.keybinds());
        json.addProperty("panelIcons", settings.panelIcons());
        json.addProperty("panelIconColorHex", settings.panelIconColorHex());
        json.addProperty("panelIconRainbow", settings.panelIconRainbow());
        json.addProperty("keybindPositionX", settings.keybindPositionX());
        json.addProperty("keybindPositionY", settings.keybindPositionY());
        json.addProperty("keybindPositionCustomized", settings.keybindPositionCustomized());
        json.addProperty("potionPositionX", settings.potionPositionX());
        json.addProperty("potionPositionY", settings.potionPositionY());
        json.addProperty("potionPositionCustomized", settings.potionPositionCustomized());
        return json;
    }

    private static void loadHud(HudSettings settings, JsonObject json) {
        setBoolean(json, "baseScan", settings.baseScan(), settings::toggleBaseScan);
        setBoolean(json, "espStats", settings.espStats(), settings::toggleEspStats);
        setBoolean(json, "coordinates", settings.coordinates(), settings::toggleCoordinates);
        setBoolean(json, "realTime", settings.realTime(), settings::toggleRealTime);
        setBoolean(json, "ping", settings.ping(), settings::togglePing);
        setBoolean(json, "ticks", settings.ticks(), settings::toggleTicks);
        setBoolean(json, "bps", settings.bps(), settings::toggleBps);
        setBoolean(json, "singleRow", settings.singleRow(), settings::toggleSingleRow);
        setBoolean(json, "potions", settings.potions(), settings::togglePotions);
        setBoolean(json, "keybinds", settings.keybinds(), settings::toggleKeybinds);
        setBoolean(json, "panelIcons", settings.panelIcons(), settings::togglePanelIcons);
        if (json.has("panelIconColorHex")) {
            settings.setPanelIconColorHex(json.get("panelIconColorHex").getAsString());
        }
        setBoolean(json, "panelIconRainbow", settings.panelIconRainbow(), settings::togglePanelIconRainbow);
        settings.loadKeybindPosition(
                json.has("keybindPositionX") ? json.get("keybindPositionX").getAsInt() : 0,
                json.has("keybindPositionY") ? json.get("keybindPositionY").getAsInt() : 0,
                bool(json, "keybindPositionCustomized", false));
        settings.loadPotionPosition(
                json.has("potionPositionX") ? json.get("potionPositionX").getAsInt() : 0,
                json.has("potionPositionY") ? json.get("potionPositionY").getAsInt() : 0,
                bool(json, "potionPositionCustomized", false));
    }

    private static JsonObject saveMenuScale(MenuScaleSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("percent", settings.percent());
        return json;
    }

    private static void loadMenuScale(MenuScaleSettings settings, JsonObject json) {
        if (json.has("percent")) {
            settings.setPercent(json.get("percent").getAsInt());
        }
    }

    private static JsonObject saveDonutRegion(DonutRegionSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("positionX", settings.positionX());
        json.addProperty("positionY", settings.positionY());
        json.addProperty("cellSize", settings.cellSize());
        json.addProperty("transparency", settings.transparency());
        json.addProperty("labelScale", settings.labelScale());
        json.addProperty("coordinates", settings.coordinates());
        json.addProperty("regionLabels", settings.regionLabels());
        json.addProperty("grid", settings.grid());
        json.addProperty("playerIndicator", settings.playerIndicator());
        json.addProperty("fontMode", settings.fontMode().name());
        return json;
    }

    private static void loadDonutRegion(DonutRegionSettings settings, JsonObject json) {
        if (json.has("positionX")) settings.setPositionX(json.get("positionX").getAsInt());
        if (json.has("positionY")) settings.setPositionY(json.get("positionY").getAsInt());
        if (json.has("cellSize")) settings.setCellSize(json.get("cellSize").getAsInt());
        if (json.has("transparency")) settings.setTransparency(json.get("transparency").getAsInt());
        if (json.has("labelScale")) settings.setLabelScale(json.get("labelScale").getAsInt());
        setBoolean(json, "coordinates", settings.coordinates(), settings::toggleCoordinates);
        setBoolean(json, "regionLabels", settings.regionLabels(), settings::toggleRegionLabels);
        setBoolean(json, "grid", settings.grid(), settings::toggleGrid);
        setBoolean(json, "playerIndicator", settings.playerIndicator(), settings::togglePlayerIndicator);
        if (json.has("fontMode")) {
            try {
                settings.setFontMode(DonutRegionSettings.FontMode.valueOf(json.get("fontMode").getAsString()));
            } catch (IllegalArgumentException ignored) {
                // Keep the default font when the saved value is unknown.
            }
        }
    }

    private static JsonObject saveClickGuiLayout(ClickGuiLayoutSettings settings) {
        JsonObject json = new JsonObject();
        for (dev.prchl.donututilities.module.ModuleCategory category
                : dev.prchl.donututilities.module.ModuleCategory.values()) {
            ClickGuiLayoutSettings.Position position = settings.position(category);
            JsonObject panel = new JsonObject();
            if (position != null) {
                panel.addProperty("x", position.x());
                panel.addProperty("y", position.y());
            }
            panel.addProperty("collapsed", settings.collapsed(category));
            json.add(category.name(), panel);
        }
        JsonObject search = new JsonObject();
        ClickGuiLayoutSettings.Position searchPosition = settings.searchPosition();
        if (searchPosition != null) {
            search.addProperty("x", searchPosition.x());
            search.addProperty("y", searchPosition.y());
        }
        search.addProperty("collapsed", settings.searchCollapsed());
        json.add("search", search);
        return json;
    }

    private static void loadClickGuiLayout(ClickGuiLayoutSettings settings, JsonObject json) {
        for (dev.prchl.donututilities.module.ModuleCategory category
                : dev.prchl.donututilities.module.ModuleCategory.values()) {
            JsonObject panel = object(json, category.name());
            if (panel.has("x") && panel.has("y")) {
                settings.setPosition(category, panel.get("x").getAsInt(), panel.get("y").getAsInt());
            }
            if (panel.has("collapsed")) {
                settings.setCollapsed(category, panel.get("collapsed").getAsBoolean());
            }
        }
        JsonObject search = object(json, "search");
        if (search.has("x") && search.has("y")) {
            settings.setSearchPosition(search.get("x").getAsInt(), search.get("y").getAsInt());
        }
        if (search.has("collapsed")) {
            settings.setSearchCollapsed(search.get("collapsed").getAsBoolean());
        }
    }

    private static JsonObject saveNameProtect(NameProtectSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("fakeName", settings.fakeName());
        json.addProperty("hideOthers", settings.hideOthers());
        return json;
    }

    private static void loadNameProtect(NameProtectSettings settings, JsonObject json) {
        if (json.has("fakeName")) settings.setFakeName(json.get("fakeName").getAsString());
        setBoolean(json, "hideOthers", settings.hideOthers(), settings::toggleHideOthers);
    }

    private static JsonObject saveSkinProtect(SkinProtectSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("skinOwner", settings.skinOwner());
        json.addProperty("changeOwnSkin", settings.changeOwnSkin());
        json.addProperty("changeOthersSkin", settings.changeOthersSkin());
        return json;
    }

    private static void loadSkinProtect(SkinProtectSettings settings, JsonObject json) {
        if (json.has("skinOwner")) settings.setSkinOwner(json.get("skinOwner").getAsString());
        setBoolean(json, "changeOwnSkin", settings.changeOwnSkin(), settings::toggleChangeOwnSkin);
        setBoolean(json, "changeOthersSkin", settings.changeOthersSkin(), settings::toggleChangeOthersSkin);
    }

    private static JsonObject savePopup(PopupSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("position", settings.position().name());
        return json;
    }

    private static void loadPopup(PopupSettings settings, JsonObject json) {
        if (json.has("position")) {
            try {
                settings.setPosition(PopupSettings.Position.valueOf(json.get("position").getAsString()));
            } catch (IllegalArgumentException ignored) {
                // Keep the default popup position when the saved value is unknown.
            }
        }
    }

    private static JsonObject saveBrandSpoofer(BrandSpooferSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("brand", settings.brand());
        return json;
    }

    private static void loadBrandSpoofer(BrandSpooferSettings settings, JsonObject json) {
        if (json.has("brand")) {
            settings.setBrand(json.get("brand").getAsString());
        }
    }

    private static JsonObject saveItemInfo(dev.prchl.donututilities.module.ItemInfoModule settings) {
        JsonObject json = new JsonObject();
        json.addProperty("textColorHex", settings.textColorHex());
        json.addProperty("amountColorHex", settings.amountColorHex());
        json.addProperty("height", settings.height());
        return json;
    }

    private static void loadItemInfo(dev.prchl.donututilities.module.ItemInfoModule settings, JsonObject json) {
        if (json.has("textColorHex")) {
            settings.setTextColorHex(json.get("textColorHex").getAsString());
        }
        if (json.has("amountColorHex")) {
            settings.setAmountColorHex(json.get("amountColorHex").getAsString());
        }
        if (json.has("height")) {
            settings.setHeight(json.get("height").getAsInt());
        }
    }

    private static JsonObject savePlayerInfo(dev.prchl.donututilities.module.PlayerInfoSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("scale", settings.scale());
        json.addProperty("nickColorHex", settings.nickColorHex());
        json.addProperty("itemsBelowHealth", settings.itemsBelowHealth());
        json.addProperty("customFont", settings.customFont());
        return json;
    }

    private static void loadPlayerInfo(dev.prchl.donututilities.module.PlayerInfoSettings settings, JsonObject json) {
        if (json.has("scale")) {
            settings.setScale(json.get("scale").getAsInt());
        }
        if (json.has("nickColorHex")) {
            settings.setNickColorHex(json.get("nickColorHex").getAsString());
        }
        if (json.has("itemsBelowHealth")) {
            settings.setItemsBelowHealth(json.get("itemsBelowHealth").getAsBoolean());
        }
        setBoolean(json, "customFont", settings.customFont(), settings::toggleCustomFont);
    }

    private static JsonObject saveModuleList(dev.prchl.donututilities.module.ModuleListSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("textColorHex", settings.textColorHex());
        json.addProperty("rainbow", settings.rainbow());
        return json;
    }

    private static void loadModuleList(dev.prchl.donututilities.module.ModuleListSettings settings, JsonObject json) {
        if (json.has("textColorHex")) {
            settings.setTextColorHex(json.get("textColorHex").getAsString());
        }
        setBoolean(json, "rainbow", settings.rainbow(), settings::toggleRainbow);
    }

    private static JsonObject saveVisuals(dev.prchl.donututilities.module.VisualsSettings settings) {
        JsonObject json = new JsonObject();
        json.addProperty("accentColorHex", settings.accentColorHex());
        json.addProperty("rainbow", settings.rainbow());
        json.addProperty("watermarkLogo", settings.watermarkLogo());
        json.addProperty("watermarkColorHex", settings.watermarkColorHex());
        json.addProperty("watermarkTransparency", settings.watermarkTransparency());
        json.addProperty("watermarkPositionX", settings.watermarkPositionX());
        json.addProperty("watermarkPositionY", settings.watermarkPositionY());
        json.addProperty("watermarkRainbow", settings.watermarkRainbow());
        json.addProperty("hudIconColorHex", settings.hudIconColorHex());
        json.addProperty("hudIconRainbow", settings.hudIconRainbow());
        return json;
    }

    private static void loadVisuals(dev.prchl.donututilities.module.VisualsSettings settings, JsonObject json) {
        if (json.has("accentColorHex")) {
            settings.setAccentColorHex(json.get("accentColorHex").getAsString());
        }
        setBoolean(json, "rainbow", settings.rainbow(), settings::toggleRainbow);
        setBoolean(json, "watermarkLogo", settings.watermarkLogo(), settings::toggleWatermarkLogo);
        if (json.has("watermarkColorHex")) {
            settings.setWatermarkColorHex(json.get("watermarkColorHex").getAsString());
        }
        if (json.has("watermarkTransparency")) {
            settings.setWatermarkTransparency(json.get("watermarkTransparency").getAsInt());
        }
        if (json.has("watermarkPositionX")) {
            settings.setWatermarkPositionX(json.get("watermarkPositionX").getAsInt());
        }
        if (json.has("watermarkPositionY")) {
            settings.setWatermarkPositionY(json.get("watermarkPositionY").getAsInt());
        }
        setBoolean(json, "watermarkRainbow", settings.watermarkRainbow(), settings::toggleWatermarkRainbow);
        if (json.has("hudIconColorHex")) {
            settings.setHudIconColorHex(json.get("hudIconColorHex").getAsString());
        }
        setBoolean(json, "hudIconRainbow", settings.hudIconRainbow(), settings::toggleHudIconRainbow);
    }

    private static void setBoolean(JsonObject json, String key, boolean current, Runnable toggle) {
        if (json.has(key) && json.get(key).getAsBoolean() != current) {
            toggle.run();
        }
    }

    private static boolean bool(JsonObject json, String key, boolean fallback) {
        return json.has(key) ? json.get(key).getAsBoolean() : fallback;
    }

    private static JsonObject object(JsonObject parent, String key) {
        return parent.has(key) && parent.get(key).isJsonObject() ? parent.getAsJsonObject(key) : new JsonObject();
    }

    private static JsonObject readConfigWithBackup(Path path) {
        JsonObject primary = readJsonObject(path);
        if (primary != null) {
            return primary;
        }

        Path backup = backupPath(path);
        JsonObject restored = readJsonObject(backup);
        if (restored != null) {
            try {
                Files.createDirectories(path.getParent());
                Files.copy(backup, path, StandardCopyOption.REPLACE_EXISTING);
                DonutUtilitiesClient.LOGGER.warn("Restored Donut Utilities config from backup");
            } catch (IOException exception) {
                DonutUtilitiesClient.LOGGER.warn("Could not restore Donut Utilities config backup", exception);
            }
            return restored;
        }
        return null;
    }

    private static JsonObject readJsonObject(Path path) {
        if (!Files.isRegularFile(path)) {
            return null;
        }
        try {
            String content = Files.readString(path);
            if (content.isBlank()) {
                return null;
            }
            JsonElement parsed = JsonParser.parseString(content);
            return parsed.isJsonObject() ? parsed.getAsJsonObject() : null;
        } catch (Exception exception) {
            DonutUtilitiesClient.LOGGER.warn("Could not read config {}", path.getFileName(), exception);
            return null;
        }
    }

    private static void preservePreviousBlockSelection(Path path, JsonObject nextRoot) {
        JsonObject previousRoot = readConfigWithBackup(path);
        if (previousRoot == null) {
            return;
        }
        JsonObject previousBlockEsp = object(previousRoot, "blockEsp");
        JsonObject nextBlockEsp = object(nextRoot, "blockEsp");
        if (!previousBlockEsp.has("selectedBlocks") || !previousBlockEsp.get("selectedBlocks").isJsonArray()) {
            return;
        }
        if (!nextBlockEsp.has("selectedBlocks") || !nextBlockEsp.get("selectedBlocks").isJsonArray()) {
            return;
        }
        JsonArray previousSelected = previousBlockEsp.getAsJsonArray("selectedBlocks");
        JsonArray nextSelected = nextBlockEsp.getAsJsonArray("selectedBlocks");
        if (!previousSelected.isEmpty() && nextSelected.isEmpty()) {
            JsonArray restored = new JsonArray();
            previousSelected.forEach(restored::add);
            nextBlockEsp.add("selectedBlocks", restored);
            nextRoot.add("blockEsp", nextBlockEsp);
        }
    }

    private static void writeWithBackup(Path path, String content) throws IOException {
        JsonElement parsed = JsonParser.parseString(content);
        if (!parsed.isJsonObject()) {
            throw new IOException("Refusing to write invalid config JSON");
        }
        if (Files.isRegularFile(path) && readJsonObject(path) != null) {
            Files.copy(path, backupPath(path), StandardCopyOption.REPLACE_EXISTING);
        }
        Path temp = path.resolveSibling(path.getFileName() + ".tmp");
        Files.writeString(temp, content, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        try {
            Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException exception) {
            Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static Path backupPath(Path path) {
        return path.resolveSibling(path.getFileName() + ".bak");
    }

    private static Path path() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config").resolve("donututilities.json");
    }
}
