package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.DonutUtilitiesClient;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntitySwingMixin {
    @Inject(method = "getCurrentSwingDuration", at = @At("HEAD"), cancellable = true)
    private void donututilities$shorterLocalSwing(CallbackInfoReturnable<Integer> info) {
        Minecraft client = Minecraft.getInstance();
        if (DonutUtilitiesClient.MODULES.enabled("swing_speed") && (Object) this == client.player) {
            info.setReturnValue(DonutUtilitiesClient.MODULES.swingSpeedSettings().swingDurationTicks());
        }
    }
}
