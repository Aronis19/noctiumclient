package dev.prchl.donututilities.render;

import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.module.HudSettings;
import dev.prchl.donututilities.module.Module;
import dev.prchl.donututilities.render.shape.RoundedRectRenderer;
import dev.prchl.donututilities.scan.BaseMarker;
import dev.prchl.donututilities.scan.MarkerType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.world.effect.MobEffectInstance;
import org.lwjgl.glfw.GLFW;

public final class DonutHudRenderer {
    private static final Identifier WORLD_ICON = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/world.png");
    private static final Identifier CLIENT_ICON = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/client.png");
    private static final Identifier CLOCK_ICON = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/clock.png");
    private static final Identifier SERVER_ICON = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/server.png");
    private static final Identifier SPEEDTEST_ICON = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/speedtest.png");
    private static final Identifier NOCTIUM_LOGO = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/noctium_logo.png");
    private static final Identifier POTION_ICON = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/potion.png");
    private static final Identifier KEYBOARD_ICON = Identifier.fromNamespaceAndPath(
            DonutUtilitiesClient.MOD_ID, "textures/gui/keyboard.png");
    private static final long MODULE_LIST_ENTER_MS = 230L;
    private static final long MODULE_LIST_EXIT_MS = 260L;
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final Map<String, ModuleListState> moduleListStates = new HashMap<>();
    private static boolean moduleListInitialized;

    private DonutHudRenderer() {
    }

    public static void render(GuiGraphics graphics, DeltaTracker tickCounter) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.options.hideGui) {
            return;
        }

        ModuleToastManager.render(graphics);
        drawWatermark(graphics);
        if (DonutUtilitiesClient.MODULES.enabled("module_list")) {
            drawModuleList(graphics);
        }
        if (DonutUtilitiesClient.MODULES.enabled("donut_region_map")) {
            DonutRegionMapRenderer.render(graphics);
        }
        if (!DonutUtilitiesClient.MODULES.enabled("hud")) {
            return;
        }

        HudSettings settings = DonutUtilitiesClient.MODULES.hudSettings();
        int widgetY = drawInfoStack(graphics, client);
        if (settings.potions()) {
            widgetY = drawPotionsPanel(graphics, client, 8, widgetY);
        }
        if (settings.keybinds()) {
            drawKeybindsPanel(graphics, 8, widgetY);
        }

    }

    private static void drawCard(GuiGraphics graphics, int x, int y, int width, int height, String title, String icon) {
        HudTheme.frame(graphics, x, y, width, height);
        graphics.fill(x + 10, y + 27, x + width - 10, y + 28, 0x553D4655);
        HudTheme.text(graphics, title, x + 12, y + 8, HudTheme.TEXT);
        drawSmallIcon(graphics, x + width - 24, y + 7, icon);
    }

    private static void drawScanCard(GuiGraphics graphics, int x, int y, int width, int height, BlockPos pos) {
        drawCard(graphics, x, y, width, height, "DONUT SMP", "compass");
        HudTheme.text(graphics, "POSITION", x + 12, y + 36, HudTheme.MUTED);
        String xyz = pos.getX() + "  " + pos.getY() + "  " + pos.getZ();
        HudTheme.text(graphics, HudTheme.fit(xyz, HudTheme.unscaledWidth(width - 24)), x + 12, y + 48, HudTheme.BLUE);
        HudTheme.text(graphics, "WORLD READY", x + 12, y + 60, 0xFF8FE0A0);
        HudTheme.text(graphics, "LIVE", x + width - 42, y + 60, HudTheme.MUTED);
    }

    private static void drawEspCard(GuiGraphics graphics, int x, int y, int width, int height) {
        drawCard(graphics, x, y, width, height, "SCAN OVERVIEW", "scan");
        int markers = DonutUtilitiesClient.SCANNER.markers().size();
        long storage = DonutUtilitiesClient.SCANNER.markers().stream().filter(marker -> marker.type() == MarkerType.STORAGE).count();
        long chunks = DonutUtilitiesClient.SCANNER.markers().stream().filter(marker -> marker.type() == MarkerType.SUS_CHUNK).count();
        long blocks = DonutUtilitiesClient.SCANNER.markers().stream().filter(marker -> marker.type() == MarkerType.BLOCK_ESP).count();
        long suspicious = DonutUtilitiesClient.SCANNER.markers().stream().filter(marker -> marker.type() == MarkerType.SUSPICIOUS).count();
        drawStat(graphics, x + 12, y + 36, "MARKERS", markers, markers > 0 ? HudTheme.BLUE : HudTheme.MUTED);
        drawStat(graphics, x + 122, y + 36, "STORAGE", storage, storage > 0 ? 0xFFFFD25A : HudTheme.MUTED);
        drawStat(graphics, x + 12, y + 52, "CHUNKS", chunks, chunks > 0 ? 0xFFFF7A90 : HudTheme.MUTED);
        drawStat(graphics, x + 122, y + 52, "BLOCKS", blocks, blocks > 0 ? 0xFF9FE870 : HudTheme.MUTED);
        BaseMarker strongest = DonutUtilitiesClient.SCANNER.strongestMarkers(1).stream().findFirst().orElse(null);
        String signal = strongest == null ? "NO BASE SIGNAL" : HudTheme.fit(strongest.label().toUpperCase(java.util.Locale.ROOT), HudTheme.unscaledWidth(width - 24));
        HudTheme.text(graphics, signal, x + 12, y + 67, suspicious > 0 ? 0xFFFF9B7A : HudTheme.MUTED);
    }

    private static void drawStat(GuiGraphics graphics, int x, int y, String label, long value, int color) {
        HudTheme.text(graphics, label, x, y, HudTheme.MUTED);
        HudTheme.text(graphics, Long.toString(value), x + 56, y, color);
    }

    private static void drawWatermark(GuiGraphics graphics) {
        String text = "Noctium Client+";
        var settings = DonutUtilitiesClient.MODULES.visualsSettings();
        boolean showLogo = !DonutUtilitiesClient.MODULES.enabled("visuals")
                || settings.watermarkLogo();
        int logoWidth = 15;
        int textOffset = showLogo ? 5 + logoWidth + 4 + 5 : 6;
        int width = textOffset + HudTheme.scaledWidth(text) + 5;
        int height = 16;
        int x = hudPosition(graphics.guiWidth(), width, settings.watermarkPositionX(), 2);
        int y = hudPosition(graphics.guiHeight(), height, settings.watermarkPositionY(), 3);
        int logoX = x + 5;
        int separatorX = logoX + logoWidth + 4;
        int textX = x + textOffset;
        int background = withAlpha(0xFF151820, settings.watermarkTransparency() * 255 / 100);
        int watermarkColor = settings.renderedWatermarkColor(System.currentTimeMillis());
        if (!NanoVgWatermarkRenderer.drawBackground(graphics, x, y, width, height, background)) {
            RoundedRectRenderer.roundedRect(graphics, x, y, width, height, 5, background);
        }
        graphics.fill(x, y, x + 2, y + height, watermarkColor);
        if (showLogo) {
            graphics.pose().pushMatrix();
            graphics.pose().translate(logoX, y + 3);
            float logoScale = logoWidth / 60.0F;
            graphics.pose().scale(logoScale, logoScale);
            graphics.blit(RenderPipelines.GUI_TEXTURED, NOCTIUM_LOGO, 0, 0, 0.0F, 0.0F,
                    60, 36, 60, 36);
            graphics.pose().popMatrix();
            graphics.fill(separatorX, y + 3, separatorX + 1, y + height - 3,
                    withAlpha(watermarkColor, 102));
        }
        int textY = y + Math.max(0, (height - Math.round(9 * HudTheme.TEXT_SCALE)) / 2);
        HudTheme.text(graphics, text, textX, textY, watermarkColor);
    }

    private static int drawInfoStack(GuiGraphics graphics, Minecraft client) {
        BlockPos pos = client.player.blockPosition();
        double horizontalSpeed = Math.hypot(client.player.getDeltaMovement().x, client.player.getDeltaMovement().z) * 20.0D;
        HudSettings settings = DonutUtilitiesClient.MODULES.hudSettings();

        if (settings.singleRow()) {
            return drawSingleRowInfo(graphics, client, settings, pos, horizontalSpeed);
        }

        int x = 8;
        int y = 28;
        if (settings.coordinates()) y = drawCoordinatesPill(
                graphics, x, y, "XYZ " + pos.getX() + "/" + pos.getY() + "/" + pos.getZ());
        if (settings.realTime()) y = drawIconHudPill(
                graphics, x, y, "TIME " + LocalTime.now().format(TIME_FORMAT), CLOCK_ICON, HudTheme.TEXT);
        if (settings.ping()) y = drawIconHudPill(
                graphics, x, y, "PING " + ping(client) + "ms", CLIENT_ICON, HudTheme.TEXT);
        if (settings.ticks()) y = drawIconHudPill(graphics, x, y, "TPS 20.0", SERVER_ICON, HudTheme.TEXT);
        if (settings.bps()) y = drawIconHudPill(graphics, x, y,
                String.format(Locale.ROOT, "BPS %.2f", horizontalSpeed), SPEEDTEST_ICON, HudTheme.TEXT);
        return y;
    }

    private static int drawSingleRowInfo(GuiGraphics graphics, Minecraft client, HudSettings settings,
            BlockPos pos, double horizontalSpeed) {
        List<String> values = new ArrayList<>();
        if (settings.coordinates()) values.add("XYZ " + pos.getX() + "/" + pos.getY() + "/" + pos.getZ());
        if (settings.realTime()) values.add("TIME " + LocalTime.now().format(TIME_FORMAT));
        if (settings.ping()) values.add("PING " + ping(client) + "ms");
        if (settings.ticks()) values.add("TPS 20.0");
        if (settings.bps()) values.add(String.format(Locale.ROOT, "BPS %.2f", horizontalSpeed));
        if (values.isEmpty()) {
            return 28;
        }

        int x = 8;
        int y = 28;
        int height = 14;
        int padding = 6;
        int separatorGap = 5;
        int width = 2 + padding;
        for (int index = 0; index < values.size(); index++) {
            width += HudTheme.scaledWidth(values.get(index)) + padding * 2;
            if (index + 1 < values.size()) {
                width += separatorGap;
            }
        }

        if (!NanoVgWatermarkRenderer.drawBackground(graphics, x, y, width, height, 0x8D151820)) {
            RoundedRectRenderer.roundedRect(graphics, x, y, width, height, 5, 0x8D151820);
        }
        graphics.fill(x, y, x + 2, y + height, visualAccent());
        int textY = y + Math.max(0, (height - Math.round(9 * HudTheme.TEXT_SCALE)) / 2);
        int cursor = x + 2 + padding;
        for (int index = 0; index < values.size(); index++) {
            String value = values.get(index);
            HudTheme.text(graphics, value, cursor, textY, HudTheme.TEXT);
            cursor += HudTheme.scaledWidth(value) + padding;
            if (index + 1 < values.size()) {
                graphics.fill(cursor, y + 3, cursor + 1, y + height - 3, 0x668B93A3);
                cursor += separatorGap + padding;
            }
        }
        return y + height + 2;
    }

    private static int drawPotionsPanel(GuiGraphics graphics, Minecraft client, int x, int y) {
        List<MobEffectInstance> effects = new ArrayList<>(client.player.getActiveEffects());
        effects.sort(MobEffectInstance::compareTo);
        int rows = Math.max(1, effects.size());
        int width = 132;
        for (MobEffectInstance effect : effects) {
            String name = potionName(effect);
            String duration = potionDuration(effect);
            width = Math.max(width, 23 + HudTheme.scaledWidth(name) + HudTheme.scaledWidth(duration) + 12);
        }
        width = Math.min(230, width);
        int height = 18 + rows * 14;
        HudSettings settings = DonutUtilitiesClient.MODULES.hudSettings();
        if (settings.potionPositionCustomized()) {
            x = hudPosition(graphics.guiWidth(), width, settings.potionPositionX(), -1);
            y = hudPosition(graphics.guiHeight(), height, settings.potionPositionY(), -1);
        }
        drawCompactPanel(graphics, x, y, width, height, "POTIONS", POTION_ICON);

        if (effects.isEmpty()) {
            RoundedRectRenderer.roundedRect(graphics, x, y + 18, width, 11, 2, 0xA6313643);
            HudTheme.text(graphics, "NO ACTIVE EFFECTS", x + 6, y + 20, HudTheme.MUTED);
        } else {
            int rowY = y + 18;
            for (MobEffectInstance effect : effects) {
                RoundedRectRenderer.roundedRect(graphics, x, rowY, width, 11, 2, 0xA6313643);
                graphics.blitSprite(RenderPipelines.GUI_TEXTURED, Gui.getMobEffectSprite(effect.getEffect()),
                        x + 5, rowY + 1, 9, 9);
                String duration = potionDuration(effect);
                String name = HudTheme.fit(potionName(effect),
                        HudTheme.unscaledWidth(width - 28 - HudTheme.scaledWidth(duration)));
                HudTheme.text(graphics, name, x + 18, rowY + 1, HudTheme.TEXT);
                HudTheme.text(graphics, duration, x + width - 5 - HudTheme.scaledWidth(duration),
                        rowY + 1, 0xFFB9C7DC);
                rowY += 14;
            }
        }
        return y + height + 4;
    }

    private static int drawKeybindsPanel(GuiGraphics graphics, int x, int y) {
        List<Module> bound = DonutUtilitiesClient.MODULES.modules().stream()
                .filter(module -> module.keyCode() != GLFW.GLFW_KEY_UNKNOWN)
                .toList();
        int rows = Math.max(1, bound.size());
        int width = 132;
        for (Module module : bound) {
            width = Math.max(width, HudTheme.scaledWidth(module.name())
                    + HudTheme.scaledWidth(module.keyName()) + 24);
        }
        width = Math.min(230, width);
        int height = 18 + rows * 14;
        HudSettings settings = DonutUtilitiesClient.MODULES.hudSettings();
        if (settings.keybindPositionCustomized()) {
            x = hudPosition(graphics.guiWidth(), width, settings.keybindPositionX(), -1);
            y = hudPosition(graphics.guiHeight(), height, settings.keybindPositionY(), -1);
        }
        drawCompactPanel(graphics, x, y, width, height, "KEYBINDS", KEYBOARD_ICON);

        if (bound.isEmpty()) {
            RoundedRectRenderer.roundedRect(graphics, x, y + 18, width, 11, 2, 0xA6313643);
            HudTheme.text(graphics, "NO BINDS", x + 6, y + 20, HudTheme.MUTED);
        } else {
            int rowY = y + 18;
            for (Module module : bound) {
                RoundedRectRenderer.roundedRect(graphics, x, rowY, width, 11, 2, 0xA6313643);
                String key = module.keyName();
                String name = HudTheme.fit(module.name().toUpperCase(Locale.ROOT),
                        HudTheme.unscaledWidth(width - 17 - HudTheme.scaledWidth(key)));
                HudTheme.text(graphics, name, x + 6, rowY + 1,
                        module.enabled() ? HudTheme.TEXT : HudTheme.MUTED);
                HudTheme.text(graphics, key, x + width - 6 - HudTheme.scaledWidth(key),
                        rowY + 1, module.enabled() ? visualAccent() : 0xFFB9C0CB);
                rowY += 14;
            }
        }
        return y + height + 4;
    }

    private static void drawCompactPanel(GuiGraphics graphics, int x, int y, int width, int height,
            String title, Identifier icon) {
        RoundedRectRenderer.roundedRect(graphics, x, y, width, 16, 4, 0xA6151820);
        HudSettings settings = DonutUtilitiesClient.MODULES.hudSettings();
        int textX = x + 6;
        if (settings.panelIcons()) {
            int iconSize = 9;
            int iconX = x + 5;
            int separatorX = iconX + iconSize + 4;
            graphics.pose().pushMatrix();
            graphics.pose().translate(iconX, y + 3);
            float iconScale = iconSize / 36.0F;
            graphics.pose().scale(iconScale, iconScale);
            graphics.blit(RenderPipelines.GUI_TEXTURED, icon, 0, 0, 0.0F, 0.0F,
                    36, 36, 36, 36, settings.renderedPanelIconColor(System.currentTimeMillis()));
            graphics.pose().popMatrix();
            graphics.fill(separatorX, y + 3, separatorX + 1, y + 13, 0x668B93A3);
            textX = separatorX + 5;
        }
        HudTheme.text(graphics, title, textX, y + 3, HudTheme.TEXT);
    }

    private static String potionName(MobEffectInstance effect) {
        String name = net.minecraft.network.chat.Component.translatable(effect.getDescriptionId())
                .getString().toUpperCase(Locale.ROOT);
        int level = effect.getAmplifier() + 1;
        return level > 1 ? name + " " + roman(level) : name;
    }

    private static String potionDuration(MobEffectInstance effect) {
        if (effect.isInfiniteDuration()) {
            return "INFINITE";
        }
        int seconds = Math.max(0, (effect.getDuration() + 19) / 20);
        int hours = seconds / 3600;
        int minutes = seconds % 3600 / 60;
        int remaining = seconds % 60;
        return hours > 0
                ? String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, remaining)
                : String.format(Locale.ROOT, "%d:%02d", minutes, remaining);
    }

    private static String roman(int value) {
        return switch (Math.min(value, 10)) {
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            case 8 -> "VIII";
            case 9 -> "IX";
            case 10 -> "X";
            default -> Integer.toString(value);
        };
    }

    private static int drawHudPill(GuiGraphics graphics, int x, int y, String text, int color) {
        int width = HudTheme.scaledWidth(text) + 11;
        int height = 14;
        if (!NanoVgWatermarkRenderer.drawBackground(graphics, x, y, width, height, 0x8D151820)) {
            RoundedRectRenderer.roundedRect(graphics, x, y, width, height, 5, 0x8D151820);
        }
        graphics.fill(x, y, x + 2, y + height, visualAccent());
        int textY = y + Math.max(0, (height - Math.round(9 * HudTheme.TEXT_SCALE)) / 2);
        HudTheme.text(graphics, text, x + 6, textY, color);
        return y + 16;
    }

    private static int drawCoordinatesPill(GuiGraphics graphics, int x, int y, String text) {
        return drawIconHudPill(graphics, x, y, text, WORLD_ICON, HudTheme.TEXT);
    }

    private static int drawIconHudPill(GuiGraphics graphics, int x, int y, String text,
            Identifier icon, int color) {
        int iconSize = 9;
        int iconX = x + 5;
        int separatorX = iconX + iconSize + 4;
        int textX = separatorX + 5;
        int width = textX - x + HudTheme.scaledWidth(text) + 5;
        int height = 14;
        if (!NanoVgWatermarkRenderer.drawBackground(graphics, x, y, width, height, 0x8D151820)) {
            RoundedRectRenderer.roundedRect(graphics, x, y, width, height, 5, 0x8D151820);
        }
        graphics.fill(x, y, x + 2, y + height, visualAccent());
        graphics.pose().pushMatrix();
        graphics.pose().translate(iconX, y + 2);
        float iconScale = iconSize / 36.0F;
        graphics.pose().scale(iconScale, iconScale);
        graphics.blit(RenderPipelines.GUI_TEXTURED, icon, 0, 0, 0.0F, 0.0F,
                36, 36, 36, 36, hudIconColor());
        graphics.pose().popMatrix();
        graphics.fill(separatorX, y + 3, separatorX + 1, y + height - 3, 0x668B93A3);
        int textY = y + Math.max(0, (height - Math.round(9 * HudTheme.TEXT_SCALE)) / 2);
        HudTheme.text(graphics, text, textX, textY, color);
        return y + 16;
    }

    private static int ping(Minecraft client) {
        try {
            if (client.getConnection() == null || client.player == null) {
                return 0;
            }
            var info = client.getConnection().getPlayerInfo(client.player.getUUID());
            return info == null ? 0 : info.getLatency();
        } catch (RuntimeException exception) {
            return 0;
        }
    }

    private static void drawModuleList(GuiGraphics graphics) {
        int screenWidth = Minecraft.getInstance().getWindow().getGuiScaledWidth();
        long now = System.currentTimeMillis();
        int y = 8;
        int edgeGap = 5;
        int right = screenWidth - edgeGap;
        int maxWidth = 250;
        int rowHeight = 12;
        int rowGap = 1;
        int textRightPadding = 2;
        int accentWidth = 2;
        int leftPadding = 3;
        int centerPadding = 0;

        syncModuleListStates(now);

        List<Module> visibleModules = DonutUtilitiesClient.MODULES.modules().stream()
                .filter(DonutHudRenderer::isModuleListVisible)
                .filter(module -> module.enabled() || stillExiting(module, now))
                .toList();

        int rowIndex = 0;
        for (Module module : visibleModules) {
            ModuleListState state = moduleListStates.get(module.id());
            float visible = moduleListProgress(state, now);
            if (visible <= 0.0F) {
                continue;
            }

            String name = module.name().toUpperCase(Locale.ROOT);
            String fitted = HudTheme.fit(name, HudTheme.unscaledWidth(maxWidth));
            int width = HudTheme.scaledWidth(fitted);
            int textAreaWidth = width + centerPadding;
            int rowWidth = textAreaWidth + leftPadding + textRightPadding + accentWidth;
            int slide = Math.round((rowWidth + 14) * (1.0F - visible));
            int animatedRight = right + slide;
            int rowX = animatedRight - rowWidth;
            int alpha = Math.round(255.0F * visible);

            RoundedRectRenderer.roundedLeftRect(graphics, rowX, y, rowWidth, rowHeight, 4,
                    withAlpha(0x151820, Math.round(141.0F * visible)));
            graphics.fill(animatedRight - accentWidth, y, animatedRight, y + rowHeight,
                    withAlpha(visualAccent(), alpha));
            int textAreaX = rowX + leftPadding;
            int textX = textAreaX + Math.max(0, (textAreaWidth - width) / 2);
            int textColor = DonutUtilitiesClient.MODULES.moduleListSettings().renderedColor(now, rowIndex);
            HudTheme.text(graphics, fitted, textX, y + 1, withAlpha(textColor, alpha));
            y += rowHeight + rowGap;
            rowIndex++;
        }
    }

    private static void syncModuleListStates(long now) {
        for (Module module : DonutUtilitiesClient.MODULES.modules()) {
            if (!isModuleListVisible(module)) {
                moduleListStates.remove(module.id());
                continue;
            }

            ModuleListState state = moduleListStates.get(module.id());
            if (state == null) {
                long startedAt = moduleListInitialized ? now : now - MODULE_LIST_ENTER_MS;
                moduleListStates.put(module.id(), new ModuleListState(module.enabled(), startedAt));
                continue;
            }
            if (state.enabled != module.enabled()) {
                state.enabled = module.enabled();
                state.changedAt = now;
            }
        }
        moduleListInitialized = true;
    }

    private static boolean isModuleListVisible(Module module) {
        return !module.id().equals("module_list")
                && !module.id().equals("click_gui")
                && !module.id().equals("hud")
                && !module.id().equals("popup");
    }

    private static int visualAccent() {
        return DonutUtilitiesClient.MODULES.enabled("visuals")
                ? DonutUtilitiesClient.MODULES.visualsSettings().renderedAccent(System.currentTimeMillis())
                : HudTheme.BLUE;
    }

    private static int hudIconColor() {
        return DonutUtilitiesClient.MODULES.enabled("visuals")
                ? DonutUtilitiesClient.MODULES.visualsSettings().renderedHudIconColor(System.currentTimeMillis())
                : 0xFFFFFFFF;
    }

    private static int hudPosition(int screenSize, int elementSize, int percent, int snapThreshold) {
        if (percent <= snapThreshold) {
            return 8;
        }
        int available = Math.max(0, screenSize - elementSize - 16);
        return 8 + Math.round(available * percent / 100.0F);
    }

    private static boolean stillExiting(Module module, long now) {
        ModuleListState state = moduleListStates.get(module.id());
        return state != null && !state.enabled && now - state.changedAt < MODULE_LIST_EXIT_MS;
    }

    private static float moduleListProgress(ModuleListState state, long now) {
        if (state == null) {
            return 0.0F;
        }
        long elapsed = now - state.changedAt;
        float raw = state.enabled
                ? Math.min(1.0F, elapsed / (float) MODULE_LIST_ENTER_MS)
                : Math.max(0.0F, 1.0F - elapsed / (float) MODULE_LIST_EXIT_MS);
        return easeOut(raw);
    }

    private static float easeOut(float value) {
        return 1.0F - (1.0F - value) * (1.0F - value);
    }

    private static int withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
    }

    private static final class ModuleListState {
        private boolean enabled;
        private long changedAt;

        private ModuleListState(boolean enabled, long changedAt) {
            this.enabled = enabled;
            this.changedAt = changedAt;
        }
    }

    private static void drawSmallIcon(GuiGraphics graphics, int x, int y, String icon) {
        int color = 0xFFD7DAE2;
        if (icon.equals("clock")) {
            RoundedRectRenderer.roundedRect(graphics, x, y, 11, 11, 5, 0x00000000);
            graphics.fill(x + 5, y + 2, x + 6, y + 6, color);
            graphics.fill(x + 5, y + 5, x + 9, y + 6, color);
            RoundedRectRenderer.roundedRect(graphics, x - 1, y - 1, 13, 13, 6, 0x34FFFFFF);
            return;
        }
        if (icon.equals("potion")) {
            RoundedRectRenderer.roundedRect(graphics, x + 3, y + 1, 5, 3, 2, color);
            RoundedRectRenderer.roundedRect(graphics, x + 1, y + 4, 9, 9, 4, 0x34FFFFFF);
            graphics.fill(x + 4, y + 7, x + 8, y + 10, color);
            return;
        }
        if (icon.equals("compass")) {
            RoundedRectRenderer.roundedRect(graphics, x - 1, y - 1, 13, 13, 6, 0x34FFFFFF);
            graphics.fill(x + 5, y + 2, x + 6, y + 10, color);
            graphics.fill(x + 2, y + 5, x + 10, y + 6, color);
            graphics.fill(x + 7, y + 3, x + 9, y + 5, HudTheme.BLUE);
            return;
        }
        if (icon.equals("scan")) {
            graphics.fill(x, y + 2, x + 4, y + 3, color);
            graphics.fill(x + 8, y + 2, x + 12, y + 3, color);
            graphics.fill(x, y + 9, x + 4, y + 10, color);
            graphics.fill(x + 8, y + 9, x + 12, y + 10, color);
            graphics.fill(x + 5, y + 5, x + 8, y + 8, HudTheme.BLUE);
            return;
        }
        RoundedRectRenderer.roundedRect(graphics, x, y + 1, 12, 10, 2, 0x34FFFFFF);
        graphics.fill(x + 2, y + 4, x + 4, y + 6, color);
        graphics.fill(x + 5, y + 4, x + 7, y + 6, color);
        graphics.fill(x + 8, y + 4, x + 10, y + 6, color);
        graphics.fill(x + 3, y + 8, x + 9, y + 9, color);
    }
}
