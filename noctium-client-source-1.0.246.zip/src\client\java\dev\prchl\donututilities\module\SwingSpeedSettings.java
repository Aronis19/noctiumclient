package dev.prchl.donututilities.module;

import dev.prchl.donututilities.DonutUtilitiesClient;

public final class SwingSpeedSettings {
    public static final int MIN_SPEED = 0;
    public static final int MAX_SPEED = 10;
    private int speed = 8;

    public int speed() {
        return speed;
    }

    public void setSpeed(int speed) {
        int clamped = Math.max(MIN_SPEED, Math.min(MAX_SPEED, speed));
        if (this.speed == clamped) {
            return;
        }
        this.speed = clamped;
        DonutUtilitiesClient.markConfigDirty();
    }

    public int swingDurationTicks() {
        return speed == 0 ? 16 : Math.max(1, 11 - speed);
    }
}
