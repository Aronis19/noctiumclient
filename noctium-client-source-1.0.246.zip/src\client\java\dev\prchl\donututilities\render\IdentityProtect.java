package dev.prchl.donututilities.render;

import dev.prchl.donututilities.DonutUtilitiesClient;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.world.item.component.ResolvableProfile;

public final class IdentityProtect {
    private IdentityProtect() {
    }

    public static Component protectedName(UUID playerId, Component original) {
        if (!DonutUtilitiesClient.MODULES.enabled("name_protect")) return original;
        Minecraft client = Minecraft.getInstance();
        boolean own = client.player != null && client.player.getUUID().equals(playerId);
        if (own) {
            return styled(DonutUtilitiesClient.MODULES.nameProtectSettings().fakeName(), original);
        }
        if (DonutUtilitiesClient.MODULES.nameProtectSettings().hideOthers()) {
            return styled("Player", original);
        }
        return original;
    }

    public static String protectedName(UUID playerId, String original) {
        return protectedName(playerId, Component.literal(original)).getString();
    }

    public static Component protectedText(Component original) {
        if (original == null || !DonutUtilitiesClient.MODULES.enabled("name_protect")) return original;
        Map<String, String> replacements = replacements();
        if (replacements.isEmpty() || !containsReplacement(original.getString(), replacements)) return original;

        MutableComponent result = Component.empty();
        boolean changed = false;
        for (Component part : original.toFlatList()) {
            String value = replaceNames(part.getString(), replacements);
            changed |= !value.equals(part.getString());
            result.append(Component.literal(value).withStyle(part.getStyle()));
        }
        return changed ? result : original;
    }

    public static String protectedText(String original) {
        if (original == null || !DonutUtilitiesClient.MODULES.enabled("name_protect")) return original;
        return replaceNames(original, replacements());
    }

    public static PlayerSkin protectedSkin(UUID playerId, PlayerSkin original) {
        if (!DonutUtilitiesClient.MODULES.enabled("skin_protect")) return original;
        Minecraft client = Minecraft.getInstance();
        boolean own = client.player != null && client.player.getUUID().equals(playerId);
        var settings = DonutUtilitiesClient.MODULES.skinProtectSettings();
        if ((own && !settings.changeOwnSkin()) || (!own && !settings.changeOthersSkin())) return original;
        String owner = settings.skinOwner();
        if (owner == null || owner.isBlank()) return original;
        try {
            return client.playerSkinRenderCache()
                    .getOrDefault(ResolvableProfile.createUnresolved(owner))
                    .playerSkin();
        } catch (RuntimeException ignored) {
            return original;
        }
    }

    private static Component styled(String value, Component original) {
        return Component.literal(value).withStyle(original == null ? net.minecraft.network.chat.Style.EMPTY : original.getStyle());
    }

    private static Map<String, String> replacements() {
        Minecraft client = Minecraft.getInstance();
        Map<String, String> replacements = new LinkedHashMap<>();
        if (client.player == null) return replacements;

        String ownName = client.player.getGameProfile().name();
        String fakeName = DonutUtilitiesClient.MODULES.nameProtectSettings().fakeName();
        if (ownName != null && !ownName.isBlank() && !ownName.equals(fakeName)) {
            replacements.put(ownName, fakeName);
        }

        if (DonutUtilitiesClient.MODULES.nameProtectSettings().hideOthers() && client.getConnection() != null) {
            client.getConnection().getOnlinePlayers().forEach(info -> {
                String name = info.getProfile().name();
                if (name != null && !name.isBlank() && !name.equals(ownName)) replacements.put(name, "Player");
            });
        }
        return replacements;
    }

    private static boolean containsReplacement(String value, Map<String, String> replacements) {
        for (String name : replacements.keySet()) {
            if (value.contains(name)) return true;
        }
        return false;
    }

    private static String replaceNames(String value, Map<String, String> replacements) {
        String result = value;
        for (Map.Entry<String, String> entry : replacements.entrySet()) {
            result = result.replace(entry.getKey(), entry.getValue());
        }
        return result;
    }
}
