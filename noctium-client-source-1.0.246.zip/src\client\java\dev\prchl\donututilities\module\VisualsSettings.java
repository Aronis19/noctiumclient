package dev.prchl.donututilities.module;

import dev.prchl.donututilities.DonutUtilitiesClient;
import java.util.Locale;
import net.minecraft.util.Mth;

public final class VisualsSettings {
    private static final int DEFAULT_ACCENT = 0xFF79C8FF;
    public static final int MIN_WATERMARK_TRANSPARENCY = 10;
    public static final int MAX_WATERMARK_TRANSPARENCY = 100;
    public static final int MIN_WATERMARK_POSITION = 0;
    public static final int MAX_WATERMARK_POSITION = 100;

    private String accentColorHex = "#79C8FF";
    private int accentColor = DEFAULT_ACCENT;
    private boolean rainbow;
    private boolean watermarkLogo = true;
    private String watermarkColorHex = "#79C8FF";
    private int watermarkColor = DEFAULT_ACCENT;
    private int watermarkTransparency = 55;
    private int watermarkPositionX;
    private int watermarkPositionY;
    private boolean watermarkRainbow;
    private String hudIconColorHex = "#FFFFFF";
    private int hudIconColor = 0xFFFFFFFF;
    private boolean hudIconRainbow;

    public String accentColorHex() {
        return accentColorHex;
    }

    public int accentColor() {
        return accentColor;
    }

    public boolean rainbow() {
        return rainbow;
    }

    public boolean watermarkLogo() {
        return watermarkLogo;
    }

    public int renderedAccent(long now) {
        if (!rainbow) {
            return accentColor;
        }
        float hue = (now % 6000L) / 6000.0F;
        return 0xFF000000 | Mth.hsvToRgb(hue, 0.72F, 1.0F);
    }

    public void setAccentColorHex(String value) {
        String clean = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
        if (clean.startsWith("#")) {
            clean = clean.substring(1);
        }
        clean = clean.replaceAll("[^0-9A-F]", "");
        if (clean.length() > 6) {
            clean = clean.substring(0, 6);
        }
        accentColorHex = "#" + clean;
        if (clean.length() == 6) {
            try {
                accentColor = 0xFF000000 | Integer.parseInt(clean, 16);
            } catch (NumberFormatException ignored) {
                accentColor = DEFAULT_ACCENT;
            }
        }
        DonutUtilitiesClient.markConfigDirty();
    }

    public void toggleRainbow() {
        rainbow = !rainbow;
        DonutUtilitiesClient.markConfigDirty();
    }

    public void toggleWatermarkLogo() {
        watermarkLogo = !watermarkLogo;
        DonutUtilitiesClient.markConfigDirty();
    }

    public String watermarkColorHex() {
        return watermarkColorHex;
    }

    public int watermarkColor() {
        return watermarkColor;
    }

    public void setWatermarkColorHex(String value) {
        String clean = sanitizeHex(value);
        watermarkColorHex = "#" + clean;
        if (clean.length() == 6) {
            try {
                watermarkColor = 0xFF000000 | Integer.parseInt(clean, 16);
            } catch (NumberFormatException ignored) {
                watermarkColor = DEFAULT_ACCENT;
            }
        }
        DonutUtilitiesClient.markConfigDirty();
    }

    public int watermarkTransparency() {
        return watermarkTransparency;
    }

    public void setWatermarkTransparency(int value) {
        watermarkTransparency = clamp(value, MIN_WATERMARK_TRANSPARENCY, MAX_WATERMARK_TRANSPARENCY);
        DonutUtilitiesClient.markConfigDirty();
    }

    public int watermarkPositionX() {
        return watermarkPositionX;
    }

    public void setWatermarkPositionX(int value) {
        watermarkPositionX = clamp(value, MIN_WATERMARK_POSITION, MAX_WATERMARK_POSITION);
        DonutUtilitiesClient.markConfigDirty();
    }

    public int watermarkPositionY() {
        return watermarkPositionY;
    }

    public void setWatermarkPositionY(int value) {
        watermarkPositionY = clamp(value, MIN_WATERMARK_POSITION, MAX_WATERMARK_POSITION);
        DonutUtilitiesClient.markConfigDirty();
    }

    public boolean watermarkRainbow() {
        return watermarkRainbow;
    }

    public void toggleWatermarkRainbow() {
        watermarkRainbow = !watermarkRainbow;
        DonutUtilitiesClient.markConfigDirty();
    }

    public int renderedWatermarkColor(long now) {
        return watermarkRainbow ? rainbowColor(now) : watermarkColor;
    }

    public String hudIconColorHex() {
        return hudIconColorHex;
    }

    public int hudIconColor() {
        return hudIconColor;
    }

    public void setHudIconColorHex(String value) {
        String clean = sanitizeHex(value);
        hudIconColorHex = "#" + clean;
        if (clean.length() == 6) {
            try {
                hudIconColor = 0xFF000000 | Integer.parseInt(clean, 16);
            } catch (NumberFormatException ignored) {
                hudIconColor = 0xFFFFFFFF;
            }
        }
        DonutUtilitiesClient.markConfigDirty();
    }

    public boolean hudIconRainbow() {
        return hudIconRainbow;
    }

    public void toggleHudIconRainbow() {
        hudIconRainbow = !hudIconRainbow;
        DonutUtilitiesClient.markConfigDirty();
    }

    public int renderedHudIconColor(long now) {
        return hudIconRainbow ? rainbowColor(now) : hudIconColor;
    }

    private static int rainbowColor(long now) {
        float hue = (now % 6000L) / 6000.0F;
        return 0xFF000000 | Mth.hsvToRgb(hue, 0.72F, 1.0F);
    }

    private static String sanitizeHex(String value) {
        String clean = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
        if (clean.startsWith("#")) {
            clean = clean.substring(1);
        }
        clean = clean.replaceAll("[^0-9A-F]", "");
        return clean.length() > 6 ? clean.substring(0, 6) : clean;
    }

    private static int clamp(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
