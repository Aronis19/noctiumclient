package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.freecam.FreecamController;
import net.minecraft.client.CameraType;
import net.minecraft.client.Options;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Options.class)
public abstract class FreecamCameraTypeMixin {
    @Inject(method = "getCameraType", at = @At("HEAD"), cancellable = true)
    private void donututilities$renderPlayerBodyInFreecam(CallbackInfoReturnable<CameraType> info) {
        if (FreecamController.active()) {
            info.setReturnValue(CameraType.THIRD_PERSON_BACK);
        }
    }
}
