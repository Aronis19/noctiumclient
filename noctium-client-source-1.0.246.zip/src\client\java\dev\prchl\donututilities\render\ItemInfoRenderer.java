package dev.prchl.donututilities.render;

import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.mixin.GameRendererAccessor;
import dev.prchl.donututilities.module.ItemInfoModule;
import dev.prchl.donututilities.render.shape.RoundedRectRenderer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

public final class ItemInfoRenderer {
    private static final int MAX_ITEMS = 256;
    private static List<ProjectedItem> projectedItems = List.of();

    private ItemInfoRenderer() {
    }

    public static void register() {
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(ItemInfoRenderer::captureWorldPositions);
    }

    private static void captureWorldPositions(WorldRenderContext context) {
        Minecraft client = Minecraft.getInstance();
        if (!DonutUtilitiesClient.MODULES.enabled("item_info")
                || client.level == null || client.player == null || client.options.hideGui) {
            projectedItems = List.of();
            return;
        }

        Camera camera = client.gameRenderer.getMainCamera();
        float partialTick = camera.getPartialTickTime();
        float fov = ((GameRendererAccessor) client.gameRenderer)
                .donututilities$getFov(camera, partialTick, true);
        Matrix4f projection = client.gameRenderer.getProjectionMatrix(fov);
        Vec3 cameraPos = camera.position();
        Quaternionf inverseCameraRotation = new Quaternionf(camera.rotation()).conjugate();
        int screenWidth = client.getWindow().getGuiScaledWidth();
        int screenHeight = client.getWindow().getGuiScaledHeight();
        double maxDistance = Math.max(96.0D, client.options.renderDistance().get() * 16.0D + 16.0D);
        double maxDistanceSqr = maxDistance * maxDistance;
        ItemInfoModule settings = DonutUtilitiesClient.MODULES.itemInfoModule();
        List<ProjectedItem> captured = new ArrayList<>();

        for (Entity entity : client.level.entitiesForRendering()) {
            if (!(entity instanceof ItemEntity item) || item.isRemoved() || item.getItem().isEmpty()) continue;
            double distanceSqr = cameraPos.distanceToSqr(item.position());
            if (distanceSqr > maxDistanceSqr) continue;

            Vec3 anchor = item.getPosition(partialTick)
                    .add(0.0D, item.getBbHeight() + settings.heightOffset() + 0.5D, 0.0D);
            Vector3f cameraSpace = new Vector3f(
                    (float) (anchor.x - cameraPos.x),
                    (float) (anchor.y - cameraPos.y),
                    (float) (anchor.z - cameraPos.z));
            inverseCameraRotation.transform(cameraSpace);
            Vector4f clip = new Vector4f(cameraSpace, 1.0F);
            projection.transform(clip);
            if (clip.w <= 0.001F) continue;

            float ndcX = clip.x / clip.w;
            float ndcY = clip.y / clip.w;
            if (ndcX < -1.1F || ndcX > 1.1F || ndcY < -1.1F || ndcY > 1.1F) continue;
            int x = Math.round((ndcX * 0.5F + 0.5F) * screenWidth);
            int y = Math.round((0.5F - ndcY * 0.5F) * screenHeight);
            float distanceScale = screenHeight * 0.5F * projection.m11() * 0.025F / clip.w;
            distanceScale = Math.max(0.35F, Math.min(2.0F, distanceScale));
            captured.add(new ProjectedItem(item, x, y, distanceScale, distanceSqr));
        }

        captured.sort(Comparator.comparingDouble(ProjectedItem::distanceSqr).reversed());
        if (captured.size() > MAX_ITEMS) captured = new ArrayList<>(captured.subList(0, MAX_ITEMS));
        projectedItems = List.copyOf(captured);
    }

    public static void renderHud(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft client = Minecraft.getInstance();
        if (!DonutUtilitiesClient.MODULES.enabled("item_info")
                || client.level == null || client.player == null || client.options.hideGui) return;

        ItemInfoModule settings = DonutUtilitiesClient.MODULES.itemInfoModule();
        Font font = client.font;
        for (ProjectedItem projected : projectedItems) {
            ItemEntity item = projected.item();
            if (item.isRemoved() || item.level() != client.level || item.getItem().isEmpty()) continue;
            String name = ItemInfoModule.itemName(item.getItem());
            String amount = item.getItem().getCount() + "x";
            int contentWidth = font.width(name) + 4 + font.width(amount);
            int width = contentWidth + 10;
            int height = 15;
            int x = -width / 2;
            int y = -height / 2;

            graphics.pose().pushMatrix();
            graphics.pose().translate(projected.x(), projected.y());
            graphics.pose().scale(projected.scale(), projected.scale());
            RoundedRectRenderer.roundedRect(graphics, x, y, width, height, 5, 0xF0151820);
            int textX = x + 5;
            graphics.drawString(font, name, textX, y + 3, settings.textColor(), true);
            textX += font.width(name) + 4;
            graphics.drawString(font, amount, textX, y + 3, settings.amountColor(), true);
            graphics.pose().popMatrix();
        }
    }

    private record ProjectedItem(ItemEntity item, int x, int y, float scale, double distanceSqr) {
    }
}
