package dev.prchl.donututilities.module;

import dev.prchl.donututilities.DonutUtilitiesClient;
import java.util.Locale;
import net.minecraft.util.Mth;

public final class ModuleListSettings {
    private static final int DEFAULT_TEXT_COLOR = 0xFFDADCE0;
    private String textColorHex = "#DADCE0";
    private int textColor = DEFAULT_TEXT_COLOR;
    private boolean rainbow;

    public String textColorHex() {
        return textColorHex;
    }

    public int textColor() {
        return textColor;
    }

    public boolean rainbow() {
        return rainbow;
    }

    public int renderedColor(long now, int row) {
        if (!rainbow) {
            return textColor;
        }
        float hue = ((now % 6000L) / 6000.0F + row * 0.075F) % 1.0F;
        return 0xFF000000 | Mth.hsvToRgb(hue, 0.72F, 1.0F);
    }

    public void setTextColorHex(String value) {
        String clean = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
        if (clean.startsWith("#")) {
            clean = clean.substring(1);
        }
        clean = clean.replaceAll("[^0-9A-F]", "");
        if (clean.length() > 6) {
            clean = clean.substring(0, 6);
        }
        textColorHex = "#" + clean;
        if (clean.length() == 6) {
            try {
                textColor = 0xFF000000 | Integer.parseInt(clean, 16);
            } catch (NumberFormatException ignored) {
                textColor = DEFAULT_TEXT_COLOR;
            }
        }
    }

    public void appendTextColorChar(String value) {
        if (value != null && !value.isBlank()) {
            setTextColorHex(textColorHex + value);
        }
    }

    public boolean removeLastTextColorChar() {
        String clean = textColorHex.startsWith("#") ? textColorHex.substring(1) : textColorHex;
        if (clean.isEmpty()) {
            return false;
        }
        setTextColorHex(clean.substring(0, clean.length() - 1));
        return true;
    }

    public void toggleRainbow() {
        rainbow = !rainbow;
        DonutUtilitiesClient.markConfigDirty();
    }
}
