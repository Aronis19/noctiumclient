package dev.prchl.donututilities.module;

public final class SkinProtectSettings {
    private String skinOwner = "Notch";
    private boolean changeOwnSkin = true;
    private boolean changeOthersSkin;

    public String skinOwner() {
        return skinOwner;
    }

    public void setSkinOwner(String skinOwner) {
        String value = sanitize(skinOwner);
        if (!value.isBlank()) this.skinOwner = value;
    }

    public boolean appendSkinOwner(String value) {
        if (skinOwner.length() >= 16) return false;
        String clean = sanitize(value);
        if (clean.isEmpty()) return false;
        skinOwner += clean;
        return true;
    }

    public boolean removeLastSkinOwnerChar() {
        if (skinOwner.isEmpty()) return false;
        skinOwner = skinOwner.substring(0, skinOwner.length() - 1);
        return true;
    }

    public boolean changeOwnSkin() {
        return changeOwnSkin;
    }

    public void toggleChangeOwnSkin() {
        changeOwnSkin = !changeOwnSkin;
    }

    public boolean changeOthersSkin() {
        return changeOthersSkin;
    }

    public void toggleChangeOthersSkin() {
        changeOthersSkin = !changeOthersSkin;
    }

    private String sanitize(String value) {
        return value == null ? "" : value.replaceAll("[^A-Za-z0-9_]", "");
    }
}
