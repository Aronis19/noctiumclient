package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.render.IdentityProtect;
import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Font.class)
public abstract class FontNameProtectMixin {
    @ModifyVariable(
            method = "drawInBatch(Lnet/minecraft/network/chat/Component;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/client/gui/Font$DisplayMode;II)V",
            at = @At("HEAD"), argsOnly = true)
    private Component donututilities$protectWorldText(Component text) {
        return IdentityProtect.protectedText(text);
    }
}
