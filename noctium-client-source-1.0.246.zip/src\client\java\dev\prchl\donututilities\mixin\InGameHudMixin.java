package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.render.DonutHudRenderer;
import dev.prchl.donututilities.render.ItemInfoRenderer;
import dev.prchl.donututilities.render.PlayerInfoRenderer;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public abstract class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void donututilities$renderHud(GuiGraphics graphics, DeltaTracker tickCounter, CallbackInfo info) {
        DonutHudRenderer.render(graphics, tickCounter);
        ItemInfoRenderer.renderHud(graphics, tickCounter);
        PlayerInfoRenderer.renderHud(graphics, tickCounter);
    }
}
