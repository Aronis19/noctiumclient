package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.render.IdentityProtect;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(GuiGraphics.class)
public abstract class GuiGraphicsNameProtectMixin {
    @ModifyVariable(
            method = "drawString(Lnet/minecraft/client/gui/Font;Ljava/lang/String;IIIZ)V",
            at = @At("HEAD"), argsOnly = true)
    private String donututilities$protectPlainString(String text) {
        return IdentityProtect.protectedText(text);
    }

    @ModifyVariable(
            method = "drawCenteredString(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V",
            at = @At("HEAD"), argsOnly = true)
    private String donututilities$protectCenteredPlainString(String text) {
        return IdentityProtect.protectedText(text);
    }

    @ModifyVariable(
            method = "drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)V",
            at = @At("HEAD"), argsOnly = true)
    private Component donututilities$protectDrawString(Component text) {
        return IdentityProtect.protectedText(text);
    }

    @ModifyVariable(
            method = "drawCenteredString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;III)V",
            at = @At("HEAD"), argsOnly = true)
    private Component donututilities$protectCenteredString(Component text) {
        return IdentityProtect.protectedText(text);
    }

    @ModifyVariable(
            method = "drawStringWithBackdrop(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIII)V",
            at = @At("HEAD"), argsOnly = true)
    private Component donututilities$protectBackdropString(Component text) {
        return IdentityProtect.protectedText(text);
    }
}
