package dev.prchl.donututilities.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.prchl.donututilities.DonutUtilitiesClient;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;

public final class EspRenderTypes {
    private static final RenderPipeline XRAY_FILL_PIPELINE = RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath(DonutUtilitiesClient.MOD_ID, "xray_esp_fill"))
            .withBlend(BlendFunction.TRANSLUCENT)
            .withCull(false)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withVertexFormat(DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS)
            .build();

    private static final RenderPipeline XRAY_LINE_PIPELINE = RenderPipeline.builder(RenderPipelines.LINES_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath(DonutUtilitiesClient.MOD_ID, "xray_esp_lines"))
            .withBlend(BlendFunction.TRANSLUCENT)
            .withCull(false)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withVertexFormat(DefaultVertexFormat.POSITION_COLOR_NORMAL_LINE_WIDTH, VertexFormat.Mode.LINES)
            .build();

    private static final RenderType XRAY_FILL = RenderType.create("donututilities_xray_fill",
            RenderSetup.builder(XRAY_FILL_PIPELINE)
                    .bufferSize(RenderType.SMALL_BUFFER_SIZE)
                    .createRenderSetup());

    private static final RenderType XRAY_LINES = RenderType.create("donututilities_xray_lines",
            RenderSetup.builder(XRAY_LINE_PIPELINE)
                    .bufferSize(RenderType.SMALL_BUFFER_SIZE)
                    .createRenderSetup());

    private EspRenderTypes() {
    }

    public static RenderType xrayFill() {
        return XRAY_FILL;
    }

    public static RenderType xrayLines() {
        return XRAY_LINES;
    }
}
