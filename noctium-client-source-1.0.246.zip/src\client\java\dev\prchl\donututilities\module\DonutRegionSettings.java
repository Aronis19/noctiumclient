package dev.prchl.donututilities.module;

public final class DonutRegionSettings {
    public enum FontMode {
        NOCTIUM("NOCTIUM"),
        MINECRAFT("MINECRAFT");

        private final String displayName;

        FontMode(String displayName) {
            this.displayName = displayName;
        }

        public String displayName() {
            return displayName;
        }
    }

    public static final int MIN_POSITION = 0;
    public static final int MAX_POSITION = 100;
    public static final int MIN_CELL_SIZE = 8;
    public static final int MAX_CELL_SIZE = 32;
    public static final int MIN_TRANSPARENCY = 10;
    public static final int MAX_TRANSPARENCY = 100;
    public static final int MIN_LABEL_SCALE = 50;
    public static final int MAX_LABEL_SCALE = 150;

    private int positionX = 2;
    private int positionY = 4;
    private int cellSize = 18;
    private int transparency = 75;
    private int labelScale = 90;
    private boolean coordinates = true;
    private boolean regionLabels = true;
    private boolean grid = true;
    private boolean playerIndicator = true;
    private FontMode fontMode = FontMode.NOCTIUM;

    public int positionX() {
        return positionX;
    }

    public void setPositionX(int positionX) {
        this.positionX = clamp(positionX, MIN_POSITION, MAX_POSITION);
    }

    public int positionY() {
        return positionY;
    }

    public void setPositionY(int positionY) {
        this.positionY = clamp(positionY, MIN_POSITION, MAX_POSITION);
    }

    public int cellSize() {
        return cellSize;
    }

    public void setCellSize(int cellSize) {
        this.cellSize = clamp(cellSize, MIN_CELL_SIZE, MAX_CELL_SIZE);
    }

    public int transparency() {
        return transparency;
    }

    public void setTransparency(int transparency) {
        this.transparency = clamp(transparency, MIN_TRANSPARENCY, MAX_TRANSPARENCY);
    }

    public int labelScale() {
        return labelScale;
    }

    public void setLabelScale(int labelScale) {
        this.labelScale = clamp(labelScale, MIN_LABEL_SCALE, MAX_LABEL_SCALE);
    }

    public boolean coordinates() {
        return coordinates;
    }

    public void toggleCoordinates() {
        coordinates = !coordinates;
    }

    public boolean regionLabels() {
        return regionLabels;
    }

    public void toggleRegionLabels() {
        regionLabels = !regionLabels;
    }

    public boolean grid() {
        return grid;
    }

    public void toggleGrid() {
        grid = !grid;
    }

    public boolean playerIndicator() {
        return playerIndicator;
    }

    public void togglePlayerIndicator() {
        playerIndicator = !playerIndicator;
    }

    public FontMode fontMode() {
        return fontMode;
    }

    public void setFontMode(FontMode fontMode) {
        if (fontMode != null) {
            this.fontMode = fontMode;
        }
    }

    public void cycleFontMode() {
        FontMode[] modes = FontMode.values();
        fontMode = modes[(fontMode.ordinal() + 1) % modes.length];
    }

    private static int clamp(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
