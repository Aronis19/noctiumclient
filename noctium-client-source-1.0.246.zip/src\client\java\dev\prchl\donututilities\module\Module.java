package dev.prchl.donututilities.module;

import dev.prchl.donututilities.DonutUtilitiesClient;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class Module {
    private final String id;
    private final String name;
    private final ModuleCategory category;
    private final String description;
    private final int color;
    private boolean enabled;
    private int keyCode = GLFW.GLFW_KEY_UNKNOWN;
    private boolean keyWasDown;
    private boolean capturingKey;

    public Module(String id, String name, ModuleCategory category, String description, int color) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.description = description;
        this.color = color;
    }

    public String id() {
        return id;
    }

    public String name() {
        return name;
    }

    public ModuleCategory category() {
        return category;
    }

    public String description() {
        return description;
    }

    public int color() {
        return color;
    }

    public boolean enabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) {
            return;
        }
        this.enabled = enabled;
        DonutUtilitiesClient.markConfigDirty();
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void tick(Minecraft client) {
    }

    public void tickKeybind(Minecraft client) {
        if (client == null || client.getWindow() == null || client.screen != null || capturingKey
                || keyCode == GLFW.GLFW_KEY_UNKNOWN) {
            keyWasDown = false;
            return;
        }
        boolean down = GLFW.glfwGetKey(client.getWindow().handle(), keyCode) == GLFW.GLFW_PRESS;
        if (down && !keyWasDown) {
            toggle();
            DonutUtilitiesClient.saveConfig();
        }
        keyWasDown = down;
    }

    public int keyCode() {
        return keyCode;
    }

    public void setStoredKeyCode(int keyCode) {
        this.keyCode = keyCode;
    }

    public boolean capturingKey() {
        return capturingKey;
    }

    public void startCapturingKey() {
        capturingKey = true;
    }

    public void setKeyCode(int keyCode) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            this.keyCode = GLFW.GLFW_KEY_UNKNOWN;
        } else if (keyCode != GLFW.GLFW_KEY_UNKNOWN) {
            this.keyCode = keyCode;
            this.keyWasDown = true;
        }
        capturingKey = false;
    }

    public String keyName() {
        if (capturingKey) {
            return "PRESS KEY";
        }
        if (keyCode == GLFW.GLFW_KEY_UNKNOWN) {
            return "NONE";
        }
        String name = GLFW.glfwGetKeyName(keyCode, 0);
        if (name != null && !name.isBlank()) {
            return name.toUpperCase(java.util.Locale.ROOT);
        }
        return switch (keyCode) {
            case GLFW.GLFW_KEY_F1 -> "F1";
            case GLFW.GLFW_KEY_F2 -> "F2";
            case GLFW.GLFW_KEY_F3 -> "F3";
            case GLFW.GLFW_KEY_F4 -> "F4";
            case GLFW.GLFW_KEY_F5 -> "F5";
            case GLFW.GLFW_KEY_F6 -> "F6";
            case GLFW.GLFW_KEY_F7 -> "F7";
            case GLFW.GLFW_KEY_F8 -> "F8";
            case GLFW.GLFW_KEY_F9 -> "F9";
            case GLFW.GLFW_KEY_F10 -> "F10";
            case GLFW.GLFW_KEY_F11 -> "F11";
            case GLFW.GLFW_KEY_F12 -> "F12";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_INSERT -> "INSERT";
            case GLFW.GLFW_KEY_DELETE -> "DELETE";
            case GLFW.GLFW_KEY_HOME -> "HOME";
            case GLFW.GLFW_KEY_END -> "END";
            case GLFW.GLFW_KEY_PAGE_UP -> "PGUP";
            case GLFW.GLFW_KEY_PAGE_DOWN -> "PGDN";
            default -> "KEY " + keyCode;
        };
    }
}
