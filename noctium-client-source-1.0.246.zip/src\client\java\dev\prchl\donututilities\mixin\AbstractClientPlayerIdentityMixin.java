package dev.prchl.donututilities.mixin;

import dev.prchl.donututilities.render.IdentityProtect;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerIdentityMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void donututilities$protectDirectSkin(CallbackInfoReturnable<PlayerSkin> callback) {
        AbstractClientPlayer player = (AbstractClientPlayer) (Object) this;
        callback.setReturnValue(IdentityProtect.protectedSkin(player.getUUID(), callback.getReturnValue()));
    }
}
