# Contributing

DonutSMP Utilities is GPL-3.0-or-later. Contributions must be compatible with that license.

## Rules

- Keep third-party credits and license notices intact.
- Do not add anti-cheat bypasses or server protection bypass logic.
- Prefer client-loaded data only: loaded chunks, loaded block entities, and rendered entities.
- Keep scanner changes performance-conscious and capped per tick.
- Include source changes when distributing jars, as required by GPL-3.0-or-later.
