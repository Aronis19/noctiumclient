package dev.prchl.donututilities.render;

import dev.prchl.donututilities.DonutUtilitiesClient;
import dev.prchl.donututilities.mixin.GameRendererAccessor;
import dev.prchl.donututilities.module.PlayerInfoSettings;
import dev.prchl.donututilities.render.shape.RoundedRectRenderer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

public final class PlayerInfoRenderer {
    private static final int MAX_PLAYERS = 64;
    private static final float WORLD_PIXEL_SCALE = 0.025F;
    private static final int SLOT_SIZE = 18;
    private static final FontDescription PLAYER_INFO_FONT = new FontDescription.Resource(
            Identifier.fromNamespaceAndPath(DonutUtilitiesClient.MOD_ID, "google_sans_semibold"));
    private static List<ProjectedPlayer> projectedPlayers = List.of();

    private PlayerInfoRenderer() {
    }

    public static void register() {
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(PlayerInfoRenderer::captureWorldPositions);
    }

    private static void captureWorldPositions(WorldRenderContext context) {
        Minecraft client = Minecraft.getInstance();
        if (!DonutUtilitiesClient.MODULES.enabled("player_info")
                || client.level == null || client.player == null || client.options.hideGui) {
            projectedPlayers = List.of();
            return;
        }

        Camera camera = client.gameRenderer.getMainCamera();
        float partialTick = camera.getPartialTickTime();
        float fov = ((GameRendererAccessor) client.gameRenderer)
                .donututilities$getFov(camera, partialTick, true);
        Matrix4f projection = client.gameRenderer.getProjectionMatrix(fov);
        Vec3 cameraPos = camera.position();
        Quaternionf inverseCameraRotation = new Quaternionf(camera.rotation()).conjugate();

        int screenWidth = client.getWindow().getGuiScaledWidth();
        int screenHeight = client.getWindow().getGuiScaledHeight();
        double maxDistance = Math.max(128.0D, client.options.renderDistance().get() * 16.0D + 32.0D);
        List<ProjectedPlayer> captured = new ArrayList<>();

        for (Player player : client.level.players()) {
            double distanceSqr = cameraPos.distanceToSqr(player.position());
            if (player.isRemoved() || distanceSqr > maxDistance * maxDistance) {
                continue;
            }
            if (player == client.player && cameraPos.distanceToSqr(player.getEyePosition(partialTick)) < 0.25D) {
                continue;
            }

            Vec3 anchor = player.getPosition(partialTick).add(0.0D, player.getBbHeight() + 0.48D, 0.0D);
            Vector3f cameraSpace = new Vector3f(
                    (float) (anchor.x - cameraPos.x),
                    (float) (anchor.y - cameraPos.y),
                    (float) (anchor.z - cameraPos.z));
            inverseCameraRotation.transform(cameraSpace);
            Vector4f clip = new Vector4f(cameraSpace, 1.0F);
            projection.transform(clip);
            if (clip.w <= 0.001F) {
                continue;
            }

            float ndcX = clip.x / clip.w;
            float ndcY = clip.y / clip.w;
            if (ndcX < -1.2F || ndcX > 1.2F || ndcY < -1.2F || ndcY > 1.2F) {
                continue;
            }
            int x = Math.round((ndcX * 0.5F + 0.5F) * screenWidth);
            int y = Math.round((0.5F - ndcY * 0.5F) * screenHeight);
            float distanceScale = screenHeight * 0.5F * projection.m11() * WORLD_PIXEL_SCALE / clip.w;
            distanceScale = Math.max(0.35F, Math.min(6.0F, distanceScale));
            captured.add(new ProjectedPlayer(player, x, y, distanceScale, distanceSqr));
        }

        captured.sort(Comparator.comparingDouble(ProjectedPlayer::distanceSqr).reversed());
        if (captured.size() > MAX_PLAYERS) {
            captured = new ArrayList<>(captured.subList(0, MAX_PLAYERS));
        }
        projectedPlayers = List.copyOf(captured);
    }

    public static void renderHud(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft client = Minecraft.getInstance();
        if (!DonutUtilitiesClient.MODULES.enabled("player_info")
                || client.level == null || client.player == null || client.options.hideGui) {
            return;
        }

        PlayerInfoSettings settings = DonutUtilitiesClient.MODULES.playerInfoSettings();
        for (ProjectedPlayer projected : projectedPlayers) {
            Player player = projected.player();
            if (player.isRemoved() || player.level() != client.level) {
                continue;
            }

            graphics.pose().pushMatrix();
            graphics.pose().translate(projected.x(), projected.y());
            float scale = projected.distanceScale() * settings.scale() / 100.0F;
            graphics.pose().scale(scale, scale);
            drawPlayerInfo(graphics, client, player, settings);
            graphics.pose().popMatrix();
        }
    }

    private static void drawPlayerInfo(GuiGraphics graphics, Minecraft client, Player player, PlayerInfoSettings settings) {
        Font font = client.font;
        ItemStack[] equipment = {
                player.getMainHandItem(),
                player.getItemBySlot(EquipmentSlot.HEAD),
                player.getItemBySlot(EquipmentSlot.CHEST),
                player.getItemBySlot(EquipmentSlot.LEGS),
                player.getItemBySlot(EquipmentSlot.FEET),
                player.getOffhandItem()
        };

        int itemRowWidth = SLOT_SIZE * equipment.length;
        int itemX = -itemRowWidth / 2;
        int itemY = settings.itemsBelowHealth() ? 2 : -35;
        for (int index = 0; index < equipment.length; index++) {
            ItemStack stack = equipment[index];
            if (!stack.isEmpty()) {
                int x = itemX + index * SLOT_SIZE;
                graphics.renderItem(player, stack, x, itemY, index);
                graphics.renderItemDecorations(font, stack, x, itemY);
            }
        }

        String name = IdentityProtect.protectedName(player.getUUID(), player.getName().getString());
        String ping = ping(client, player) + "ms";
        String distance = String.format(Locale.ROOT, "%.1fm", client.player.distanceTo(player));
        Component nameText = playerInfoText(name, settings.customFont());
        Component pingText = playerInfoText(ping, settings.customFont());
        Component distanceText = playerInfoText(distance, settings.customFont());
        int contentWidth = font.width(nameText) + 5 + font.width(pingText) + 5 + font.width(distanceText);
        int tagWidth = Math.max(48, contentWidth + 10);
        int tagX = -tagWidth / 2;
        int tagY = -16;
        RoundedRectRenderer.roundedRect(graphics, tagX, tagY, tagWidth, 15, 5, 0x8D151820);

        int textX = tagX + Math.max(5, (tagWidth - contentWidth) / 2);
        graphics.drawString(font, nameText, textX, tagY + 3, settings.nickColor(), true);
        textX += font.width(nameText) + 5;
        graphics.drawString(font, pingText, textX, tagY + 3, 0xFF75E08A, true);
        textX += font.width(pingText) + 5;
        graphics.drawString(font, distanceText, textX, tagY + 3, 0xFFD6D8DE, true);

        float health = player.getMaxHealth() <= 0.0F ? 0.0F : player.getHealth() / player.getMaxHealth();
        health = Math.max(0.0F, Math.min(1.0F, health));
        graphics.fill(tagX + 3, -3, tagX + tagWidth - 3, -1, 0xAA252A32);
        int healthWidth = Math.round((tagWidth - 6) * health);
        if (healthWidth > 0) {
            graphics.fill(tagX + 3, -3, tagX + 3 + healthWidth, -1, 0xFF75E08A);
        }
    }

    private static int ping(Minecraft client, Player player) {
        if (client.getConnection() == null) {
            return 0;
        }
        PlayerInfo info = client.getConnection().getPlayerInfo(player.getUUID());
        return info == null ? 0 : Math.max(0, info.getLatency());
    }

    private static Component playerInfoText(String text, boolean customFont) {
        Component component = Component.literal(text);
        return customFont ? component.copy().withStyle(style -> style.withFont(PLAYER_INFO_FONT)) : component;
    }

    private record ProjectedPlayer(Player player, int x, int y, float distanceScale, double distanceSqr) {
    }
}
